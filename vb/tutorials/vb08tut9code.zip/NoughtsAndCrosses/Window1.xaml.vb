﻿Class Window1 
    Private WithEvents btn1, btn2, btn3, btn4, _
    btn5, btn6, btn7, btn8, btn9 As New Button
    Dim IsCross As Boolean
    Dim Nought As String = "O"
    Dim Cross As String = "X"
    Dim Won As Boolean
    Dim Board(3, 3) As String

    Private Sub Add(ByRef Grid As Grid, ByRef Button As Button, _
                    ByRef Row As Integer, ByRef Column As Integer)
        Button.Margin = New Thickness(5)
        Grid.Children.Add(Button)
        Grid.SetColumn(Button, Column)
        Grid.SetRow(Button, Row)
    End Sub

    Private Sub Layout(ByRef Grid As Grid)
        Grid.ColumnDefinitions.Clear() ' Clear Columns
        Grid.RowDefinitions.Clear() ' Clear Rows
        Grid.Children.Clear() ' Clear the Grid
        Grid.ColumnDefinitions.Add(New ColumnDefinition)
        Grid.ColumnDefinitions.Add(New ColumnDefinition)
        Grid.ColumnDefinitions.Add(New ColumnDefinition)
        Grid.RowDefinitions.Add(New RowDefinition)
        Grid.RowDefinitions.Add(New RowDefinition)
        Grid.RowDefinitions.Add(New RowDefinition)
        Add(Grid, btn1, 0, 0)
        Add(Grid, btn2, 0, 1)
        Add(Grid, btn3, 0, 2)
        Add(Grid, btn4, 1, 0)
        Add(Grid, btn5, 1, 1)
        Add(Grid, btn6, 1, 2)
        Add(Grid, btn7, 2, 0)
        Add(Grid, btn8, 2, 1)
        Add(Grid, btn9, 2, 2)
        For Each Button As Button In Grid.Children
            Button.Content = Nothing ' Clear Buttons
        Next
    End Sub

    Private Function GetPiece(ByRef Button As Button) As String
        If IsCross Then ' Draw X
            Dim Line1, Line2 As New LineGeometry
            Dim Lines As New Path
            Dim LineGroup As New GeometryGroup
            Line1.StartPoint = New Point(0, 0)
            Line1.EndPoint = New Point(50, 50)
            Line2.StartPoint = New Point(50, 0)
            Line2.EndPoint = New Point(0, 50)
            LineGroup.Children.Add(Line1)
            LineGroup.Children.Add(Line2)
            Lines.Stretch = Stretch.Uniform
            Lines.Data = LineGroup
            Lines.Stroke = Brushes.Red
            Lines.StrokeThickness = 4.0
            Lines.Margin = New Thickness(5)
            Button.Content = Lines
            Return Cross
        Else ' Draw O
            Dim CircleGeo As New  _
            EllipseGeometry(New Rect(0, 0, 50, 50))
            Dim Circle As New Path
            Circle.Stretch = Stretch.Uniform
            Circle.Data = CircleGeo
            Circle.Stroke = Brushes.Blue
            Circle.StrokeThickness = 4.0
            Circle.Margin = New Thickness(5)
            Button.Content = Circle
            Return Nought
        End If
    End Function

    Private Sub SetPiece(ByRef Grid As Grid, ByRef Button As Button)
        Dim Piece As String
        If Button.Content Is Nothing Then
            Piece = GetPiece(Button)
            Board(Grid.GetRow(Button), Grid.GetColumn(Button)) = Piece
        End If
    End Sub

    Private Sub NewGame()
        Dim Result As MsgBoxResult
        Dim Piece As String
        Layout(BoardLayout) ' Reset Grid
        Board(0, 0) = ""
        Board(0, 1) = ""
        Board(0, 2) = ""
        Board(1, 0) = ""
        Board(1, 1) = ""
        Board(1, 2) = ""
        Board(2, 0) = ""
        Board(2, 1) = ""
        Board(2, 2) = ""
        Won = False
        Result = MsgBox(Cross & " goes first?", _
                        MsgBoxStyle.Question + MsgBoxStyle.YesNo, _
                        "Noughts and Crosses")
        If Result = MsgBoxResult.Yes Then
            IsCross = True
            Piece = Cross
        Else
            IsCross = False
            Piece = Nought
        End If
        Me.Title = "Player:" & Piece
    End Sub

    Private Function CheckWinner(ByRef Player As String) As Boolean
        If (Board(0, 0) = Player And Board(0, 1) = Player And Board(0, 2) = Player) Or _
        (Board(1, 0) = Player And Board(1, 1) = Player And Board(1, 2) = Player) Or _
        (Board(2, 0) = Player And Board(2, 1) = Player And Board(2, 2) = Player) Or _
        (Board(0, 0) = Player And Board(1, 0) = Player And Board(2, 0) = Player) Or _
        (Board(0, 1) = Player And Board(1, 1) = Player And Board(2, 1) = Player) Or _
        (Board(0, 2) = Player And Board(1, 2) = Player And Board(2, 2) = Player) Or _
        (Board(0, 0) = Player And Board(1, 1) = Player And Board(2, 2) = Player) Or _
        (Board(0, 2) = Player And Board(1, 1) = Player And Board(2, 0) = Player) Then
            Return True
        End If
    End Function

    Private Sub CheckDraw()
        If Board(0, 0) <> "" And Board(0, 1) <> "" And Board(0, 2) <> "" _
        And Board(1, 0) <> "" And Board(1, 1) <> "" And Board(1, 2) <> "" _
        And Board(2, 0) <> "" And Board(2, 1) <> "" And Board(2, 2) <> "" Then
            If Not Won Then
                MsgBox("Draw!", MsgBoxStyle.Information, "Noughts and Crosses")
                Me.Title = "Draw!"
                NewGame()
            End If
        End If
    End Sub

    Private Sub OnClick(ByVal sender As System.Object, _
                         ByVal e As System.Windows.RoutedEventArgs) _
                         Handles btn1.Click, btn2.Click, btn3.Click, _
                         btn4.Click, btn5.Click, btn6.Click, btn7.Click, _
                         btn8.Click, btn9.Click
        Dim Piece As String = ""
        If Not Won Then
            SetPiece(BoardLayout, sender)
            If CheckWinner(Cross) Then
                Piece = Cross
            ElseIf CheckWinner(Nought) Then
                Piece = Nought
            End If
            If Piece <> "" Then
                Won = True
                MsgBox("Player " & Piece & " Won!", _
                       MsgBoxStyle.Information, "Noughts and Crosses")
            End If
            CheckDraw()
            IsCross = Not IsCross
            If IsCross Then
                Me.Title = "Player:" & Cross
            Else
                Me.Title = "Player:" & Nought
            End If
        Else
            MsgBox("Game Over!", _
                   MsgBoxStyle.Exclamation, "Noughts and Crosses")
            NewGame()
        End If
    End Sub

    Private Sub btnNew_Click(ByVal sender As System.Object, _
                             ByVal e As System.Windows.RoutedEventArgs) _
                             Handles btnNew.Click
        NewGame()
    End Sub

    Private Sub Window1_Loaded(ByVal sender As Object, _
                               ByVal e As System.Windows.RoutedEventArgs) _
                               Handles Me.Loaded
        NewGame()
    End Sub
End Class

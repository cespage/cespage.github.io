Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, _
                              ByVal e As System.EventArgs) _
                              Handles Button1.Click
        MsgBox(TextBox1.Text, MsgBoxStyle.Information, "Test")
    End Sub
End Class

Public Class Form1

    Dim DrawBrush As Brush
    Dim DrawBitmap As Bitmap
    Dim DrawGraphics As Graphics
    Dim MyFont As New System.Drawing.Font("Arial", 12, _
    FontStyle.Regular, GraphicsUnit.Point)

    Dim arrNumber(0 To 5) As Integer
    Dim intNumber As Integer

    ' Selects Numbers
    Private Sub ChooseNumbers()
        Dim x, y As Integer
        For x = 0 To 5
Start:
            Randomize()
            intNumber = Int((49 * Rnd()) + 1) ' Random number 1 to 49
            For y = 0 To 5
                ' If number already been selected select another one
                If intNumber = arrNumber(y) Then
                    GoTo Start
                End If
            Next y
            arrNumber(x) = intNumber
        Next x
    End Sub

    ' Determines what colour the ball should be based on the Value
    Private Function BallColour(ByVal Value As Integer) As Brush
        If Value > 0 And Value < 10 Then
            DrawBrush = Brushes.White
        ElseIf Value > 10 And Value < 20 Then
            DrawBrush = Brushes.SkyBlue
        ElseIf Value > 20 And Value < 30 Then
            DrawBrush = Brushes.Magenta
        ElseIf Value > 30 And Value < 40 Then
            DrawBrush = Brushes.LawnGreen
        ElseIf Value > 40 And Value < 50 Then
            DrawBrush = Brushes.Yellow
        End If
        Return DrawBrush
    End Function

    ' Draws a Ball with a colour and value
    Private Sub DrawBall(ByVal Number As String, ByVal Left As Integer)
        Dim pos As Integer
        If Number.Length = 2 Then pos = 9 Else pos = 13 ' Postion for Single or Double Digit
        DrawGraphics.SmoothingMode = Drawing2D.SmoothingMode.HighQuality ' Smooth Drawing
        DrawGraphics.FillEllipse(BallColour(CInt(Number)), Left, 1, 40, 40) ' Draw Ball
        DrawGraphics.DrawString(Number, MyFont, Brushes.Black, Left + pos, 13) ' Draw Number
    End Sub

    ' Outputs all Balls to the PictureBox
    Private Sub RenderBalls()
        Dim i As Integer
        Dim intLeft As Integer
        intLeft = 1
        DrawBitmap = New Bitmap(PictureBox1.Width, PictureBox1.Height)
        DrawGraphics = Graphics.FromImage(DrawBitmap)
        For i = 0 To 5
            DrawBall(arrNumber(i), intLeft)
            intLeft = intLeft + 45
        Next
        PictureBox1.Image = DrawBitmap
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, _
                              ByVal e As System.EventArgs) _
                              Handles Button1.Click
        ChooseNumbers()
        RenderBalls()
    End Sub
End Class

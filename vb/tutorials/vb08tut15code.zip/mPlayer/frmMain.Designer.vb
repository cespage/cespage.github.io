﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.TrackBar = New System.Windows.Forms.TrackBar
        Me.Display = New System.Windows.Forms.Timer(Me.components)
        Me.mnuPlayer = New System.Windows.Forms.MenuStrip
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MediaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PlayPauseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.StopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripSeparator
        Me.SlowerSpeedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.NormalSpeedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FasterSpeedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripSeparator
        Me.RepeatToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AudioToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.VolumeUpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.VolumeNormalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.VolumeDownToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripSeparator
        Me.BalanceLeftToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BalanceEqualToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BalanceRightToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripSeparator
        Me.MuteLeftToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MuteRightToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.Player = New mPlayer.mPlayerControl
        CType(Me.TrackBar, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.mnuPlayer.SuspendLayout()
        Me.SuspendLayout()
        '
        'TrackBar
        '
        Me.TrackBar.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TrackBar.Location = New System.Drawing.Point(0, 219)
        Me.TrackBar.Name = "TrackBar"
        Me.TrackBar.Size = New System.Drawing.Size(284, 45)
        Me.TrackBar.TabIndex = 1
        '
        'Display
        '
        Me.Display.Enabled = True
        Me.Display.Interval = 333
        '
        'mnuPlayer
        '
        Me.mnuPlayer.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.MediaToolStripMenuItem, Me.AudioToolStripMenuItem})
        Me.mnuPlayer.Location = New System.Drawing.Point(0, 0)
        Me.mnuPlayer.Name = "mnuPlayer"
        Me.mnuPlayer.Size = New System.Drawing.Size(284, 24)
        Me.mnuPlayer.TabIndex = 2
        Me.mnuPlayer.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenToolStripMenuItem, Me.CloseToolStripMenuItem, Me.ToolStripMenuItem1, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        Me.OpenToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.OpenToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.OpenToolStripMenuItem.Text = "Open..."
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.W), System.Windows.Forms.Keys)
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.CloseToolStripMenuItem.Text = "Close"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(152, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'MediaToolStripMenuItem
        '
        Me.MediaToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PlayPauseToolStripMenuItem, Me.StopToolStripMenuItem, Me.ToolStripMenuItem2, Me.SlowerSpeedToolStripMenuItem, Me.NormalSpeedToolStripMenuItem, Me.FasterSpeedToolStripMenuItem, Me.ToolStripMenuItem3, Me.RepeatToolStripMenuItem})
        Me.MediaToolStripMenuItem.Name = "MediaToolStripMenuItem"
        Me.MediaToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.MediaToolStripMenuItem.Text = "Media"
        '
        'PlayPauseToolStripMenuItem
        '
        Me.PlayPauseToolStripMenuItem.Name = "PlayPauseToolStripMenuItem"
        Me.PlayPauseToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.P), System.Windows.Forms.Keys)
        Me.PlayPauseToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.PlayPauseToolStripMenuItem.Text = "Play/Pause"
        '
        'StopToolStripMenuItem
        '
        Me.StopToolStripMenuItem.Name = "StopToolStripMenuItem"
        Me.StopToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.StopToolStripMenuItem.Size = New System.Drawing.Size(224, 22)
        Me.StopToolStripMenuItem.Text = "Stop"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(146, 6)
        '
        'SlowerSpeedToolStripMenuItem
        '
        Me.SlowerSpeedToolStripMenuItem.Name = "SlowerSpeedToolStripMenuItem"
        Me.SlowerSpeedToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.SlowerSpeedToolStripMenuItem.Size = New System.Drawing.Size(224, 22)
        Me.SlowerSpeedToolStripMenuItem.Text = "Slower Speed"
        '
        'NormalSpeedToolStripMenuItem
        '
        Me.NormalSpeedToolStripMenuItem.Name = "NormalSpeedToolStripMenuItem"
        Me.NormalSpeedToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.NormalSpeedToolStripMenuItem.Size = New System.Drawing.Size(224, 22)
        Me.NormalSpeedToolStripMenuItem.Text = "Normal Speed"
        '
        'FasterSpeedToolStripMenuItem
        '
        Me.FasterSpeedToolStripMenuItem.Name = "FasterSpeedToolStripMenuItem"
        Me.FasterSpeedToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.G), System.Windows.Forms.Keys)
        Me.FasterSpeedToolStripMenuItem.Size = New System.Drawing.Size(224, 22)
        Me.FasterSpeedToolStripMenuItem.Text = "Faster Speed"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(146, 6)
        '
        'RepeatToolStripMenuItem
        '
        Me.RepeatToolStripMenuItem.CheckOnClick = True
        Me.RepeatToolStripMenuItem.Name = "RepeatToolStripMenuItem"
        Me.RepeatToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.T), System.Windows.Forms.Keys)
        Me.RepeatToolStripMenuItem.Size = New System.Drawing.Size(224, 22)
        Me.RepeatToolStripMenuItem.Text = "Repeat"
        '
        'AudioToolStripMenuItem
        '
        Me.AudioToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VolumeUpToolStripMenuItem, Me.VolumeNormalToolStripMenuItem, Me.VolumeDownToolStripMenuItem, Me.ToolStripMenuItem4, Me.BalanceLeftToolStripMenuItem, Me.BalanceEqualToolStripMenuItem, Me.BalanceRightToolStripMenuItem, Me.ToolStripMenuItem5, Me.MuteLeftToolStripMenuItem, Me.MuteRightToolStripMenuItem})
        Me.AudioToolStripMenuItem.Name = "AudioToolStripMenuItem"
        Me.AudioToolStripMenuItem.Size = New System.Drawing.Size(51, 20)
        Me.AudioToolStripMenuItem.Text = "Audio"
        '
        'VolumeUpToolStripMenuItem
        '
        Me.VolumeUpToolStripMenuItem.Name = "VolumeUpToolStripMenuItem"
        Me.VolumeUpToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F9
        Me.VolumeUpToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.VolumeUpToolStripMenuItem.Text = "Volume Up"
        '
        'VolumeNormalToolStripMenuItem
        '
        Me.VolumeNormalToolStripMenuItem.Name = "VolumeNormalToolStripMenuItem"
        Me.VolumeNormalToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F7
        Me.VolumeNormalToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.VolumeNormalToolStripMenuItem.Text = "Volume Normal"
        '
        'VolumeDownToolStripMenuItem
        '
        Me.VolumeDownToolStripMenuItem.Name = "VolumeDownToolStripMenuItem"
        Me.VolumeDownToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F8
        Me.VolumeDownToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.VolumeDownToolStripMenuItem.Text = "Volume Down"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(155, 6)
        '
        'BalanceLeftToolStripMenuItem
        '
        Me.BalanceLeftToolStripMenuItem.Name = "BalanceLeftToolStripMenuItem"
        Me.BalanceLeftToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.L), System.Windows.Forms.Keys)
        Me.BalanceLeftToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.BalanceLeftToolStripMenuItem.Text = "Balance Left"
        '
        'BalanceEqualToolStripMenuItem
        '
        Me.BalanceEqualToolStripMenuItem.Name = "BalanceEqualToolStripMenuItem"
        Me.BalanceEqualToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.E), System.Windows.Forms.Keys)
        Me.BalanceEqualToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.BalanceEqualToolStripMenuItem.Text = "Balance Equal"
        '
        'BalanceRightToolStripMenuItem
        '
        Me.BalanceRightToolStripMenuItem.Name = "BalanceRightToolStripMenuItem"
        Me.BalanceRightToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.R), System.Windows.Forms.Keys)
        Me.BalanceRightToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.BalanceRightToolStripMenuItem.Text = "Balance Right"
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(155, 6)
        '
        'MuteLeftToolStripMenuItem
        '
        Me.MuteLeftToolStripMenuItem.CheckOnClick = True
        Me.MuteLeftToolStripMenuItem.Name = "MuteLeftToolStripMenuItem"
        Me.MuteLeftToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.L), System.Windows.Forms.Keys)
        Me.MuteLeftToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.MuteLeftToolStripMenuItem.Text = "Mute Left"
        '
        'MuteRightToolStripMenuItem
        '
        Me.MuteRightToolStripMenuItem.CheckOnClick = True
        Me.MuteRightToolStripMenuItem.Name = "MuteRightToolStripMenuItem"
        Me.MuteRightToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.R), System.Windows.Forms.Keys)
        Me.MuteRightToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.MuteRightToolStripMenuItem.Text = "Mute Right"
        '
        'Player
        '
        Me.Player.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Player.BackColor = System.Drawing.SystemColors.Control
        Me.Player.Balance = 500
        Me.Player.Location = New System.Drawing.Point(12, 35)
        Me.Player.Mute = mPlayer.mPlayerControl.Channels.None
        Me.Player.Name = "Player"
        Me.Player.Repeat = False
        Me.Player.Size = New System.Drawing.Size(260, 174)
        Me.Player.Speed = 1000
        Me.Player.TabIndex = 0
        Me.Player.Text = "MPlayerControl1"
        Me.Player.Volume = 500
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 264)
        Me.Controls.Add(Me.TrackBar)
        Me.Controls.Add(Me.Player)
        Me.Controls.Add(Me.mnuPlayer)
        Me.MainMenuStrip = Me.mnuPlayer
        Me.Name = "frmMain"
        Me.Text = "Form1"
        CType(Me.TrackBar, System.ComponentModel.ISupportInitialize).EndInit()
        Me.mnuPlayer.ResumeLayout(False)
        Me.mnuPlayer.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Player As mPlayer.mPlayerControl
    Friend WithEvents TrackBar As System.Windows.Forms.TrackBar
    Friend WithEvents Display As System.Windows.Forms.Timer
    Friend WithEvents mnuPlayer As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MediaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PlayPauseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StopToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SlowerSpeedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NormalSpeedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FasterSpeedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents RepeatToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AudioToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VolumeUpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VolumeNormalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VolumeDownToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BalanceLeftToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BalanceEqualToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BalanceRightToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MuteLeftToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MuteRightToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class

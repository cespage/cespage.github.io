﻿Public Class frmMain

    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles OpenToolStripMenuItem.Click
        Dim Open As New OpenFileDialog()
        Open.Filter = "Audio|*.wma;*.mp3|Video|*.wmv;*.avi;*.mpeg;*.mpg|All files (*.*)|*.*"
        Open.CheckFileExists = True
        If Open.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            Try
                Player.Open(Open.FileName)
                If Player.TotalTime >= 0 Then ' Initialise the Trackbar
                    TrackBar.Value = 0
                    TrackBar.Minimum = 0
                    TrackBar.Maximum = CInt(Player.TotalTime)
                End If
                Player.Play() ' Play Media
                Me.Text = "mPlayer - " & Open.FileName
            Catch ex As Exception
                ' Do nothing on Exception
            End Try
        End If
    End Sub

    Private Sub CloseToolStripMenuItem_Click(ByVal sender As System.Object, _
                                             ByVal e As System.EventArgs) _
                                             Handles CloseToolStripMenuItem.Click
        Dim Response As MsgBoxResult
        Response = MsgBox("Are you sure you want to Close the Media?", _
                          MsgBoxStyle.Question + MsgBoxStyle.YesNo, _
                          "mPlayer")
        If Response = MsgBoxResult.Yes Then
            Player.Close()
        End If
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles ExitToolStripMenuItem.Click
        Dim Response As MsgBoxResult
        Response = MsgBox("Are you sure you want to Exit mPlayer?", _
                          MsgBoxStyle.Question + MsgBoxStyle.YesNo, _
                          "mPlayer")
        If Response = MsgBoxResult.Yes Then
            End
        End If
    End Sub

    Private Sub PlayPauseToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                 ByVal e As System.EventArgs) _
                                                 Handles PlayPauseToolStripMenuItem.Click
        If Player.Playing Then
            If Player.Paused Then
                Player.Resume()
            Else
                Player.Pause()
            End If
        Else
            Player.Play()
        End If
    End Sub

    Private Sub StopToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles StopToolStripMenuItem.Click
        Player.Stop()
    End Sub

    Private Sub SlowerSpeedToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                   ByVal e As System.EventArgs) _
                                                   Handles SlowerSpeedToolStripMenuItem.Click
        If Player.Speed > 1 Then
            Player.Speed -= 100
        End If
    End Sub

    Private Sub NormalSpeedToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                   ByVal e As System.EventArgs) _
                                                   Handles NormalSpeedToolStripMenuItem.Click
        Player.Speed = 1000
    End Sub

    Private Sub FasterSpeedToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                   ByVal e As System.EventArgs) _
                                                   Handles FasterSpeedToolStripMenuItem.Click
        If Player.Speed < 2000 Then
            Player.Speed += 100
        End If
    End Sub

    Private Sub RepeatToolStripMenuItem_Click(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) _
                                              Handles RepeatToolStripMenuItem.Click
        Player.Repeat = RepeatToolStripMenuItem.Checked
    End Sub

    Private Sub VolumeUpToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                ByVal e As System.EventArgs) _
                                                Handles VolumeUpToolStripMenuItem.Click
        If Player.Volume < 1000 Then
            Player.Volume += 100
        End If
    End Sub

    Private Sub VolumeNormalToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                    ByVal e As System.EventArgs) _
                                                    Handles VolumeNormalToolStripMenuItem.Click
        Player.Volume = 500
    End Sub

    Private Sub VolumeDownToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                  ByVal e As System.EventArgs) _
                                                  Handles VolumeDownToolStripMenuItem.Click
        If Player.Volume < 0 Then
            Player.Volume -= 100
        End If
    End Sub

    Private Sub BalanceLeftToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                   ByVal e As System.EventArgs) _
                                                   Handles BalanceLeftToolStripMenuItem.Click
        If Player.Balance > 0 Then
            Player.Balance = -100
        End If
    End Sub

    Private Sub BalanceEqualToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                    ByVal e As System.EventArgs) _
                                                    Handles BalanceEqualToolStripMenuItem.Click
        Player.Balance = 500
    End Sub

    Private Sub BalanceRightToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                    ByVal e As System.EventArgs) _
                                                    Handles BalanceRightToolStripMenuItem.Click
        If Player.Balance < 1000 Then
            Player.Balance += 100
        End If
    End Sub

    Private Sub MuteLeftToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                ByVal e As System.EventArgs) _
                                                Handles MuteLeftToolStripMenuItem.Click
        Player.Mute = (MuteLeftToolStripMenuItem.Checked And mPlayerControl.Channels.Left) _
        Or (MuteRightToolStripMenuItem.Checked And mPlayerControl.Channels.Right)
    End Sub

    Private Sub MuteRightToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                 ByVal e As System.EventArgs) _
                                                 Handles MuteRightToolStripMenuItem.Click
        Player.Mute = (MuteLeftToolStripMenuItem.Checked And mPlayerControl.Channels.Left) _
        Or (MuteRightToolStripMenuItem.Checked And mPlayerControl.Channels.Right)
    End Sub

    Private Sub TrackBar_Scroll(ByVal sender As System.Object, _
                                ByVal e As System.EventArgs) _
                                Handles TrackBar.Scroll
        Dim Mute As mPlayerControl.Channels = Player.Mute
        Player.Mute = mPlayerControl.Channels.Both ' Mute for Scroll
        Player.MoveToTime(TrackBar.Value) ' Move to Time
        Player.Mute = Mute ' Restore Previous Mute Value after Scroll
    End Sub

    Private Sub Display_Tick(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs) _
                             Handles Display.Tick
        Dim TotalSeconds As Long = CLng(Player.TotalTime / 1000)
        Dim CurrentSecond As Long = Player.CurrentTime
        If CurrentSecond >= TrackBar.Minimum And CurrentSecond <= TrackBar.Maximum Then
            TrackBar.Value = CInt(CurrentSecond)
        Else
            TrackBar.Value = TrackBar.Minimum
        End If
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs) _
                             Handles MyBase.Load
        Me.Text = "mPlayer"
    End Sub
End Class

﻿Public Class frmMain

    Private WithEvents Slides As New Slides

    Private Sub BrowseToolStripMenuItem_Click(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) _
                                              Handles BrowseToolStripMenuItem.Click
        Dim Browse As New FolderBrowserDialog
        Browse.Description = "Select Photo Folder"
        If Browse.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            Try
                Slides.Browse(Browse.SelectedPath)
                If Slides.TotalImages >= 0 Then
                    TrackBar.Value = 0
                    TrackBar.Minimum = 0
                    TrackBar.Maximum = CInt(Slides.TotalImages)
                End If
                Slides.Play() ' Play Slideshow
                Me.Text = "Slide Show - " & Browse.SelectedPath
            Catch ex As Exception
                ' Do nothing on Exception
            End Try
        End If
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles ExitToolStripMenuItem.Click
        Dim Response As MsgBoxResult
        Response = MsgBox("Are you sure you want to Exit Slide Show?", _
                          MsgBoxStyle.Question + MsgBoxStyle.YesNo, _
                          "Slide Show")
        If Response = MsgBoxResult.Yes Then
            End
        End If
    End Sub

    Private Sub PlayPauseToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                 ByVal e As System.EventArgs) _
                                                 Handles PlayPauseToolStripMenuItem.Click
        If Slides.Playing Then
            If Slides.Paused Then
                Slides.Resume()
            Else
                Slides.Pause()
            End If
        Else
            Slides.Play()
        End If
    End Sub

    Private Sub StopToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles StopToolStripMenuItem.Click
        Slides.Stop()
    End Sub

    Private Sub SlowToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles SlowToolStripMenuItem.Click
        Slides.Speed = 3000
    End Sub

    Private Sub MediumToolStripMenuItem_Click(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) _
                                              Handles MediumToolStripMenuItem.Click
        Slides.Speed = 1500
    End Sub

    Private Sub FastToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles FastToolStripMenuItem.Click
        Slides.Speed = 500
    End Sub

    Private Sub RepeatToolStripMenuItem_Click(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) _
                                              Handles RepeatToolStripMenuItem.Click
        Slides.Repeat = RepeatToolStripMenuItem.Checked
    End Sub

    Private Sub TrackBar_Scroll(ByVal sender As System.Object, _
                                ByVal e As System.EventArgs) Handles TrackBar.Scroll
        Slides.Move(TrackBar.Value)
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = "Slide Show"
    End Sub

    Private Sub Slides_Slide(ByVal Filename As String) Handles Slides.Slide
        Viewer.ImageLocation = Filename
        TrackBar.Value = Slides.CurrentImage
    End Sub
End Class

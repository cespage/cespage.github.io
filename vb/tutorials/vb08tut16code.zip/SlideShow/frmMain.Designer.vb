﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Viewer = New System.Windows.Forms.PictureBox
        Me.TrackBar = New System.Windows.Forms.TrackBar
        Me.mnuSlides = New System.Windows.Forms.MenuStrip
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BrowseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SlidesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PlayPauseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.StopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripSeparator
        Me.SlowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MediumToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FastToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripSeparator
        Me.RepeatToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        CType(Me.Viewer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.mnuSlides.SuspendLayout()
        Me.SuspendLayout()
        '
        'Viewer
        '
        Me.Viewer.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Viewer.Location = New System.Drawing.Point(11, 35)
        Me.Viewer.Name = "Viewer"
        Me.Viewer.Size = New System.Drawing.Size(261, 175)
        Me.Viewer.TabIndex = 0
        Me.Viewer.TabStop = False
        '
        'TrackBar
        '
        Me.TrackBar.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TrackBar.Location = New System.Drawing.Point(0, 219)
        Me.TrackBar.Name = "TrackBar"
        Me.TrackBar.Size = New System.Drawing.Size(284, 45)
        Me.TrackBar.TabIndex = 1
        '
        'mnuSlides
        '
        Me.mnuSlides.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.SlidesToolStripMenuItem})
        Me.mnuSlides.Location = New System.Drawing.Point(0, 0)
        Me.mnuSlides.Name = "mnuSlides"
        Me.mnuSlides.Size = New System.Drawing.Size(284, 24)
        Me.mnuSlides.TabIndex = 2
        Me.mnuSlides.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BrowseToolStripMenuItem, Me.ToolStripMenuItem1, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'BrowseToolStripMenuItem
        '
        Me.BrowseToolStripMenuItem.Name = "BrowseToolStripMenuItem"
        Me.BrowseToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.B), System.Windows.Forms.Keys)
        Me.BrowseToolStripMenuItem.Size = New System.Drawing.Size(162, 22)
        Me.BrowseToolStripMenuItem.Text = "Browse..."
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(149, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'SlidesToolStripMenuItem
        '
        Me.SlidesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PlayPauseToolStripMenuItem, Me.StopToolStripMenuItem, Me.ToolStripMenuItem2, Me.SlowToolStripMenuItem, Me.MediumToolStripMenuItem, Me.FastToolStripMenuItem, Me.ToolStripMenuItem3, Me.RepeatToolStripMenuItem})
        Me.SlidesToolStripMenuItem.Name = "SlidesToolStripMenuItem"
        Me.SlidesToolStripMenuItem.Size = New System.Drawing.Size(49, 20)
        Me.SlidesToolStripMenuItem.Text = "Slides"
        '
        'PlayPauseToolStripMenuItem
        '
        Me.PlayPauseToolStripMenuItem.Name = "PlayPauseToolStripMenuItem"
        Me.PlayPauseToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.P), System.Windows.Forms.Keys)
        Me.PlayPauseToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.PlayPauseToolStripMenuItem.Text = "Play/Pause"
        '
        'StopToolStripMenuItem
        '
        Me.StopToolStripMenuItem.Name = "StopToolStripMenuItem"
        Me.StopToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.StopToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.StopToolStripMenuItem.Text = "Stop"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(149, 6)
        '
        'SlowToolStripMenuItem
        '
        Me.SlowToolStripMenuItem.Name = "SlowToolStripMenuItem"
        Me.SlowToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.SlowToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.SlowToolStripMenuItem.Text = "Slow"
        '
        'MediumToolStripMenuItem
        '
        Me.MediumToolStripMenuItem.Name = "MediumToolStripMenuItem"
        Me.MediumToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.M), System.Windows.Forms.Keys)
        Me.MediumToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.MediumToolStripMenuItem.Text = "Medium"
        '
        'FastToolStripMenuItem
        '
        Me.FastToolStripMenuItem.Name = "FastToolStripMenuItem"
        Me.FastToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.F), System.Windows.Forms.Keys)
        Me.FastToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.FastToolStripMenuItem.Text = "Fast"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(149, 6)
        '
        'RepeatToolStripMenuItem
        '
        Me.RepeatToolStripMenuItem.CheckOnClick = True
        Me.RepeatToolStripMenuItem.Name = "RepeatToolStripMenuItem"
        Me.RepeatToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.T), System.Windows.Forms.Keys)
        Me.RepeatToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.RepeatToolStripMenuItem.Text = "Repeat"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 264)
        Me.Controls.Add(Me.TrackBar)
        Me.Controls.Add(Me.Viewer)
        Me.Controls.Add(Me.mnuSlides)
        Me.MainMenuStrip = Me.mnuSlides
        Me.Name = "frmMain"
        Me.Text = "Form1"
        CType(Me.Viewer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar, System.ComponentModel.ISupportInitialize).EndInit()
        Me.mnuSlides.ResumeLayout(False)
        Me.mnuSlides.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Viewer As System.Windows.Forms.PictureBox
    Friend WithEvents TrackBar As System.Windows.Forms.TrackBar
    Friend WithEvents mnuSlides As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BrowseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SlidesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PlayPauseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StopToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SlowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MediumToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FastToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents RepeatToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class

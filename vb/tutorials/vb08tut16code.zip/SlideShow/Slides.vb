﻿Public Class Slides

    ' Private Members

    Private WithEvents sDisplay As New Timer
    Private sImages As New ArrayList
    Private sBrowseSuccess As Boolean
    Private sInterval As Integer = 1500
    Private sTotalImages As Integer = 0
    Private sCurrent As Integer = 0
    Private sPlaying As Boolean
    Private sPaused As Boolean
    Private sRepeat As Boolean

    ' Private Methods

    ''' <summary>Get Files as ArrayList</summary>
    ''' <param name="Path">Path to Look through</param>
    ''' <param name="Filter">Files to Look for</param>
    Private Function Files(ByRef Path As String, _
                           ByRef Filter As String) As ArrayList
        Dim alFiles As New ArrayList
        Dim dirInfo As New IO.DirectoryInfo(Path)
        If dirInfo.Exists Then ' Check Path Exists
            Dim dirFiles As IO.FileInfo() = dirInfo.GetFiles("*.*")
            ' Loop through the Path for Files by Filter
            For Each fileinfo As IO.FileInfo In dirFiles
                If InStr(Filter, fileinfo.Extension, CompareMethod.Text) > 0 Then
                    alFiles.Add(fileinfo.FullName) ' Add to ArrayList
                End If
            Next
        End If
        Return alFiles
    End Function

    ' Constructor

    Public Sub New()
        sDisplay.Enabled = False
        sDisplay.Interval = sInterval
    End Sub

    ' Public Methods

    ''' <summary>Browse Folder for Photos</summary>  
    ''' <param name="Path">The Path of the Folder</param>  
    ''' <returns>True if Photos Present, False if None</returns>
    Public Function [Browse](ByVal Path As String) As Boolean
        sImages.Clear() ' Clear Images List
        sImages = Files(Path, ".jpg.png.gif.bmp.jpeg")
        sTotalImages = sImages.Count - 1 ' Get Total Images
        If sTotalImages > 0 Then ' Photos Found
            sBrowseSuccess = True
            Return True
        Else
            Return False ' No Photos Found
        End If
    End Function

    ''' <summary>Play Slideshow</summary>  
    Public Function [Play]() As Boolean
        If sBrowseSuccess Then
            sPlaying = True
            sDisplay.Enabled = True
            If sPaused Then
                Me.Pause()
            Else
                sPaused = False
            End If
        End If
    End Function

    ''' <summary>Stop Slideshow</summary> 
    Public Function [Stop]() As Boolean
        If sBrowseSuccess Then
            sDisplay.Enabled = False
            sCurrent = 0
            sPlaying = False
            sPaused = False
        End If
        Return False
    End Function

    ''' <summary>Pause Slideshow</summary>
    Public Function [Pause]() As Boolean
        If sBrowseSuccess Then
            sDisplay.Enabled = False
            sPaused = Not sDisplay.Enabled
            Return sPaused
        End If
        Return False
    End Function

    ''' <summary>Resume Slideshow</summary>
    Public Function [Resume]() As Boolean
        If sBrowseSuccess And sPaused Then
            sDisplay.Enabled = True
            sPaused = Not sDisplay.Enabled
            Return sPaused
        End If
        Return False
    End Function

    ''' <summary>Move to Index</summary>
    ''' <param name="Index">Index to Move to</param>
    Public Function [Move](ByVal Index As Integer) As Boolean
        If sBrowseSuccess Then
            If Index < sImages.Count Then
                sCurrent = Index
                If sPlaying Then
                    Me.Play()
                End If
            End If
        End If
    End Function

    ' Public Properties

    ''' <summary>Repeat Slideshow</summary>
    Public Property Repeat() As Boolean
        Get
            Return sRepeat
        End Get
        Set(ByVal Value As Boolean)
            If sRepeat <> Value Then
                sRepeat = Value
            End If
        End Set
    End Property

    ''' <summary>Playback Speed in Milliseconds, 500-3000 where 1500 is normal</summary>
    Public Property Speed() As Integer
        Get
            Return sInterval
        End Get
        Set(ByVal Value As Integer)
            If Value >= 500 And Value < 3000 And Value <> sInterval Then
                sInterval = Value
                sDisplay.Interval = sInterval
            End If
        End Set
    End Property

    ''' <summary>Total Images in Slideshow</summary>
    Public ReadOnly Property TotalImages() As Integer
        Get
            Return sTotalImages
        End Get
    End Property

    ''' <summary>Current Image in Slideshow</summary>
    Public ReadOnly Property CurrentImage() As Integer
        Get
            Return sCurrent
        End Get
    End Property

    ''' <summary>Is Slideshow Playing?</summary>
    Public ReadOnly Property Playing() As Boolean
        Get
            Return sPlaying
        End Get
    End Property

    ''' <summary>Is Slideshow Paused?</summary>
    Public ReadOnly Property Paused() As Boolean
        Get
            Return sPaused
        End Get
    End Property

    ' Timer

    Private Sub sDisplay_Tick(ByVal sender As Object, _
                              ByVal e As System.EventArgs) _
                              Handles sDisplay.Tick
        If sBrowseSuccess And sPlaying Then
            If sCurrent < sImages.Count Then
                RaiseEvent Slide(CStr(sImages.Item(sCurrent)))
                sCurrent += 1
            Else
                If sRepeat Then
                    sCurrent = 0 ' Reset if Repeat
                End If
            End If
        End If
    End Sub

    ' Event

    Public Event Slide(ByVal Filename As String)

End Class

Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, _
                              ByVal e As System.EventArgs) _
                              Handles Button1.Click
        Dim Open As New OpenFileDialog()
        Dim myStreamReader As System.IO.StreamReader
        Open.Filter = "Plain Text Files (*.txt)|*.txt|All files (*.*)|*.*"
        Open.CheckFileExists = True
        Open.Title = "Open"
        Open.ShowDialog(Me)
        Try
            Open.OpenFile()
            myStreamReader = System.IO.File.OpenText(Open.FileName)
            TextBox1.Text = myStreamReader.ReadToEnd()
        Catch ex As Exception
            ' Do nothing on Exception
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, _
                              ByVal e As System.EventArgs) _
                              Handles Button2.Click
        Dim Save As New SaveFileDialog()
        Dim myStreamWriter As System.IO.StreamWriter
        Save.Filter = "Plain Text Files (*.txt)|*.txt|All files (*.*)|*.*"
        Save.CheckPathExists = True
        Save.Title = "Save"
        Save.ShowDialog(Me)
        Try
            myStreamWriter = System.IO.File.AppendText(Save.FileName)
            myStreamWriter.Write(TextBox1.Text)
            myStreamWriter.Flush()
        Catch ex As Exception
            ' Do Nothing
        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, _
                              ByVal e As System.EventArgs) _
                              Handles Button3.Click
        End
    End Sub
End Class

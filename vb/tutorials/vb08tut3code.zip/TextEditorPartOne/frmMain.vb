﻿Public Class frmMain

    Private Sub NewToolStripMenuItem_Click(ByVal sender As System.Object, _
                                           ByVal e As System.EventArgs) _
                                           Handles NewToolStripMenuItem.Click
        Dim Response As MsgBoxResult
        Response = MsgBox("Are you sure you want to start a New Document?", _
                          MsgBoxStyle.Question + MsgBoxStyle.YesNo, _
                          "Text Editor")
        If Response = MsgBoxResult.Yes Then
            txtEditor.Text = ""
            Me.Text = "Text Editor - Untitled"
        End If
    End Sub

    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles OpenToolStripMenuItem.Click
        Dim Open As New OpenFileDialog()
        Dim myStreamReader As System.IO.StreamReader
        Open.Filter = "Plain Text Files (*.txt)|*.txt|All files (*.*)|*.*"
        Open.CheckFileExists = True
        Open.ShowDialog(Me)
        Try
            Open.OpenFile()
            myStreamReader = System.IO.File.OpenText(Open.FileName)
            txtEditor.Text = myStreamReader.ReadToEnd()
            Me.Text = "Text Editor - " & Open.FileName
        Catch ex As Exception
            ' Do nothing on Exception
        End Try
    End Sub

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles SaveToolStripMenuItem.Click
        Dim Save As New SaveFileDialog()
        Dim myStreamWriter As System.IO.StreamWriter
        Save.Filter = "Plain Text Files (*.txt)|*.txt|All files (*.*)|*.*"
        Save.CheckPathExists = True
        Save.ShowDialog(Me)
        Try
            myStreamWriter = System.IO.File.CreateText(Save.FileName)
            myStreamWriter.Write(txtEditor.Text)
            myStreamWriter.Flush()
            Me.Text = "Text Editor - " & Save.FileName
        Catch ex As Exception
            ' Do nothing on Exception
        End Try
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles ExitToolStripMenuItem.Click
        Dim Response As MsgBoxResult
        Response = MsgBox("Are you sure you want to Exit Text Editor?", _
                          MsgBoxStyle.Question + MsgBoxStyle.YesNo, _
                          "Text Editor")
        If Response = MsgBoxResult.Yes Then
            End
        End If
    End Sub

    Private Sub CutToolStripMenuItem_Click(ByVal sender As System.Object, _
                                           ByVal e As System.EventArgs) _
                                           Handles CutToolStripMenuItem.Click
        txtEditor.Cut()
    End Sub

    Private Sub CopyToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles CopyToolStripMenuItem.Click
        txtEditor.Copy()
    End Sub

    Private Sub PasteToolStripMenuItem_Click(ByVal sender As System.Object, _
                                             ByVal e As System.EventArgs) _
                                             Handles PasteToolStripMenuItem.Click
        txtEditor.Paste()
    End Sub

    Private Sub DeleteToolStripMenuItem_Click(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) _
                                              Handles DeleteToolStripMenuItem.Click
        txtEditor.SelectedText = ""
    End Sub

    Private Sub SelectAllToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                 ByVal e As System.EventArgs) _
                                                 Handles SelectAllToolStripMenuItem.Click
        txtEditor.SelectAll()
    End Sub

    Private Sub TimeDateToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                ByVal e As System.EventArgs) _
                                                Handles TimeDateToolStripMenuItem.Click
        txtEditor.SelectedText = Format(Now, "HH:mm dd/MM/yyyy")
    End Sub

    Private Sub FontToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles FontToolStripMenuItem.Click
        Dim Font As New FontDialog()
        Font.Font = txtEditor.Font
        Font.ShowDialog(Me)
        Try
            txtEditor.Font = Font.Font
        Catch ex As Exception
            ' Do nothing on Exception
        End Try
    End Sub

    Private Sub ColourToolStripMenuItem_Click(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) _
                                              Handles ColourToolStripMenuItem.Click
        Dim Colour As New ColorDialog()
        Colour.Color = txtEditor.ForeColor
        Colour.ShowDialog(Me)
        Try
            txtEditor.ForeColor = Colour.Color
        Catch ex As Exception
            ' Do nothing on Exception
        End Try
    End Sub

    Private Sub BackgroundToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                  ByVal e As System.EventArgs) _
                                                  Handles BackgroundToolStripMenuItem.Click
        Dim Colour As New ColorDialog()
        Colour.Color = txtEditor.BackColor
        Colour.ShowDialog(Me)
        Try
            txtEditor.BackColor = Colour.Color
        Catch ex As Exception
            ' Do nothing on Exception
        End Try
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs) _
                             Handles MyBase.Load
        txtEditor.Text = ""
        Me.Text = "Text Editor - Untitled"
    End Sub
End Class

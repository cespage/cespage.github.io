﻿Public Class frmMain

    ' API Methods

    Public Declare Function IsWindowVisible Lib "user32.dll" _
    Alias "IsWindowVisible" (ByVal hwnd As Integer) As Boolean

    Public Declare Function GetWindow Lib "user32.dll" _
    Alias "GetWindow" (ByVal hwnd As Integer, _
                       ByVal wCmd As Integer) As Integer

    Public Declare Function GetWindowLong Lib "user32.dll" _
    Alias "GetWindowLongA" (ByVal hwnd As Integer, _
                            ByVal nIndex As Integer) As Integer

    Public Declare Function GetParent Lib "user32.dll" _
    Alias "GetParent" (ByVal hwnd As Integer) As Integer

    Public Declare Function SetForegroundWindow Lib "user32.dll" _
    Alias "SetForegroundWindow" (ByVal hwnd As Integer) As Integer

    ' Declarations

    Private RowOne As String() = {"`", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "="}
    Private RowTwo As String() = {"q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "[", "]"}
    Private RowThree As String() = {"a", "s", "d", "f", "g", "h", "j", "k", "l", ";", "'", "#"}
    Private RowFour As String() = {"\", "z", "x", "c", "v", "b", "n", "m", ",", ".", "/"}
    Private CapsLock As New CheckBox
    Private Key, Special As String
    Private Windows As New ArrayList
    Private Window As IntPtr

    ' Event Handlers

    Private Sub Key_Special(ByVal Sender As Button, _
                            ByVal e As System.EventArgs)
        If Special = "" Then
            Special = Sender.Tag
        Else
            Special = ""
        End If
    End Sub

    Private Sub Key_Click(ByVal Sender As Button, _
                          ByVal e As System.EventArgs)
        Key = Sender.Tag
        If Key = "{SPACE}" Then Key = " " 'Convert {SPACE} to Space
        If Window <> 0 Then
            SetForegroundWindow(Window)
            SendKeys.SendWait(Special & IIf(Capslock.Checked _
                                            And Not Special <> "^", _
                                            UCase(Key), Key))
            SetForegroundWindow(Window)
        End If
    End Sub

    ' Private Methods

    Private Function IsActiveWindow(ByVal hWnd As Integer) As Boolean
        Dim IsOwned As Boolean
        Dim Style As Integer
        IsOwned = GetWindow(hWnd, 4) <> 0
        Style = GetWindowLong(hWnd, -20)
        If Not IsWindowVisible(hWnd) Then Return False ' Not Visible
        If GetParent(hWnd) <> 0 Then Return False ' Has Parent
        If (Style And &H80) <> 0 And Not IsOwned Then Return False ' Is Tooltip
        If (Style And &H40000) = 0 And IsOwned Then Return False ' Has Owner
        If Process.GetCurrentProcess.MainWindowHandle = hWnd Then Return False
        Return True ' Window Valid
    End Function

    Private Sub KeyboardButton(ByVal Width As Integer, ByVal Height As Integer, _
                               ByVal Top As Integer, ByVal Left As Integer, _
                               Optional ByVal Text As String = "", _
                               Optional ByVal Tag As String = "", _
                               Optional ByVal Special As Boolean = False)
        Dim Button As New Button
        Button.Size = New Size(Width, Height)
        Button.Location = New Point(Left, Top)
        Button.Text = Text
        Button.Tag = Tag
        If Special Then
            AddHandler Button.Click, AddressOf Key_Special
        Else
            AddHandler Button.Click, AddressOf Key_Click
        End If
        Controls.Add(Button)
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs) _
                             Handles MyBase.Load
        Dim Col As Integer
        ' Row One
        For Col = 0 To 12
            KeyboardButton(25, 25, 40, Col * 25 + 4, _
                           RowOne(Col), RowOne(Col))
        Next
        KeyboardButton(50, 25, 40, Col * 25 + 4, "BkSp", "{BACKSPACE}")
        ' Row Two
        KeyboardButton(36, 25, 66, 4, "Tab", "{TAB}")
        For Col = 0 To 11
            KeyboardButton(25, 25, 66, Col * 25 + 40, _
                           UCase(RowTwo(Col)), RowTwo(Col))
        Next
        KeyboardButton(39, 25, 66, 36 + Col * 25 + 4, "↵", "{ENTER}")
        ' Row Three
        CapsLock.Appearance = Appearance.Button
        CapsLock.Size = New Size(48, 25)
        CapsLock.Location = New Point(4, 92)
        CapsLock.Text = "Caps"
        Controls.Add(CapsLock)
        For Col = 0 To 11
            KeyboardButton(25, 25, 92, Col * 25 + 52, _
                           UCase(RowThree(Col)), RowThree(Col))
        Next
        KeyboardButton(27, 25, 92, 48 + Col * 25 + 4, "", "{ENTER}")
        ' Row Four
        KeyboardButton(38, 25, 118, 4, "Shift", "+", True)
        For Col = 0 To 10
            KeyboardButton(25, 25, 118, Col * 25 + 42, _
                           UCase(RowFour(Col)), RowFour(Col))
        Next
        KeyboardButton(62, 25, 118, Col * 25 + 42, "Shift", "+", True)
        ' Row Five
        KeyboardButton(50, 25, 144, 4, "Ctrl", "^", True)
        KeyboardButton(50, 25, 144, 54, "Alt", "%", True)
        KeyboardButton(154, 25, 144, 104, "Space", "{SPACE}")
        KeyboardButton(44, 25, 144, 258, "Home", "{HOME}")
        KeyboardButton(44, 25, 144, 302, "End", "{END}")
        KeyboardButton(33, 25, 144, 346, "Del", "{DEL}")
    End Sub

    Private Sub cboWindows_DropDown(ByVal sender As Object, _
                                    ByVal e As System.EventArgs) _
                                    Handles cboWindows.DropDown
        Windows.Clear()
        cboWindows.Items.Clear()
        For Each Item As Process In Process.GetProcesses
            If IsActiveWindow(Item.MainWindowHandle) _
            And Item.MainWindowTitle <> "" Then
                Windows.Add(Item.MainWindowHandle)
                cboWindows.Items.Add(Item.MainWindowTitle)
            End If
        Next
    End Sub

    Private Sub cboWindows_SelectedIndexChanged(ByVal sender As Object, _
                                                ByVal e As System.EventArgs) _
                                                Handles cboWindows.SelectedIndexChanged
        If cboWindows.SelectedItem <> Nothing Then
            Window = Windows.Item(cboWindows.SelectedIndex)
        End If
    End Sub
End Class

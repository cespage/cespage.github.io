﻿Public Class frmMain

    Private Sub NewToolStripMenuItem_Click(ByVal sender As System.Object, _
                                           ByVal e As System.EventArgs) _
                                           Handles NewToolStripMenuItem.Click
        Dim Response As MsgBoxResult
        Response = MsgBox("Are you sure you want to start a New Document?", _
                          MsgBoxStyle.Question + MsgBoxStyle.YesNo, _
                          "Rich Text Editor")
        If Response = MsgBoxResult.Yes Then
            rtbEditor.Clear()
            Me.Text = "Rich Text Editor - Untitled"
        End If
    End Sub

    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles OpenToolStripMenuItem.Click
        Dim Open As New OpenFileDialog()
        Open.Filter = "Rich Text Document (*.rtf)|*.rtf|All files (*.*)|*.*"
        Open.CheckFileExists = True
        If Open.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            Try
                rtbEditor.LoadFile(Open.FileName)
                Me.Text = "Rich Text Editor - " & Open.FileName
            Catch ex As Exception
                ' Do nothing on Exception
            End Try
        End If
    End Sub

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles SaveToolStripMenuItem.Click
        Dim Save As New SaveFileDialog()
        Save.Filter = "Rich Text Document (*.rtf)|*.rtf|All files (*.*)|*.*"
        Save.CheckPathExists = True
        If Save.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            Try
                rtbEditor.SaveFile(Save.FileName)
                Me.Text = "Rich Text Editor - " & Save.FileName
            Catch ex As Exception
                ' Do nothing on Exception
            End Try
        End If
    End Sub

    Private Sub PrintToolStripMenuItem_Click(ByVal sender As System.Object, _
                                             ByVal e As System.EventArgs) _
                                             Handles PrintToolStripMenuItem.Click
        Dim PrintDialog As New PrintDialog()
        PrintDialog.Document = rtbEditor.PrintDocument
        If PrintDialog.ShowDialog(Me) = DialogResult.OK Then
            Try
                rtbEditor.PrintDocument.Print() ' Print Document
            Catch ex As Exception
                ' Do nothing on Exception
            End Try
        End If
    End Sub

    Private Sub PrintPreviewToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                    ByVal e As System.EventArgs) _
                                                    Handles PrintPreviewToolStripMenuItem.Click
        Dim PrintPreview As New PrintPreviewDialog()
        PrintPreview.Document = rtbEditor.PrintDocument
        PrintPreview.ShowDialog(Me)
    End Sub

    Private Sub PageSetupToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                 ByVal e As System.EventArgs) Handles _
                                                 PageSetupToolStripMenuItem.Click
        Dim PageSetup As New PageSetupDialog
        PageSetup.Document = rtbEditor.PrintDocument
        If PageSetup.ShowDialog(Me) = DialogResult.OK Then
            Try
                rtbEditor.PrintDocument.PrinterSettings = _
                PageSetup.PrinterSettings ' Set Page Settings
            Catch ex As Exception
                ' Do nothing on Exception
            End Try
        End If
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles ExitToolStripMenuItem.Click
        Dim Response As MsgBoxResult
        Response = MsgBox("Are you sure you want to Exit Rich Text Editor?", _
                          MsgBoxStyle.Question + MsgBoxStyle.YesNo, _
                          "Rich Text Editor")
        If Response = MsgBoxResult.Yes Then
            End
        End If
    End Sub

    Private Sub CutToolStripMenuItem_Click(ByVal sender As System.Object, _
                                           ByVal e As System.EventArgs) _
                                           Handles CutToolStripMenuItem.Click
        rtbEditor.Cut()
    End Sub

    Private Sub CopyToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles CopyToolStripMenuItem.Click
        rtbEditor.Copy()
    End Sub

    Private Sub PasteToolStripMenuItem_Click(ByVal sender As System.Object, _
                                             ByVal e As System.EventArgs) _
                                             Handles PasteToolStripMenuItem.Click
        rtbEditor.Paste()
    End Sub

    Private Sub DeleteToolStripMenuItem_Click(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) _
                                              Handles DeleteToolStripMenuItem.Click
        rtbEditor.SelectedText = ""
    End Sub

    Private Sub SelectAllToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                 ByVal e As System.EventArgs) _
                                                 Handles SelectAllToolStripMenuItem.Click
        rtbEditor.SelectAll()
    End Sub

    Private Sub TimeDateToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                ByVal e As System.EventArgs) _
                                                Handles TimeDateToolStripMenuItem.Click
        rtbEditor.SelectedText = Format(Now, "HH:mm dd/MM/yyyy")
    End Sub

    Private Sub FontToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles FontToolStripMenuItem.Click
        Dim Font As New FontDialog()
        Font.Font = rtbEditor.SelectionFont
        If Font.ShowDialog(Me) = DialogResult.OK Then
            Try
                rtbEditor.SelectionFont = Font.Font
            Catch ex As Exception
                ' Do nothing on Exception
            End Try
        End If
    End Sub

    Private Sub ColourToolStripMenuItem_Click(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) _
                                              Handles ColourToolStripMenuItem.Click
        Dim Colour As New ColorDialog()
        Colour.Color = rtbEditor.SelectionColor
        If Colour.ShowDialog(Me) = DialogResult.OK Then
            Try
                rtbEditor.SelectionColor = Colour.Color
            Catch ex As Exception
                ' Do nothing on Exception
            End Try
        End If
    End Sub

    Private Sub HighlightToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                 ByVal e As System.EventArgs) _
                                                 Handles HighlightToolStripMenuItem.Click
        Dim Colour As New ColorDialog()
        Colour.Color = rtbEditor.SelectionBackColor
        If Colour.ShowDialog(Me) = DialogResult.OK Then
            Try
                rtbEditor.SelectionBackColor = Colour.Color
            Catch ex As Exception
                ' Do nothing on Exception
            End Try
        End If
    End Sub

    Private Sub AlignLeftToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                 ByVal e As System.EventArgs) _
                                                 Handles AlignLeftToolStripMenuItem.Click
        rtbEditor.SelectionAlignment = HorizontalAlignment.Left
        AlignLeftToolStripMenuItem.Checked = True
        AlignCentreToolStripMenuItem.Checked = False
        AlignRightToolStripMenuItem.Checked = False
    End Sub

    Private Sub AlignCentreToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                   ByVal e As System.EventArgs) _
                                                   Handles AlignCentreToolStripMenuItem.Click
        rtbEditor.SelectionAlignment = HorizontalAlignment.Center
        AlignLeftToolStripMenuItem.Checked = False
        AlignCentreToolStripMenuItem.Checked = True
        AlignRightToolStripMenuItem.Checked = False
    End Sub

    Private Sub AlignRightToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                  ByVal e As System.EventArgs) _
                                                  Handles AlignRightToolStripMenuItem.Click
        rtbEditor.SelectionAlignment = HorizontalAlignment.Right
        AlignLeftToolStripMenuItem.Checked = False
        AlignCentreToolStripMenuItem.Checked = False
        AlignRightToolStripMenuItem.Checked = True
    End Sub

    Private Sub BoldToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles BoldToolStripMenuItem.Click
        If rtbEditor.SelectionFont.Bold Then
            rtbEditor.SelectionFont = New Font(rtbEditor.SelectionFont, _
                                               rtbEditor.SelectionFont.Style And Not FontStyle.Bold)
        Else
            rtbEditor.SelectionFont = New Font(rtbEditor.SelectionFont, _
                                               rtbEditor.SelectionFont.Style Or FontStyle.Bold)
        End If
        BoldToolStripMenuItem.Checked = rtbEditor.SelectionFont.Bold
    End Sub

    Private Sub ItalicsToolStripMenuItem_Click(ByVal sender As System.Object, _
                                               ByVal e As System.EventArgs) _
                                               Handles ItalicsToolStripMenuItem.Click
        If rtbEditor.SelectionFont.Italic Then
            rtbEditor.SelectionFont = New Font(rtbEditor.SelectionFont, _
                                               rtbEditor.SelectionFont.Style And Not FontStyle.Italic)
        Else
            rtbEditor.SelectionFont = New Font(rtbEditor.SelectionFont, _
                                               rtbEditor.SelectionFont.Style Or FontStyle.Italic)
        End If
        ItalicsToolStripMenuItem.Checked = rtbEditor.SelectionFont.Italic
    End Sub

    Private Sub UnderlineToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                 ByVal e As System.EventArgs) _
                                                 Handles UnderlineToolStripMenuItem.Click
        If rtbEditor.SelectionFont.Underline Then
            rtbEditor.SelectionFont = New Font(rtbEditor.SelectionFont, _
                                               rtbEditor.SelectionFont.Style And Not FontStyle.Underline)
        Else
            rtbEditor.SelectionFont = New Font(rtbEditor.SelectionFont, _
                                               rtbEditor.SelectionFont.Style Or FontStyle.Underline)
        End If
        UnderlineToolStripMenuItem.Checked = rtbEditor.SelectionFont.Underline
    End Sub

    Private Sub BulletsToolStripMenuItem_Click(ByVal sender As System.Object, _
                                               ByVal e As System.EventArgs) _
                                               Handles BulletsToolStripMenuItem.Click
        rtbEditor.SelectionBullet = Not rtbEditor.SelectionBullet
        BulletsToolStripMenuItem.Checked = rtbEditor.SelectionBullet
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs) _
                             Handles MyBase.Load
        AlignLeftToolStripMenuItem.Checked = True
        Me.Text = "Rich Text Editor - Untitled"
    End Sub

    Private Sub rtbEditor_SelectionChanged(ByVal sender As Object, _
                                           ByVal e As System.EventArgs) _
                                           Handles rtbEditor.SelectionChanged
        AlignLeftToolStripMenuItem.Checked = False
        AlignCentreToolStripMenuItem.Checked = False
        AlignRightToolStripMenuItem.Checked = False
        Select Case rtbEditor.SelectionAlignment
            Case HorizontalAlignment.Left
                AlignLeftToolStripMenuItem.Checked = True
            Case HorizontalAlignment.Center
                AlignCentreToolStripMenuItem.Checked = True
            Case HorizontalAlignment.Right
                AlignRightToolStripMenuItem.Checked = True
        End Select
        BoldToolStripMenuItem.Checked = rtbEditor.SelectionFont.Bold
        ItalicsToolStripMenuItem.Checked = rtbEditor.SelectionFont.Italic
        UnderlineToolStripMenuItem.Checked = rtbEditor.SelectionFont.Underline
        BulletsToolStripMenuItem.Checked = rtbEditor.SelectionBullet
    End Sub
End Class

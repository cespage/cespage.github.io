﻿Class Window1 
    Private Sub Draw(ByRef StackPanel As StackPanel, ByRef Values As ArrayList)
        StackPanel.Children.Clear() ' Clear the Stack Panel
        For Each Value As Integer In Values
            Dim Ball As New Ellipse
            Dim Brush As New VisualBrush
            Dim Colour As New SolidColorBrush
            Dim Detail As New StackPanel
            Dim Text As New TextBlock
            Dim FontSize As New FontSizeConverter
            If Value > 0 And Value < 10 Then
                Colour = Brushes.White
            ElseIf Value >= 10 And Value < 20 Then
                Colour = Brushes.SkyBlue
            ElseIf Value >= 20 And Value < 30 Then
                Colour = Brushes.Magenta
            ElseIf Value >= 30 And Value < 40 Then
                Colour = Brushes.LawnGreen
            ElseIf Value >= 40 Then
                Colour = Brushes.Yellow
            End If
            Detail.Background = Colour ' Ball Colour
            Text.Text = Value ' Ball Value
            Text.FontSize = CDbl(FontSize.ConvertFromString("12pt"))
            Text.Margin = New Thickness(10)
            Detail.Children.Add(Text)
            Brush.Visual = Detail
            Ball.Height = 40
            Ball.Width = 40
            Ball.Fill = Brush
            Ball.BitmapEffect = _
            New Windows.Media.Effects.DropShadowBitmapEffect
            Ball.Margin = New Thickness(2)
            StackPanel.Children.Add(Ball)
        Next
    End Sub

    Private Sub Choose()
        Dim Numbers As New ArrayList
        Dim Number As Integer
        While Numbers.Count < 6 ' Select 6 Numbers
            Randomize()
            Number = Int((49 * Rnd()) + 1) '  Random Number 1 - 49
            If Not Numbers.Contains(Number) _
            Or Numbers.Count < 1 Then ' If chosen or none
                Numbers.Add(Number) ' Add Number
            End If
        End While
        Draw(LottoLayout, Numbers)
    End Sub

    Private Sub btnChoose_Click(ByVal sender As System.Object, _
                                ByVal e As System.Windows.RoutedEventArgs) _
                                Handles btnChoose.Click
        Choose()
    End Sub
End Class

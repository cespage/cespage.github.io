﻿Class Window1 
    Private Const CLUBS As String = "♣"
    Private Const DIAMONDS As String = "♦"
    Private Const HEARTS As String = "♥"
    Private Const SPADES As String = "♠"
    Private Const ACE As String = "A"
    Private Const JACK As String = "J"
    Private Const QUEEN As String = "Q"
    Private Const KING As String = "K"

    Private WithEvents btn1, btn2 As New Button
    Private DeckOne, DeckTwo As New ArrayList
    Private CardOne, CardTwo As Integer
    Private FirstChoice, SecondChoice As Integer
    Private Score As Integer = 0
    Private Counter As Integer = 0

    Private Function Deck(ByRef Card As Integer) As Object
        Dim Display As Integer = 0
        Dim Suite As String = ""
        Dim Value As String = ""
        Dim CardBrush As SolidColorBrush = Brushes.Black
        Dim CardPath As New Path
        Dim CardGroup As New GeometryGroup
        Dim CardItem As FormattedText = Nothing
        Dim Culture As Globalization.CultureInfo = _
        Globalization.CultureInfo.GetCultureInfo("en-us")
        Dim Flow As Windows.FlowDirection = _
        Windows.FlowDirection.LeftToRight
        Dim Serif As New Typeface("Times New Roman")
        Dim SanSerif As New Typeface("Arial")
        If Card >= 1 And Card <= 13 Then
            CardBrush = Brushes.Black
            Suite = CLUBS
            Display = Card
        ElseIf Card >= 14 And Card <= 26 Then
            CardBrush = Brushes.Red
            Suite = DIAMONDS
            Display = Card - 13
        ElseIf Card >= 27 And Card <= 39 Then
            CardBrush = Brushes.Red
            Suite = HEARTS
            Display = Card - 26
        ElseIf Card >= 40 And Card <= 52 Then
            CardBrush = Brushes.Black
            Suite = SPADES
            Display = Card - 39
        End If
        Dim CardFace As New FormattedText(Suite, Culture, Flow, SanSerif, 40, Brushes.Black)
        Value = Display
        CardPath.Width = 124
        CardPath.Height = 222
        CardPath.Fill = CardBrush
        Select Case Display
            Case 1
                Value = ACE
                CardItem = New FormattedText(Suite, Culture, Flow, SanSerif, 72, Brushes.Black)
                CardGroup.Children.Add(CardItem.BuildGeometry(New Point(36, 34))) ' Middle
            Case 2
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(46, 0))) ' Centre Top
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(46, 104))) ' Centre Bottom
            Case 3
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(46, 0))) ' Centre Top
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(46, 52))) ' Centre
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(46, 104))) ' Centre Bottom
            Case 4
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(18, 0))) ' Top Right
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(74, 0))) ' Top Left
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(18, 104))) ' Bottom Right
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(74, 104))) ' Bottom Left
            Case 5
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(18, 0))) ' Top Right
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(74, 0))) ' Top Left
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(46, 52))) ' Centre
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(18, 104))) ' Bottom Right
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(74, 104))) ' Bottom Left
            Case 6
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(18, 0))) ' Top Right
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(74, 0))) ' Top Left
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(18, 52))) ' Centre Left
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(74, 52))) ' Centre Right
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(18, 104))) ' Bottom Right
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(74, 104))) ' Bottom Left
            Case 7
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(18, 0))) ' Top Left
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(74, 0))) ' Top Right
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(18, 52))) ' Centre Left
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(46, 78))) ' Centre Bottom
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(74, 52))) ' Centre Right
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(18, 104))) ' Bottom Left
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(74, 104))) ' Bottom Right
            Case 8
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(18, 0))) ' Top Left
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(74, 0))) ' Top Right
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(18, 52))) ' Centre Left
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(46, 26))) ' Centre Top
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(46, 78))) ' Centre Bottom
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(74, 52))) ' Centre Right
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(18, 104))) ' Bottom Left
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(74, 104))) ' Bottom Right
            Case 9
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(18, 0))) ' Top Left
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(74, 0))) ' Top Right
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(18, 34))) ' Centre Left Top
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(18, 70))) ' Centre Left Bottom
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(46, 52))) ' Centre
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(74, 34))) ' Centre Right Top
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(74, 70))) ' Centre Right Bottom
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(18, 104))) ' Bottom Left
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(74, 104))) ' Bottom Right
            Case 10
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(18, 0))) ' Top Left
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(74, 0))) ' Top Right
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(18, 34))) ' Centre Left Top
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(18, 70))) ' Centre Left Bottom
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(46, 26))) ' Centre Top
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(46, 78))) ' Centre Bottom
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(74, 34))) ' Centre Right Top
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(74, 70))) ' Centre Right Bottom
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(18, 104))) ' Bottom Left
                CardGroup.Children.Add(CardFace.BuildGeometry(New Point(74, 104))) ' Bottom Right
            Case 11
                Value = JACK
                CardItem = New FormattedText(Value, Culture, Flow, Serif, 72, Brushes.Black)
                CardGroup.Children.Add(CardItem.BuildGeometry(New Point(44, 34))) ' Middle
            Case 12
                Value = QUEEN
                CardItem = New FormattedText(Value, Culture, Flow, Serif, 72, Brushes.Black)
                CardGroup.Children.Add(CardItem.BuildGeometry(New Point(36, 34))) ' Middle
            Case 13
                Value = KING
                CardItem = New FormattedText(Value, Culture, Flow, Serif, 72, Brushes.Black)
                CardGroup.Children.Add(CardItem.BuildGeometry(New Point(36, 34))) ' Middle
        End Select
        Dim CardValue As New FormattedText(Value, Culture, Flow, Serif, 16, Brushes.Black)
        Dim CardSuite As New FormattedText(Suite, Culture, Flow, SanSerif, 20, Brushes.Black)
        CardGroup.Children.Add(CardValue.BuildGeometry(New Point(4, 4)))
        CardGroup.Children.Add(CardSuite.BuildGeometry(New Point(4, 16)))
        CardGroup.Children.Add(CardSuite.BuildGeometry(New Point(100, 116)))
        If Len(Value) = 1 Then
            CardGroup.Children.Add(CardValue.BuildGeometry(New Point(102, 134)))
        Else
            CardGroup.Children.Add(CardValue.BuildGeometry(New Point(98, 134)))
        End If
        CardPath.Data = CardGroup
        Return CardPath
    End Function

    Private Function Card(ByRef Value As Integer, _
                          ByRef IsFacing As Boolean, _
                          ByRef BackColor As Brush) As Object
        Dim Canvas As New Canvas
        Dim Face As New Polygon
        Face.Points.Add(New Point(0, 0))
        Face.Points.Add(New Point(0, 155))
        Face.Points.Add(New Point(117, 155))
        Face.Points.Add(New Point(117, 0))
        Canvas.Height = 222
        Canvas.Width = 124
        Face.StrokeLineJoin = PenLineJoin.Round
        Face.Width = Canvas.Width
        Face.Height = Canvas.Height
        Face.Stroke = Brushes.Black
        Face.StrokeThickness = 4.0
        If IsFacing Then
            Face.Fill = BackColor
            Canvas.Children.Add(Face)
            Canvas.Children.Add(Deck(Value))
        Else
            Face.Fill = BackColor
            Canvas.Children.Add(Face)
        End If
        Return Canvas
    End Function

    Private Sub Add(ByRef Grid As Grid, ByRef Button As Button, _
            ByRef Row As Integer, ByRef Column As Integer)
        Button.Margin = New Thickness(4)
        Button.Height = 160
        Button.Width = 120
        If Column = 0 Then
            Button.Content = Card(1, False, Brushes.Red)
        Else
            Button.Content = Card(2, False, Brushes.Blue)
        End If
        Grid.Children.Add(Button)
        Grid.SetColumn(Button, Column)
        Grid.SetRow(Button, Row)
    End Sub

    Private Sub Layout(ByRef Grid As Grid)
        Grid.ColumnDefinitions.Clear() ' Clear Columns
        Grid.RowDefinitions.Clear() ' Clear Rows
        Grid.Children.Clear() ' Clear the Grid
        Grid.ColumnDefinitions.Add(New ColumnDefinition)
        Grid.ColumnDefinitions.Add(New ColumnDefinition)
        Grid.RowDefinitions.Add(New RowDefinition)
        Add(Grid, btn1, 0, 0)
        Add(Grid, btn2, 0, 1)
    End Sub

    Private Sub Shuffle(ByRef PlayerDeck As ArrayList)
        Dim Selection As Integer
        PlayerDeck.Clear() ' Reset Deck
        While PlayerDeck.Count < 52 ' Select 52 Numbers
            Randomize()
            Selection = Int((52 * Rnd()) + 1)
            If Not PlayerDeck.Contains(Selection) _
            Or PlayerDeck.Count < 1 Then
                PlayerDeck.Add(Selection)
            End If
        End While
    End Sub

    Private Sub NewGame()
        Score = 0
        Layout(BoardLayout)
        Shuffle(DeckOne)
        Shuffle(DeckTwo)
        Me.Title = "Score:" & Score
    End Sub

    Private Sub OnClick(ByVal sender As System.Object, _
                    ByVal e As System.Windows.RoutedEventArgs) _
                    Handles btn1.Click, btn2.Click
        If CardOne < 52 And CardTwo < 52 Then
            FirstChoice = DeckOne(CardOne)
            btn1.Content = Card(FirstChoice, True, Brushes.White)
            CardOne += 1
            SecondChoice = DeckTwo(CardTwo)
            btn2.Content = Card(SecondChoice, True, Brushes.White)
            CardTwo += 1
            If FirstChoice.Equals(SecondChoice) Then
                Score += 1
                MsgBox("Match!", MsgBoxStyle.Information, "Playing Cards")
            End If
            Me.Title = "Score:" & Score
            Counter += 1
        Else
            MsgBox("Game Over! Matched " & Score & _
                   " out of " & Counter & " Cards!", _
                              MsgBoxStyle.Information, "Playing Cards")
            NewGame()
        End If
    End Sub


    Private Sub btnNew_Click(ByVal sender As System.Object, _
                             ByVal e As System.Windows.RoutedEventArgs) _
                             Handles btnNew.Click
        NewGame()
    End Sub

    Private Sub Window1_Loaded(ByVal sender As Object, _
                           ByVal e As System.Windows.RoutedEventArgs) _
                           Handles Me.Loaded
        NewGame()
    End Sub
End Class

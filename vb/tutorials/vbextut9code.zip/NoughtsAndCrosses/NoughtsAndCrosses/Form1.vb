Public Class Form1

    Dim DrawPicture As New PictureBox
    Dim DrawBitmap As Bitmap
    Dim DrawGraphics As Graphics

    Dim CirclePen As New Pen(Color.Blue, 4)
    Dim CrossPen As New Pen(Color.Red, 4)

    Dim IsCross As Boolean
    Dim Nought As String = "O"
    Dim Cross As String = "X"
    Dim Won As Boolean
    Dim Board(3, 3) As String

    Private Sub DrawX()
        DrawGraphics.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
        DrawGraphics.DrawLine(CrossPen, 10, 10, 50, 50)
        DrawGraphics.DrawLine(CrossPen, 50, 10, 10, 50)
    End Sub

    Private Sub DrawO()
        DrawGraphics.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
        DrawGraphics.DrawEllipse(CirclePen, 8, 8, 40, 40)
    End Sub


    Private Sub SetPiece(ByVal Row As Integer, ByVal Column As Integer, ByVal pic As PictureBox)
        If Board(Row, Column) = Nought Or Board(Row, Column) = Cross Then
            ' Do nothing if Nought or Cross already in square
        Else
            DrawPicture = CType(pic, PictureBox)
            DrawBitmap = New Bitmap(DrawPicture.Width, DrawPicture.Height)
            DrawGraphics = Graphics.FromImage(DrawBitmap)
            DrawPicture.Image = DrawBitmap
            If IsCross Then
                DrawX()
                Board(Row, Column) = Cross
                Me.Text = "Player:" & Nought
            Else
                DrawO()
                Board(Row, Column) = Nought
                Me.Text = "Player:" & Cross
            End If
        End If
    End Sub

    Private Sub Check(ByVal Player As String, ByVal x1 As Integer, ByVal y1 As Integer, _
    ByVal x2 As Integer, ByVal y2 As Integer, ByVal x3 As Integer, ByVal y3 As Integer)
        If Board(x1, y1) = Player And Board(x2, y2) = Player And Board(x3, y3) = Player Then
            Won = True
            Me.Text = Player & " Won!"
            MsgBox(Player & " Won!", MsgBoxStyle.Information, "Noughts and Crossses")
        End If
    End Sub

    Private Sub CheckWon(ByVal Player As String)
        Check(Player, 1, 1, 1, 2, 1, 3)
        Check(Player, 2, 1, 2, 2, 2, 3)
        Check(Player, 3, 1, 3, 2, 3, 3)
        Check(Player, 1, 1, 2, 1, 3, 1)
        Check(Player, 1, 2, 2, 2, 3, 2)
        Check(Player, 1, 3, 2, 3, 3, 3)
        Check(Player, 1, 1, 2, 2, 3, 3)
        Check(Player, 3, 1, 2, 2, 1, 3)
    End Sub

    Private Sub CheckDraw()
        If Not Board(1, 1) = "" And Not Board(1, 2) = "" And Not Board(1, 3) = "" Then
            If Not Board(2, 1) = "" And Not Board(2, 2) = "" And Not Board(2, 3) = "" Then
                If Not Board(3, 1) = "" And Not Board(3, 2) = "" And Not Board(3, 3) = "" Then
                    If Not Won Then
                        Me.Text = "Draw!"
                        MsgBox("Draw!", MsgBoxStyle.Information, "Noughts and Crossses")
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub PictureClick(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles PictureBox1.Click, _
    PictureBox2.Click, PictureBox3.Click, PictureBox4.Click, _
    PictureBox5.Click, PictureBox6.Click, PictureBox7.Click, _
    PictureBox8.Click, PictureBox9.Click
        If Not Won Then
            Select Case sender.name
                Case "PictureBox1"
                    SetPiece(1, 1, sender)
                Case "PictureBox2"
                    SetPiece(1, 2, sender)
                Case "PictureBox3"
                    SetPiece(1, 3, sender)
                Case "PictureBox4"
                    SetPiece(2, 1, sender)
                Case "PictureBox5"
                    SetPiece(2, 2, sender)
                Case "PictureBox6"
                    SetPiece(2, 3, sender)
                Case "PictureBox7"
                    SetPiece(3, 1, sender)
                Case "PictureBox8"
                    SetPiece(3, 2, sender)
                Case "PictureBox9"
                    SetPiece(3, 3, sender)
            End Select
            CheckWon(Cross)
            CheckWon(Nought)
            CheckDraw()
            IsCross = Not IsCross
        Else
            MsgBox("Game is Over")
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles Button1.Click
        Dim msg As MsgBoxResult
        Board(1, 1) = ""
        Board(1, 2) = ""
        Board(1, 3) = ""
        Board(2, 1) = ""
        Board(2, 2) = ""
        Board(2, 3) = ""
        Board(3, 1) = ""
        Board(3, 2) = ""
        Board(3, 3) = ""
        PictureBox1.Image = Nothing
        PictureBox2.Image = Nothing
        PictureBox3.Image = Nothing
        PictureBox4.Image = Nothing
        PictureBox5.Image = Nothing
        PictureBox6.Image = Nothing
        PictureBox7.Image = Nothing
        PictureBox8.Image = Nothing
        PictureBox9.Image = Nothing
        Won = False
        msg = MsgBox(Cross & " to go first?", _
        MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Noughts and Crossses")
        If msg = MsgBoxResult.Yes Then
            IsCross = True
            Me.Text = "Player:" & Cross
        Else
            IsCross = False
            Me.Text = "Player:" & Nought
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, _
                           ByVal e As System.EventArgs) Handles MyBase.Load
        Button1.PerformClick()
    End Sub
End Class


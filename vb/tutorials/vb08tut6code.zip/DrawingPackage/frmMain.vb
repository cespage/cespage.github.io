﻿Public Class frmMain
    Private DrawBitmap As Bitmap
    Private DrawGraphics As Graphics
    Private DrawColour As Color = Color.Blue
    Private DrawWidth As Integer = 5

    Private Sub NewToolStripMenuItem_Click(ByVal sender As System.Object, _
                                           ByVal e As System.EventArgs) _
                                           Handles NewToolStripMenuItem.Click
        Dim Response As MsgBoxResult
        Response = MsgBox("Are you sure you want to start a New Drawing?", _
                          MsgBoxStyle.Question + MsgBoxStyle.YesNo, _
                          "Drawing Package")
        If Response = MsgBoxResult.Yes Then
            picDraw.Image = Nothing
            Me.Text = "Drawing Package - Untitled"
        End If
    End Sub

    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles OpenToolStripMenuItem.Click
        Dim Open As New OpenFileDialog()
        Open.Filter = "Bitmap Image (*.bmp)|*.bmp|All files (*.*)|*.*"
        Open.CheckFileExists = True
        If Open.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            Try
                Open.OpenFile()
                picDraw.Image = Image.FromFile(Open.FileName)
                Me.Text = "Drawing Package - " & Open.FileName
            Catch ex As Exception
                ' Do nothing on Exception
            End Try
        End If
    End Sub

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles SaveToolStripMenuItem.Click
        Dim Save As New SaveFileDialog()
        Save.Filter = "Bitmap Image Files (*.bmp)|*.bmp|All files (*.*)|*.*"
        Save.CheckPathExists = True
        If Save.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            Try
                picDraw.Image.Save(Save.FileName)
                Me.Text = "Drawing Package - " & Save.FileName
            Catch ex As Exception
                ' Do nothing on Exception
            End Try
        End If
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles ExitToolStripMenuItem.Click
        Dim Response As MsgBoxResult
        Response = MsgBox("Are you sure you want to Exit Drawing Package?", _
                          MsgBoxStyle.Question + MsgBoxStyle.YesNo, _
                          "Drawing Package")
        If Response = MsgBoxResult.Yes Then
            End
        End If
    End Sub

    Private Sub CutToolStripMenuItem_Click(ByVal sender As System.Object, _
                                           ByVal e As System.EventArgs) _
                                           Handles CutToolStripMenuItem.Click
        Clipboard.SetImage(picDraw.Image) ' Copy
        ' Delete
        DrawBitmap = New Bitmap(picDraw.Width, picDraw.Height)
        DrawGraphics = Graphics.FromImage(DrawBitmap)
        picDraw.Image = DrawBitmap
    End Sub

    Private Sub CopyToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles CopyToolStripMenuItem.Click
        Clipboard.SetImage(picDraw.Image) ' Copy
    End Sub

    Private Sub PasteToolStripMenuItem_Click(ByVal sender As System.Object, _
                                             ByVal e As System.EventArgs) _
                                             Handles PasteToolStripMenuItem.Click
        picDraw.Image = Clipboard.GetImage ' Paste
    End Sub

    Private Sub DeleteToolStripMenuItem_Click(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) _
                                              Handles DeleteToolStripMenuItem.Click
        ' Delete
        DrawBitmap = New Bitmap(picDraw.Width, picDraw.Height)
        DrawGraphics = Graphics.FromImage(DrawBitmap)
        picDraw.Image = DrawBitmap
    End Sub

    Private Sub WidthToolStripMenuItem_Click(ByVal sender As System.Object, _
                                             ByVal e As System.EventArgs) _
                                             Handles WidthToolStripMenuItem.Click
        Dim Value As String
        Value = InputBox("Enter a Width (between 1-200)", _
                         "Drawing Package", DrawWidth)
        If IsNumeric(Value) Then
            If CInt(Value) > 0 And CInt(Value) <= 200 Then
                DrawWidth = CInt(Value)
            End If
        End If
        Value = Nothing
    End Sub

    Private Sub ColourToolStripMenuItem_Click(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) _
                                              Handles ColourToolStripMenuItem.Click
        Dim Colour As New ColorDialog
        Colour.Color = DrawColour
        If Colour.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            Try
                DrawColour = Colour.Color
            Catch ex As Exception
                ' Do nothing on Exception
            End Try
        End If
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs) _
                             Handles MyBase.Load
        DrawBitmap = New Bitmap(picDraw.Width, picDraw.Height)
        DrawGraphics = Graphics.FromImage(DrawBitmap)
        DrawGraphics.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
        picDraw.Image = DrawBitmap
        Me.Text = "Drawing Package - Untitled"
    End Sub

    Private Sub frmMain_Resize(ByVal sender As Object, _
                               ByVal e As System.EventArgs) _
                               Handles Me.Resize
        If picDraw.Width > picDraw.Image.Width Or _
        picDraw.Height > picDraw.Image.Height Then
            DrawBitmap = New Bitmap(picDraw.Width, picDraw.Height)
            DrawGraphics = Graphics.FromImage(DrawBitmap)
            DrawGraphics.DrawImage(picDraw.Image, 0, 0)
            picDraw.Image = DrawBitmap
        End If
    End Sub

    Private Sub picDraw_MouseMove(ByVal sender As Object, _
                                  ByVal e As System.Windows.Forms.MouseEventArgs) _
                                  Handles picDraw.MouseMove
        If e.Button = Windows.Forms.MouseButtons.Left Then
            DrawGraphics.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
            DrawGraphics.FillEllipse(New SolidBrush(DrawColour), _
                                     e.X, e.Y, DrawWidth, DrawWidth)
            picDraw.Image = DrawBitmap
        End If
    End Sub
End Class

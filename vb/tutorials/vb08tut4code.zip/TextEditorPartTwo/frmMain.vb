﻿Imports System.Text.RegularExpressions

Public Class frmMain
    Private WithEvents FindReplace As New FindReplaceDialog
    Private FindReplaceRegex As Regex
    Private FindReplaceMatch As Match
    Private IsFirstFind As Boolean = True

    Private Function SearchRegEx() As Regex
        If FindReplace.MatchCase Then ' Search with Match Case
            Return New Regex(Regex.Escape(FindReplace.FindWhat))
        Else ' Search with Ignore Case
            Return New Regex(Regex.Escape(FindReplace.FindWhat), RegexOptions.IgnoreCase)
        End If
    End Function

    Private Sub FindText(ByRef TextBox As TextBox)
        If IsFirstFind Then
            FindReplaceRegex = SearchRegEx()
            FindReplaceMatch = FindReplaceRegex.Match(TextBox.Text)
            IsFirstFind = False
        Else
            FindReplaceMatch = FindReplaceRegex.Match(TextBox.Text, _
                                                      FindReplaceMatch.Index + 1)
        End If
        If FindReplaceMatch.Success Then
            TextBox.Focus()
            TextBox.SelectionStart = FindReplaceMatch.Index
            TextBox.SelectionLength = FindReplaceMatch.Length
        Else
            IsFirstFind = True
        End If
    End Sub

    Private Sub ReplaceText(ByRef TextBox As TextBox)
        Dim ReplaceRegex As Regex = SearchRegEx()
        Dim ReplaceMatch As Match = ReplaceRegex.Match(TextBox.SelectedText)
        If ReplaceMatch.Success Then
            If ReplaceMatch.Value = TextBox.SelectedText Then
                TextBox.SelectedText = FindReplace.ReplaceWith
            End If
        End If
        FindText(TextBox)
    End Sub

    Private Sub ReplaceAllText(ByRef TextBox As TextBox)
        Dim ReplaceRegex As Regex = SearchRegEx()
        Dim strReplaced As String
        Dim selectedPos As Integer = TextBox.SelectionStart
        strReplaced = ReplaceRegex.Replace(TextBox.Text, FindReplace.ReplaceWith)
        If TextBox.Text <> strReplaced Then ' Replace Text if Changed
            TextBox.Text = strReplaced
            TextBox.SelectionStart = selectedPos ' Restore SelectionStart
        End If
        TextBox.Focus()
    End Sub

    Public Sub FindNext(ByRef TextBox As TextBox)
        FindText(TextBox)
    End Sub

    Private Sub NewToolStripMenuItem_Click(ByVal sender As System.Object, _
                                           ByVal e As System.EventArgs) _
                                           Handles NewToolStripMenuItem.Click
        Dim Response As MsgBoxResult
        Response = MsgBox("Are you sure you want to start a New Document?", _
                          MsgBoxStyle.Question + MsgBoxStyle.YesNo, _
                          "Text Editor")
        If Response = MsgBoxResult.Yes Then
            txtEditor.Text = ""
            Me.Text = "Text Editor - Untitled"
        End If
    End Sub

    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles OpenToolStripMenuItem.Click
        Dim Open As New OpenFileDialog()
        Dim myStreamReader As System.IO.StreamReader
        Open.Filter = "Plain Text Files (*.txt)|*.txt|All files (*.*)|*.*"
        Open.CheckFileExists = True
        Open.ShowDialog(Me)
        Try
            Open.OpenFile()
            myStreamReader = System.IO.File.OpenText(Open.FileName)
            txtEditor.Text = myStreamReader.ReadToEnd()
            Me.Text = "Text Editor - " & Open.FileName
        Catch ex As Exception
            ' Do nothing on Exception
        End Try
    End Sub

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles SaveToolStripMenuItem.Click
        Dim Save As New SaveFileDialog()
        Dim myStreamWriter As System.IO.StreamWriter
        Save.Filter = "Plain Text Files (*.txt)|*.txt|All files (*.*)|*.*"
        Save.CheckPathExists = True
        Save.ShowDialog(Me)
        Try
            myStreamWriter = System.IO.File.CreateText(Save.FileName)
            myStreamWriter.Write(txtEditor.Text)
            myStreamWriter.Flush()
            Me.Text = "Text Editor - " & Save.FileName
        Catch ex As Exception
            ' Do nothing on Exception
        End Try
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles ExitToolStripMenuItem.Click
        Dim Response As MsgBoxResult
        Response = MsgBox("Are you sure you want to Exit Text Editor?", _
                          MsgBoxStyle.Question + MsgBoxStyle.YesNo, _
                          "Text Editor")
        If Response = MsgBoxResult.Yes Then
            End
        End If
    End Sub

    Private Sub CutToolStripMenuItem_Click(ByVal sender As System.Object, _
                                           ByVal e As System.EventArgs) _
                                           Handles CutToolStripMenuItem.Click
        txtEditor.Cut()
    End Sub

    Private Sub CopyToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles CopyToolStripMenuItem.Click
        txtEditor.Copy()
    End Sub

    Private Sub PasteToolStripMenuItem_Click(ByVal sender As System.Object, _
                                             ByVal e As System.EventArgs) _
                                             Handles PasteToolStripMenuItem.Click
        txtEditor.Paste()
    End Sub

    Private Sub DeleteToolStripMenuItem_Click(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) _
                                              Handles DeleteToolStripMenuItem.Click
        txtEditor.SelectedText = ""
    End Sub

    Private Sub SelectAllToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                 ByVal e As System.EventArgs) _
                                                 Handles SelectAllToolStripMenuItem.Click
        txtEditor.SelectAll()
    End Sub

    Private Sub TimeDateToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                ByVal e As System.EventArgs) _
                                                Handles TimeDateToolStripMenuItem.Click
        txtEditor.SelectedText = Format(Now, "HH:mm dd/MM/yyyy")
    End Sub

    Private Sub FontToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles FontToolStripMenuItem.Click
        Dim Font As New FontDialog()
        Font.Font = txtEditor.Font
        Font.ShowDialog(Me)
        Try
            txtEditor.Font = Font.Font
        Catch ex As Exception
            ' Do nothing on Exception
        End Try
    End Sub

    Private Sub ColourToolStripMenuItem_Click(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) _
                                              Handles ColourToolStripMenuItem.Click
        Dim Colour As New ColorDialog()
        Colour.Color = txtEditor.ForeColor
        Colour.ShowDialog(Me)
        Try
            txtEditor.ForeColor = Colour.Color
        Catch ex As Exception
            ' Do nothing on Exception
        End Try
    End Sub

    Private Sub BackgroundToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                  ByVal e As System.EventArgs) _
                                                  Handles BackgroundToolStripMenuItem.Click
        Dim Colour As New ColorDialog()
        Colour.Color = txtEditor.BackColor
        Colour.ShowDialog(Me)
        Try
            txtEditor.BackColor = Colour.Color
        Catch ex As Exception
            ' Do nothing on Exception
        End Try
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs) _
                             Handles MyBase.Load
        txtEditor.Text = ""
        Me.Text = "Text Editor - Untitled"
    End Sub

    Private Sub FindReplace_FindNext(ByVal sender As Object, _
                                     ByVal e As System.EventArgs) _
                                     Handles FindReplace.FindNext
        FindNext(txtEditor)
    End Sub

    Private Sub FindReplace_Replace(ByVal sender As Object, _
                                    ByVal e As System.EventArgs) _
                                    Handles FindReplace.Replace
        ReplaceText(txtEditor)
    End Sub

    Private Sub FindReplace_ReplaceAll(ByVal sender As Object, _
                                       ByVal e As System.EventArgs) _
                                       Handles FindReplace.ReplaceAll
        ReplaceAllText(txtEditor)
    End Sub

    Private Sub FindToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles FindToolStripMenuItem.Click
        FindReplace.FindWhat = txtEditor.SelectedText
        FindReplace.HideWholeWord = True
        FindReplace.Type = FindReplaceDialog.FindReplaceDialogType.Find
        FindReplace.ShowDialog(Me)
    End Sub

    Private Sub FindNextToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                ByVal e As System.EventArgs) _
                                                Handles FindNextToolStripMenuItem.Click
        FindNext(txtEditor)
        txtEditor.Focus()
    End Sub

    Private Sub ReplaceToolStripMenuItem_Click(ByVal sender As System.Object, _
                                               ByVal e As System.EventArgs) _
                                               Handles ReplaceToolStripMenuItem.Click
        FindReplace.FindWhat = txtEditor.SelectedText
        FindReplace.HideWholeWord = True
        FindReplace.Type = FindReplaceDialog.FindReplaceDialogType.Replace
        FindReplace.ShowDialog(Me)
    End Sub
End Class

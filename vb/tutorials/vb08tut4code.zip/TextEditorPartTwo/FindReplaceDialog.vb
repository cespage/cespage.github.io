﻿Imports System
Imports System.Windows.Forms
Imports System.Runtime.InteropServices

''' <summary>FindReplaceDialog Component</summary> 
Public Class FindReplaceDialog
    Inherits System.ComponentModel.Component
    Implements System.Windows.Forms.IMessageFilter

    ' Public Enums

    Public Enum FindDirection
        Up = 0
        Down = 1
    End Enum

    Public Enum FindReplaceDialogType
        Find = 0
        Replace = 1
    End Enum

    Public Enum FindReplaceItem
        UpDown = 0
        MatchCase = 1
        WholeWord = 2
    End Enum

    ' Private Constants

    Private Const FR_DOWN As Integer = 1
    Private Const FR_MATCHWHOLEWORD As Integer = 2
    Private Const FR_MATCHCASE As Integer = 4
    Private Const FR_FINDNEXT As Integer = 8
    Private Const FR_REPLACE As Integer = 16
    Private Const FR_REPLACEALL As Integer = 32
    Private Const FR_DIALOGTERM As Integer = 64
    Private Const FR_SHOWHELP As Integer = 128
    Private Const FR_ENABLEHOOK As Integer = 256
    Private Const FR_ENABLETEMPLATE As Integer = 512
    Private Const FR_DISABLEUPDOWN As Integer = 1024
    Private Const FR_DISABLEMATCHCASE As Integer = 2048
    Private Const FR_DISABLEWHOLEWORD As Integer = 4096
    Private Const FR_ENABLETEMPLATEHANDLE As Integer = 8192
    Private Const FR_HIDEUPDOWN As Integer = 16384
    Private Const FR_HIDEMATCHCASE As Integer = 32768
    Private Const FR_HIDEWHOLEWORD As Integer = 65536
    Private Const MINBUFFERSIZE As Integer = 256
    Private Const DIALOG_MESSAGE As String = "commdlg_FindReplace"

    ' Private Members

    Private hwndDlg As IntPtr ' Dialog handle

    Private flags As Integer ' Dialog Flags
    Private fr As IntPtr ' Copy of memory passed to FindReplace 
    Private dialogType As FindReplaceDialogType ' Dialog type 
    Private m_findwhat As String ' String to be found 
    Private m_replacewith As String ' String to be replaced with 
    Private findwhatbuffer As IntPtr = IntPtr.Zero ' Buffer for find what string
    Private replacewithbuffer As IntPtr = IntPtr.Zero ' Buffer for replace with 
    Friend Shared findmsgstring As Integer = 0 ' Message used by dialog

    Private owner As OwnerWindow ' Window that subclasses the owner 

    ' Owner Window InnerClass

    Private Class OwnerWindow
        Inherits NativeWindow
        Private Source As FindReplaceDialog

        Friend Sub New(ByVal Source As FindReplaceDialog)
            Me.Source = Source
        End Sub

        Protected Overloads Overrides Sub WndProc(ByRef m As System.Windows.Forms.Message)
            If m.Msg = FindReplaceDialog.findmsgstring Then
                Source.HandleFindMsgString(m)
            Else
                DefWndProc(m)
            End If
        End Sub
    End Class

    ' Constructor

    ''' <summary>Initialises a FindReplaceDialog Instance</summary> 
    Public Sub New()
        owner = New OwnerWindow(Me)
    End Sub

    ' Private Methods

    Private Sub SetOption(ByVal [option] As Integer, _
                          ByVal b As Boolean)
        If b Then
            flags = flags Or [option]
        Else
            flags = flags And Not [option]
        End If
    End Sub

    Private Function GetOption(ByVal [option] As Integer) As Boolean
        Return (flags And [option]) <> 0
    End Function

    Private Function StringToBuffer(ByVal stringIn As String, _
                                    ByRef Length As Short) As IntPtr
        Dim stringPointer As New IntPtr
        Try ' Accept a string and pass back a pointer to the string.
            stringPointer = Marshal.StringToHGlobalAuto(stringIn)
            Length = CType(stringIn.Length, Short)
            If (stringIn Is Nothing) Or (stringIn.Length < MINBUFFERSIZE) Then
                stringPointer = Marshal.ReAllocHGlobal(stringPointer, _
                                       New IntPtr(MINBUFFERSIZE * _
                                                  Marshal.SystemDefaultCharSize))
                Length = CType(MINBUFFERSIZE, Short)
            End If
            Return stringPointer
        Catch ex As System.Exception
            Throw ex
        End Try
    End Function

    Private Sub CleanUp()
        If findwhatbuffer <> IntPtr.Zero Then
            Marshal.FreeHGlobal(findwhatbuffer)
        End If
        If replacewithbuffer <> IntPtr.Zero Then
            Marshal.FreeHGlobal(replacewithbuffer)
        End If
        If fr <> IntPtr.Zero Then
            Dim tempfr As FindReplace = _
            DirectCast(Marshal.PtrToStructure(fr, GetType(FindReplace)), FindReplace)
            Marshal.FreeHGlobal(fr)
        End If
        fr = IntPtr.Zero
    End Sub

    ' API Class and Methods

    <StructLayout(LayoutKind.Sequential)> _
    Friend Class FindReplace
        Friend cbSize As Integer
        Friend hwndOwner As IntPtr
        Friend hInstance As IntPtr
        Friend flags As Integer
        Friend findwhat As IntPtr
        Friend replacewith As IntPtr
        Friend findwhatlen As Short
        Friend replacewithlen As Short
        Friend custdata As IntPtr
        Friend hookproc As IntPtr
        Friend templateName As IntPtr
    End Class

    <DllImport("Comdlg32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    Private Shared Function FindText(ByVal lpfr As IntPtr) As IntPtr
    End Function

    <DllImport("Comdlg32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    Private Shared Function ReplaceText(ByVal lpfr As IntPtr) As IntPtr
    End Function

    <DllImport("User32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    Private Shared Function RegisterWindowMessage(<MarshalAs(UnmanagedType.LPTStr)> _
        ByVal message As String) As Integer
    End Function

    <DllImport("User32.dll")> _
    Private Shared Function DestroyWindow(ByVal hwnd As IntPtr) As Integer
    End Function

    <StructLayout(LayoutKind.Sequential)> _
    Private Structure MSG
        Friend hwnd As IntPtr
        Friend message As Integer
        Friend wparam As IntPtr
        Friend lparam As IntPtr
        Private time As Integer
        Private x As Long
        Private y As Long
    End Structure

    <DllImport("User32.dll")> _
    Private Shared Function IsDialogMessage(ByVal hwnd As IntPtr, _
                                            ByRef msg As MSG) As Boolean
    End Function

    ' IMessageFilter Implementation

    Public Function PreFilterMessage(ByRef m As System.Windows.Forms.Message) _
    As Boolean Implements System.Windows.Forms.IMessageFilter.PreFilterMessage
        Dim msg As New MSG()
        msg.hwnd = m.HWnd
        msg.lparam = m.LParam
        msg.message = m.Msg
        msg.wparam = m.WParam
        Return IsDialogMessage(hwndDlg, msg)
    End Function

    ' Public Properties

    ''' <summary>Get or set the search direction, Up/Down</summary> 
    Public Property Direction() As FindDirection
        Get
            Return IIf(GetOption(FR_DOWN), _
                       FindDirection.Down, FindDirection.Up)
        End Get
        Set(ByVal Value As FindDirection)
            SetOption(FR_DOWN, Value = FindDirection.Down)
        End Set
    End Property

    ''' <summary>Hides Up/Down radio buttons</summary> 
    Public Property HideUpDown() As Boolean
        Get
            Return GetOption(FR_HIDEUPDOWN)
        End Get
        Set(ByVal Value As Boolean)
            SetOption(FR_HIDEUPDOWN, Value)
        End Set
    End Property

    ''' <summary>Hides Match Case checkbox</summary> 
    Public Property HideMatchCase() As Boolean
        Get
            Return GetOption(FR_HIDEMATCHCASE)
        End Get
        Set(ByVal Value As Boolean)
            SetOption(FR_HIDEMATCHCASE, Value)
        End Set
    End Property

    ''' <summary>Hides Whole Word checkbox</summary> 
    Public Property HideWholeWord() As Boolean
        Get
            Return GetOption(FR_HIDEWHOLEWORD)
        End Get
        Set(ByVal Value As Boolean)
            SetOption(FR_HIDEWHOLEWORD, Value)
        End Set
    End Property

    ''' <summary>Uses match case option while searching</summary> 
    Public Property MatchCase() As Boolean
        Get
            Return GetOption(FR_MATCHCASE)
        End Get
        Set(ByVal value As Boolean)
            SetOption(FR_MATCHCASE, value)
        End Set
    End Property

    ''' <summary>Disables Match Case checkbox</summary> 
    Public Property DisableMatchCase() As Boolean
        Get
            Return GetOption(FR_DISABLEMATCHCASE)
        End Get
        Set(ByVal value As Boolean)
            SetOption(FR_DISABLEMATCHCASE, value)
        End Set
    End Property

    ''' <summary>Disables Up/Down radio buttons</summary> 
    Public Property DisableUpDown() As Boolean
        Get
            Return GetOption(FR_DISABLEUPDOWN)
        End Get
        Set(ByVal value As Boolean)
            SetOption(FR_DISABLEUPDOWN, value)
        End Set
    End Property

    ''' <summary>Disables Whole Word checkbox</summary> 
    Public Property DisableWholeWord() As Boolean
        Get
            Return GetOption(FR_DISABLEWHOLEWORD)
        End Get
        Set(ByVal value As Boolean)
            SetOption(FR_DISABLEWHOLEWORD, value)
        End Set
    End Property

    ''' <summary>Matches Whole Word</summary> 
    Public Property MatchWholeWord() As Boolean
        Get
            Return GetOption(FR_MATCHWHOLEWORD)
        End Get
        Set(ByVal value As Boolean)
            SetOption(FR_MATCHWHOLEWORD, value)
        End Set
    End Property

    ''' <summary>Show Help Button in Title bar</summary> 
    Public Property ShowHelp() As Boolean
        Get
            Return GetOption(FR_SHOWHELP)
        End Get
        Set(ByVal value As Boolean)
            SetOption(FR_SHOWHELP, value)
        End Set
    End Property

    ''' <summary>Get or Set the String to be found</summary> 
    Public Property FindWhat() As String
        Get
            Return m_findwhat
        End Get
        Set(ByVal value As String)
            m_findwhat = value
        End Set
    End Property

    ''' <summary>Gets or Set the String to replaced with</summary> 
    Public Property ReplaceWith() As String
        Get
            Return m_replacewith
        End Get
        Set(ByVal value As String)
            m_replacewith = value
        End Set
    End Property

    ''' <summary>Get or Set the Dialog Type</summary> 
    Public Property Type() As FindReplaceDialogType
        Get
            Return dialogType
        End Get
        Set(ByVal value As FindReplaceDialogType)
            dialogType = value
        End Set
    End Property

    ' Events

    ''' <summary>Fired when user clicks the replace button</summary> 
    Public Event Replace As EventHandler
    ''' <summary>Fired when the user clicks ReplaceAll button</summary> 
    Public Event ReplaceAll As EventHandler
    ''' <summary>Fired when the user clicks the FindNext button</summary> 
    Public Event FindNext As EventHandler
    ''' <summary>Fired when the dialog is terminated by the user</summary> 
    Public Event DialogTerminate As EventHandler
    ''' <summary>Allows derived classes to handle replace event</summary> 
    Protected Overridable Sub OnReplace()
        RaiseEvent Replace(Me, EventArgs.Empty)
    End Sub
    ''' <summary>Allows derived classes to handle replace all event</summary> 
    Protected Overridable Sub OnReplaceAll()
        RaiseEvent ReplaceAll(Me, EventArgs.Empty)
    End Sub
    ''' <summary>Allows derive classes to handle find next event</summary> 
    Protected Overridable Sub OnFindNext()
        RaiseEvent FindNext(Me, EventArgs.Empty)
    End Sub
    ''' <summary>Allows derive classes to dialog terminate event</summary> 
    Protected Overridable Sub OnDialogTerminate()
        hwndDlg = IntPtr.Zero
        Me.owner.ReleaseHandle()
        Application.RemoveMessageFilter(Me)
        RaiseEvent DialogTerminate(Me, EventArgs.Empty)
    End Sub

    ' Dialog Methods

    Friend Sub HandleFindMsgString(ByVal m As Message)
        Dim tempfr As FindReplace = _
        DirectCast(Marshal.PtrToStructure(m.LParam, GetType(FindReplace)), FindReplace)
        flags = tempfr.flags
        m_findwhat = Marshal.PtrToStringAuto(tempfr.findwhat)
        m_replacewith = Marshal.PtrToStringAuto(tempfr.replacewith)
        If GetOption(FR_DIALOGTERM) Then
            SetOption(FR_DIALOGTERM, False)
            OnDialogTerminate()
        ElseIf GetOption(FR_FINDNEXT) Then
            SetOption(FR_FINDNEXT, False)
            OnFindNext()
        ElseIf GetOption(FR_REPLACE) Then
            SetOption(FR_REPLACE, False)
            OnReplace()
        ElseIf GetOption(FR_REPLACEALL) Then
            SetOption(FR_REPLACEALL, False)
            OnReplaceAll()
        End If
    End Sub

    ''' <summary>Shows the dialog. Throws an execption if something goes wrong</summary> 
    ''' <param name="owner">The owner of the dialog box (a form)</param> 
    Public Sub ShowDialog(ByVal owner As IWin32Window)
        If findmsgstring = 0 Then
            findmsgstring = RegisterWindowMessage(DIALOG_MESSAGE)
        End If
        Me.owner.AssignHandle(owner.Handle) ' Subclass Owner 
        CleanUp() ' Reset Buffers
        Dim tempfr As New FindReplace() ' Create new FindReplace 
        tempfr.hwndOwner = owner.Handle
        tempfr.cbSize = Marshal.SizeOf(GetType(FindReplace))
        findwhatbuffer = StringToBuffer(New String(m_findwhat), tempfr.findwhatlen)
        tempfr.findwhat = findwhatbuffer
        replacewithbuffer = StringToBuffer(New String(m_replacewith), tempfr.replacewithlen)
        tempfr.replacewith = replacewithbuffer
        tempfr.flags = flags
        tempfr.hInstance = IntPtr.Zero
        fr = Marshal.AllocHGlobal(Marshal.SizeOf(tempfr))
        Marshal.StructureToPtr(tempfr, fr, True)
        Application.AddMessageFilter(Me)
        If dialogType = FindReplaceDialogType.Find Then
            hwndDlg = FindText(fr)
        Else
            hwndDlg = ReplaceText(fr)
        End If
        If hwndDlg = IntPtr.Zero Then
            Marshal.ThrowExceptionForHR(Marshal.GetHRForLastWin32Error())
        End If
    End Sub

    ''' <summary>Destroys dialog if already open</summary> 
    ''' <param name="disposing">Free unmanaged resources</param> 
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
        CleanUp()
        If hwndDlg <> IntPtr.Zero Then
            DestroyWindow(hwndDlg)
            Application.RemoveMessageFilter(Me)
        End If
    End Sub

End Class

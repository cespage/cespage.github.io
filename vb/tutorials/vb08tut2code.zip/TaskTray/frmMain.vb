﻿Public Class frmMain

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles ExitToolStripMenuItem.Click
        End
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs) _
                             Handles MyBase.Load
        trayIcon.Icon = Me.Icon
        trayIcon.Visible = True
        trayIcon.ShowBalloonTip(100, "Task Tray", "Hello World", ToolTipIcon.Info)
    End Sub
End Class

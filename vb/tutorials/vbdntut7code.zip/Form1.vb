Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.White
        Me.PictureBox1.Location = New System.Drawing.Point(40, 16)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(64, 64)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.White
        Me.PictureBox2.Location = New System.Drawing.Point(184, 16)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(64, 64)
        Me.PictureBox2.TabIndex = 1
        Me.PictureBox2.TabStop = False
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(200, 224)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(88, 32)
        Me.Button3.TabIndex = 6
        Me.Button3.Text = "Exit"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(104, 224)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(88, 32)
        Me.Button2.TabIndex = 5
        Me.Button2.Text = "New Game"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(8, 224)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(88, 32)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Roll"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(40, 88)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(208, 16)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Label1"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label1, Me.Button3, Me.Button2, Me.Button1, Me.PictureBox2, Me.PictureBox1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim myBrush As SolidBrush
    Dim DiceOne As Integer
    Dim DiceTwo As Integer
    Dim Turn As Integer
    Dim DiceColor As Color

    Private Sub Form1_Load(ByVal sender As Object, _
    ByVal e As System.EventArgs) Handles MyBase.Load
        Label1.TextAlign = ContentAlignment.MiddleCenter
        Label1.Text = "Player 1"
        Turn = 1
        DiceColor = Color.Black
    End Sub

    Private Sub Center(ByVal b As SolidBrush, _
    ByVal pic As PictureBox, ByVal g As Graphics)
        g.FillEllipse(b, CInt(pic.Width / 2 - 6), _
        CInt(pic.Height / 2 - 6), 12, 12)
    End Sub

    Private Sub TopLeft(ByVal b As SolidBrush, _
    ByVal pic As PictureBox, ByVal g As Graphics)
        g.FillEllipse(b, 6, 6, 12, 12)
    End Sub

    Private Sub CenterLeft(ByVal b As SolidBrush, _
    ByVal pic As PictureBox, ByVal g As Graphics)
        g.FillEllipse(b, 6, _
        CInt(pic.Height / 2 - 6), 12, 12)
    End Sub

    Private Sub BottomLeft(ByVal b As SolidBrush, _
    ByVal pic As PictureBox, ByVal g As Graphics)
        g.FillEllipse(b, 6, pic.Height - 18, 12, 12)
    End Sub

    Private Sub TopRight(ByVal b As SolidBrush, _
    ByVal pic As PictureBox, ByVal g As Graphics)
        g.FillEllipse(b, pic.Width - 18, 6, 12, 12)
    End Sub

    Private Sub CenterRight(ByVal b As SolidBrush, _
    ByVal pic As PictureBox, ByVal g As Graphics)
        g.FillEllipse(b, pic.Width - 18, _
        CInt(pic.Height / 2 - 6), 12, 12)
    End Sub

    Private Sub BottomRight(ByVal b As SolidBrush, _
    ByVal pic As PictureBox, ByVal g As Graphics)
        g.FillEllipse(b, pic.Width - 18, _
        pic.Height - 18, 12, 12)
    End Sub

    Private Sub RenderDice(ByVal Value As Integer, _
    ByVal pic As PictureBox, ByVal g As Graphics, _
    ByVal ForeColor As Color)
        myBrush = New SolidBrush(ForeColor)
        Select Case Value
            Case 0
                ' Draw Nothing
            Case 1
                Center(myBrush, pic, g)
            Case 2
                TopLeft(myBrush, pic, g)
                BottomRight(myBrush, pic, g)
            Case 3
                TopLeft(myBrush, pic, g)
                Center(myBrush, pic, g)
                BottomRight(myBrush, pic, g)
            Case 4
                TopLeft(myBrush, pic, g)
                BottomLeft(myBrush, pic, g)
                TopRight(myBrush, pic, g)
                BottomRight(myBrush, pic, g)
            Case 5
                TopLeft(myBrush, pic, g)
                BottomLeft(myBrush, pic, g)
                Center(myBrush, pic, g)
                TopRight(myBrush, pic, g)
                BottomRight(myBrush, pic, g)
            Case 6
                TopLeft(myBrush, pic, g)
                CenterLeft(myBrush, pic, g)
                BottomLeft(myBrush, pic, g)
                TopRight(myBrush, pic, g)
                CenterRight(myBrush, pic, g)
                BottomRight(myBrush, pic, g)
        End Select
    End Sub

    Private Sub PictureBox1_Paint(ByVal sender As Object, _
    ByVal e As System.Windows.Forms.PaintEventArgs) _
    Handles PictureBox1.Paint
        RenderDice(DiceOne, PictureBox1, e.Graphics, DiceColor)
    End Sub

    Private Sub PictureBox2_Paint(ByVal sender As Object, _
    ByVal e As System.Windows.Forms.PaintEventArgs) _
    Handles PictureBox2.Paint
        RenderDice(DiceTwo, PictureBox1, e.Graphics, DiceColor)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles Button1.Click
        If Turn = 1 Then
            Randomize()
            DiceOne = CInt(Int((6 * Rnd()) + 1))
            PictureBox1.Refresh()
            Label1.Text = "Player 2"
            Turn = 2
        Else
            Randomize()
            DiceTwo = CInt(Int((6 * Rnd()) + 1))
            PictureBox2.Refresh()
            Label1.Text = "Player 1"
            Turn = 1
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles Button2.Click
        DiceOne = 0
        DiceTwo = 0
        PictureBox1.Refresh()
        PictureBox2.Refresh()
        Label1.Text = "Player 1"
        Turn = 1
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles Button3.Click
        End
    End Sub
End Class

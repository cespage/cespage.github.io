﻿Class Window1 

    Private Sub btnHelloWorld_Click(ByVal sender As System.Object, _
                                    ByVal e As System.Windows.RoutedEventArgs) _
                                    Handles btnHelloWorld.Click
        MsgBox("Hello World", MsgBoxStyle.Information, "Hello World")
    End Sub
End Class

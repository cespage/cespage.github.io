﻿Class Window1 
    Private WithEvents btn1, btn2, btn3, btn4, _
    btn5, btn6, btn7, btn8 As New Button
    Private WithEvents btn9, btn10, btn11, btn12, _
    btn13, btn14, btn15, btn16 As New Button
    Private Moves As Integer = 0
    Private FirstCardChoice As Integer = 0
    Private SecondCardChoice As Integer = 0
    Private FirstButton, SecondButton As Button
    Private Board(4, 4) ' Board
    Private Match As New ArrayList ' Matched

    Private Sub Add(ByRef Grid As Grid, ByRef Button As Button, _
                ByRef Row As Integer, ByRef Column As Integer)
        Button.Margin = New Thickness(5)
        Button.Content = Nothing
        Grid.Children.Add(Button)
        Grid.SetColumn(Button, Column)
        Grid.SetRow(Button, Row)
    End Sub

    Private Sub Layout(ByRef Grid As Grid)
        Grid.ColumnDefinitions.Clear() ' Clear Columns
        Grid.RowDefinitions.Clear() ' Clear Rows
        Grid.Children.Clear() ' Clear the Grid
        Grid.ColumnDefinitions.Add(New ColumnDefinition)
        Grid.ColumnDefinitions.Add(New ColumnDefinition)
        Grid.ColumnDefinitions.Add(New ColumnDefinition)
        Grid.ColumnDefinitions.Add(New ColumnDefinition)
        Grid.RowDefinitions.Add(New RowDefinition)
        Grid.RowDefinitions.Add(New RowDefinition)
        Grid.RowDefinitions.Add(New RowDefinition)
        Grid.RowDefinitions.Add(New RowDefinition)
        Add(Grid, btn1, 0, 0)
        Add(Grid, btn2, 0, 1)
        Add(Grid, btn3, 0, 2)
        Add(Grid, btn4, 0, 3)
        Add(Grid, btn5, 1, 0)
        Add(Grid, btn6, 1, 1)
        Add(Grid, btn7, 1, 2)
        Add(Grid, btn8, 1, 3)
        Add(Grid, btn9, 2, 0)
        Add(Grid, btn10, 2, 1)
        Add(Grid, btn11, 2, 2)
        Add(Grid, btn12, 2, 3)
        Add(Grid, btn13, 3, 0)
        Add(Grid, btn14, 3, 1)
        Add(Grid, btn15, 3, 2)
        Add(Grid, btn16, 3, 3)
    End Sub

    Private Function Shape(ByRef Points As  _
                       System.Windows.Media.PointCollection) As Object
        Dim Polygon As New Polygon
        Polygon.Stretch = Stretch.Uniform
        Polygon.StrokeLineJoin = PenLineJoin.Round
        Polygon.Points = Points
        Polygon.Width = Polygon.Height
        Polygon.Stroke = Brushes.Black
        Polygon.StrokeThickness = 4.0
        Polygon.Margin = New Thickness(5)
        Return Polygon
    End Function

    Private Function Card(ByRef Type As Integer) As Object
        Dim Points As New System.Windows.Media.PointCollection
        Select Case Type
            Case 1 ' Circle
                Dim CircleGeo As New EllipseGeometry(New Rect(0, 0, 50, 50))
                Dim Circle As New Path
                Circle.Stretch = Stretch.Uniform
                Circle.Data = CircleGeo
                Circle.Stroke = Brushes.Black
                Circle.StrokeThickness = 4.0
                Circle.Margin = New Thickness(5)
                Return Circle
            Case 2 ' Cross
                Dim Lines As New Path
                Dim LineGroup As New GeometryGroup
                LineGroup.Children.Add(New LineGeometry(New Point(0, 0), New Point(50, 50)))
                LineGroup.Children.Add(New LineGeometry(New Point(50, 0), New Point(0, 50)))
                Lines.Stretch = Stretch.Uniform
                Lines.Data = LineGroup
                Lines.Stroke = Brushes.Black
                Lines.StrokeThickness = 4.0
                Lines.Margin = New Thickness(5)
                Return Lines
            Case 3 ' Triangle
                Points.Add(New Point(150, 0))
                Points.Add(New Point(0, 250))
                Points.Add(New Point(300, 250))
                Return Shape(Points)
            Case 4 ' Square
                Points.Add(New Point(0, 0))
                Points.Add(New Point(0, 100))
                Points.Add(New Point(100, 100))
                Points.Add(New Point(100, 0))
                Return Shape(Points)
            Case 5 ' Pentagon
                Points.Add(New Point(0, 125))
                Points.Add(New Point(150, 0))
                Points.Add(New Point(300, 125))
                Points.Add(New Point(250, 300))
                Points.Add(New Point(50, 300))
                Return Shape(Points)
            Case 6 ' Hexagon
                Points.Add(New Point(75, 0))
                Points.Add(New Point(225, 0))
                Points.Add(New Point(300, 150))
                Points.Add(New Point(225, 300))
                Points.Add(New Point(75, 300))
                Points.Add(New Point(0, 150))
                Return Shape(Points)
            Case 7 ' Star
                Points.Add(New Point(9, 2))
                Points.Add(New Point(11, 7))
                Points.Add(New Point(17, 7))
                Points.Add(New Point(12, 10))
                Points.Add(New Point(14, 15))
                Points.Add(New Point(9, 12))
                Points.Add(New Point(4, 15))
                Points.Add(New Point(6, 10))
                Points.Add(New Point(1, 7))
                Points.Add(New Point(7, 7))
                Return Shape(Points)
            Case 8 ' Rhombus
                Points.Add(New Point(50, 0))
                Points.Add(New Point(100, 50))
                Points.Add(New Point(50, 100))
                Points.Add(New Point(0, 50))
                Return Shape(Points)
            Case Else
                Return Type
        End Select
    End Function

    Private Function Random(ByRef Start As Integer, ByRef Finish As Integer, _
                        ByRef Total As Integer) As ArrayList
        Dim Selections As New ArrayList
        Dim Selection As Integer
        While Selections.Count < Total
            Randomize()
            Selection = Int((Finish * Rnd()) + Start) ' Random Selection
            If Not Selections.Contains(Selection) _
            Or Selections.Count < 1 Then ' If Not Selected
                Selections.Add(Selection) ' Add Selection
            End If
        End While
        Return Selections
        Selections = Nothing
    End Function

    Private Sub Choose()
        Dim Numbers, Indices As New ArrayList ' Numbers, Index
        Dim Counter As Integer = 0
        While Numbers.Count < 17 ' Get 16 Numbers ( 2 x 8 )
            Dim Cards As ArrayList = Random(1, 8, 8) ' Random 1 - 8
            For Card As Integer = 0 To 7
                Numbers.Add(Cards.Item(Card)) ' Add to Cards
            Next
        End While
        Indices = Random(1, 16, 16) ' Random 1 - 16
        For Column As Integer = 0 To 3 ' Board Columns
            For Row As Integer = 0 To 3 ' Board Rows
                Board(Column, Row) = Numbers.Item(Indices(Counter) - 1)
                Counter += 1
            Next
        Next
    End Sub

    Private Sub NewGame()
        Moves = 0
        Match.Clear()
        Choose()
        Layout(BoardLayout)
        Me.Title = "Moves:0"
    End Sub

    Private Sub OnClick(ByVal sender As System.Object, _
                         ByVal e As System.Windows.RoutedEventArgs) Handles _
    btn1.Click, btn2.Click, btn3.Click, btn4.Click, btn5.Click, _
    btn6.Click, btn7.Click, btn8.Click, btn9.Click, btn10.Click, _
    btn11.Click, btn12.Click, btn13.Click, btn14.Click, btn15.Click, _
    btn16.Click
        Dim Button As New Button
        Button = CType(sender, Button)
        If Match.IndexOf(Board(Grid.GetRow(Button), _
                               Grid.GetColumn(Button))) < 0 Then ' No Match
            If FirstCardChoice = 0 Then
                FirstButton = Button
                FirstCardChoice = Board(Grid.GetRow(Button), _
                                        Grid.GetColumn(Button))
                Button.Content = Card(Board(Grid.GetRow(Button), _
                                            Grid.GetColumn(Button)))
            ElseIf SecondCardChoice = 0 Then
                SecondButton = Button
                If Not FirstButton.Equals(SecondButton) Then ' Different
                    SecondCardChoice = Board(Grid.GetRow(Button), _
                                             Grid.GetColumn(Button))
                    Button.Content = Card(Board(Grid.GetRow(Button), _
                                                Grid.GetColumn(Button)))
                    If FirstCardChoice.Equals(SecondCardChoice) Then ' Compare
                        Match.Add(FirstCardChoice)
                        Match.Add(SecondCardChoice)
                        MsgBox("Match!", MsgBoxStyle.Information, "Memory Game")
                        If Match.Count = 16 Then
                            MsgBox("Well Done! You got them all in " & _
                                   Moves & " moves!", _
                                   MsgBoxStyle.Information, "Memory Game")
                            Layout(BoardLayout)
                        End If
                    Else ' Reset Buttons
                        MsgBox("No Match", MsgBoxStyle.Exclamation, "Memory Game")
                        FirstButton.Content = Nothing
                        SecondButton.Content = Nothing
                    End If
                    Moves += 1
                    Me.Title = "Moves:" & Moves
                    FirstCardChoice = 0
                    SecondCardChoice = 0
                    FirstButton = Nothing
                    SecondButton = Nothing
                End If
            End If
        End If
    End Sub

    Private Sub btnNew_Click(ByVal sender As System.Object, _
                             ByVal e As System.Windows.RoutedEventArgs) _
                             Handles btnNew.Click
        NewGame()
    End Sub

    Private Sub Window1_Loaded(ByVal sender As Object, _
                               ByVal e As System.Windows.RoutedEventArgs) _
                               Handles Me.Loaded
        NewGame()
    End Sub
End Class

﻿Imports Microsoft.Win32
Public Class frmMain

    Dim Startup As Microsoft.Win32.RegistryKey = _
    Registry.CurrentUser.CreateSubKey _
    ("SOFTWARE\Microsoft\Windows\CurrentVersion\Run")

    Private Sub LogOffToolStripMenuItem_Click(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) _
                                              Handles LogOffToolStripMenuItem.Click
        System.Diagnostics.Process.Start("Shutdown", "/L")
    End Sub

    Private Sub RestartToolStripMenuItem_Click(ByVal sender As System.Object, _
                                               ByVal e As System.EventArgs) _
                                               Handles RestartToolStripMenuItem.Click
        System.Diagnostics.Process.Start("Shutdown", "/R")
    End Sub

    Private Sub ShutdownToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                ByVal e As System.EventArgs) _
                                                Handles ShutdownToolStripMenuItem.Click
        System.Diagnostics.Process.Start("Shutdown", "/S")
    End Sub

    Private Sub ShowAtStartupToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                     ByVal e As System.EventArgs) _
                                                     Handles ShowAtStartupToolStripMenuItem.Click
        If ShowAtStartupToolStripMenuItem.Checked Then
            Startup.DeleteValue("StartupShutdown")
            ShowAtStartupToolStripMenuItem.Checked = False
        Else
            With Startup
                .OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Run", True)
                .SetValue("StartupShutdown", Windows.Forms.Application.ExecutablePath)
            End With
            ShowAtStartupToolStripMenuItem.Checked = True
        End If
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs) _
                             Handles MyBase.Load
        trayIcon.Icon = Me.Icon
        trayIcon.Visible = True
        ShowAtStartupToolStripMenuItem.Checked = _
        Not Startup.GetValue("StartupShutdown") Is Nothing
    End Sub

    Private Sub frmMain_FormClosed(ByVal sender As Object, _
                               ByVal e As System.Windows.Forms.FormClosedEventArgs) _
                               Handles Me.FormClosed
        trayIcon.Visible = False
        End
    End Sub

End Class

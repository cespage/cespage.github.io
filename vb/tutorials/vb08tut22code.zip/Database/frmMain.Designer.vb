﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Dim IDLabel As System.Windows.Forms.Label
        Dim AlbumLabel As System.Windows.Forms.Label
        Dim ArtistLabel As System.Windows.Forms.Label
        Dim GenreLabel As System.Windows.Forms.Label
        Me.DatabaseDataSet = New Database.DatabaseDataSet
        Me.MusicBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.MusicTableAdapter = New Database.DatabaseDataSetTableAdapters.MusicTableAdapter
        Me.TableAdapterManager = New Database.DatabaseDataSetTableAdapters.TableAdapterManager
        Me.MusicBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton
        Me.MusicBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton
        Me.IDTextBox = New System.Windows.Forms.TextBox
        Me.AlbumTextBox = New System.Windows.Forms.TextBox
        Me.ArtistTextBox = New System.Windows.Forms.TextBox
        Me.GenreTextBox = New System.Windows.Forms.TextBox
        IDLabel = New System.Windows.Forms.Label
        AlbumLabel = New System.Windows.Forms.Label
        ArtistLabel = New System.Windows.Forms.Label
        GenreLabel = New System.Windows.Forms.Label
        CType(Me.DatabaseDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MusicBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MusicBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MusicBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'DatabaseDataSet
        '
        Me.DatabaseDataSet.DataSetName = "DatabaseDataSet"
        Me.DatabaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'MusicBindingSource
        '
        Me.MusicBindingSource.DataMember = "Music"
        Me.MusicBindingSource.DataSource = Me.DatabaseDataSet
        '
        'MusicTableAdapter
        '
        Me.MusicTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.MusicTableAdapter = Me.MusicTableAdapter
        Me.TableAdapterManager.UpdateOrder = Database.DatabaseDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'MusicBindingNavigator
        '
        Me.MusicBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.MusicBindingNavigator.BindingSource = Me.MusicBindingSource
        Me.MusicBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.MusicBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.MusicBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.MusicBindingNavigatorSaveItem})
        Me.MusicBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.MusicBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.MusicBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.MusicBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.MusicBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.MusicBindingNavigator.Name = "MusicBindingNavigator"
        Me.MusicBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.MusicBindingNavigator.Size = New System.Drawing.Size(284, 25)
        Me.MusicBindingNavigator.TabIndex = 0
        Me.MusicBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 15)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 6)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 20)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 20)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 6)
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 20)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'MusicBindingNavigatorSaveItem
        '
        Me.MusicBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.MusicBindingNavigatorSaveItem.Image = CType(resources.GetObject("MusicBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.MusicBindingNavigatorSaveItem.Name = "MusicBindingNavigatorSaveItem"
        Me.MusicBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 23)
        Me.MusicBindingNavigatorSaveItem.Text = "Save Data"
        '
        'IDLabel
        '
        IDLabel.AutoSize = True
        IDLabel.Location = New System.Drawing.Point(30, 34)
        IDLabel.Name = "IDLabel"
        IDLabel.Size = New System.Drawing.Size(21, 13)
        IDLabel.TabIndex = 1
        IDLabel.Text = "ID:"
        '
        'IDTextBox
        '
        Me.IDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MusicBindingSource, "ID", True))
        Me.IDTextBox.Location = New System.Drawing.Point(57, 31)
        Me.IDTextBox.Name = "IDTextBox"
        Me.IDTextBox.Size = New System.Drawing.Size(100, 20)
        Me.IDTextBox.TabIndex = 2
        '
        'AlbumLabel
        '
        AlbumLabel.AutoSize = True
        AlbumLabel.Location = New System.Drawing.Point(12, 63)
        AlbumLabel.Name = "AlbumLabel"
        AlbumLabel.Size = New System.Drawing.Size(39, 13)
        AlbumLabel.TabIndex = 3
        AlbumLabel.Text = "Album:"
        '
        'AlbumTextBox
        '
        Me.AlbumTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MusicBindingSource, "Album", True))
        Me.AlbumTextBox.Location = New System.Drawing.Point(57, 60)
        Me.AlbumTextBox.Name = "AlbumTextBox"
        Me.AlbumTextBox.Size = New System.Drawing.Size(100, 20)
        Me.AlbumTextBox.TabIndex = 4
        '
        'ArtistLabel
        '
        ArtistLabel.AutoSize = True
        ArtistLabel.Location = New System.Drawing.Point(18, 89)
        ArtistLabel.Name = "ArtistLabel"
        ArtistLabel.Size = New System.Drawing.Size(33, 13)
        ArtistLabel.TabIndex = 5
        ArtistLabel.Text = "Artist:"
        '
        'ArtistTextBox
        '
        Me.ArtistTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MusicBindingSource, "Artist", True))
        Me.ArtistTextBox.Location = New System.Drawing.Point(57, 86)
        Me.ArtistTextBox.Name = "ArtistTextBox"
        Me.ArtistTextBox.Size = New System.Drawing.Size(100, 20)
        Me.ArtistTextBox.TabIndex = 6
        '
        'GenreLabel
        '
        GenreLabel.AutoSize = True
        GenreLabel.Location = New System.Drawing.Point(12, 115)
        GenreLabel.Name = "GenreLabel"
        GenreLabel.Size = New System.Drawing.Size(39, 13)
        GenreLabel.TabIndex = 7
        GenreLabel.Text = "Genre:"
        '
        'GenreTextBox
        '
        Me.GenreTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MusicBindingSource, "Genre", True))
        Me.GenreTextBox.Location = New System.Drawing.Point(57, 112)
        Me.GenreTextBox.Name = "GenreTextBox"
        Me.GenreTextBox.Size = New System.Drawing.Size(100, 20)
        Me.GenreTextBox.TabIndex = 8
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 264)
        Me.Controls.Add(GenreLabel)
        Me.Controls.Add(Me.GenreTextBox)
        Me.Controls.Add(ArtistLabel)
        Me.Controls.Add(Me.ArtistTextBox)
        Me.Controls.Add(AlbumLabel)
        Me.Controls.Add(Me.AlbumTextBox)
        Me.Controls.Add(IDLabel)
        Me.Controls.Add(Me.IDTextBox)
        Me.Controls.Add(Me.MusicBindingNavigator)
        Me.Name = "frmMain"
        Me.Text = "Form1"
        CType(Me.DatabaseDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MusicBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MusicBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MusicBindingNavigator.ResumeLayout(False)
        Me.MusicBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DatabaseDataSet As Database.DatabaseDataSet
    Friend WithEvents MusicBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents MusicTableAdapter As Database.DatabaseDataSetTableAdapters.MusicTableAdapter
    Friend WithEvents TableAdapterManager As Database.DatabaseDataSetTableAdapters.TableAdapterManager
    Friend WithEvents MusicBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MusicBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents IDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AlbumTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ArtistTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GenreTextBox As System.Windows.Forms.TextBox

End Class

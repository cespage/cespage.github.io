﻿Public Class frmMain

    Private Sub MusicBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MusicBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.MusicBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.DatabaseDataSet)

    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DatabaseDataSet.Music' table. You can move, or remove it, as needed.
        Me.MusicTableAdapter.Fill(Me.DatabaseDataSet.Music)

    End Sub
End Class

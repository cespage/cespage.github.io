﻿Public Class frmMain
    Private Const BLOCK_DEFAULT As String = "[DEFAULT]"
    Private Const BLOCK_INTERNETSHORTCUT As String = "[InternetShortcut]"
    Private Const ITEM_URL As String = "URL="
    Private Const ITEM_BASEURL As String = "BASEURL="

    Private Sub Navigate(ByRef URL As String)
        If String.IsNullOrEmpty(URL) Then Return
        If URL.Equals("about:blank") Then Return
        If Not URL.StartsWith("http://") And _
        Not URL.StartsWith("https://") Then
            URL = "http://" & URL
        End If
        Try
            webMain.Navigate(URL)
        Catch ex As Exception
            ' Do nothing on Exception
        End Try
    End Sub

    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles OpenToolStripMenuItem.Click
        Dim Open As New OpenFileDialog()
        Dim URLFile As String()
        Dim myStreamReader As System.IO.StreamReader
        Open.Filter = "Internet Favourite (*.url)|*.url|All files (*.*)|*.*"
        Open.CheckFileExists = True
        Open.ShowDialog(Me)
        Try
            Open.OpenFile()
            myStreamReader = System.IO.File.OpenText(Open.FileName)
            URLFile = myStreamReader.ReadToEnd().Split(New String() {ControlChars.CrLf}, _
                                                     StringSplitOptions.RemoveEmptyEntries)
            For Each Item As String In URLFile
                If Item.StartsWith(ITEM_URL) Then
                    Navigate(Item.Substring(ITEM_URL.Length))
                    Exit For
                End If
            Next
        Catch ex As Exception
            ' Do nothing on Exception
        End Try
    End Sub

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles SaveToolStripMenuItem.Click
        Dim Save As New SaveFileDialog()
        Dim myStreamWriter As System.IO.StreamWriter
        Save.Filter = "Internet Favourite (*.url)|*.url|All files (*.*)|*.*"
        Save.CheckPathExists = True
        Save.FileName = webMain.DocumentTitle
        Save.ShowDialog(Me)
        Try
            myStreamWriter = System.IO.File.CreateText(Save.FileName)
            myStreamWriter.Write(BLOCK_DEFAULT & vbCrLf & _
                                 ITEM_BASEURL & webMain.Url.ToString & vbCrLf & _
                                 BLOCK_INTERNETSHORTCUT & vbCrLf & _
                                 ITEM_URL & webMain.Url.ToString)
            myStreamWriter.Flush()
        Catch ex As Exception
            ' Do nothing on Exception
        End Try
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles ExitToolStripMenuItem.Click
        Dim Response As MsgBoxResult
        Response = MsgBox("Are you sure you want to Exit Web Browser?", _
                          MsgBoxStyle.Question + MsgBoxStyle.YesNo, _
                          "Web Browser")
        If Response = MsgBoxResult.Yes Then
            End
        End If
    End Sub

    Private Sub CutToolStripMenuItem_Click(ByVal sender As System.Object, _
                                           ByVal e As System.EventArgs) _
                                           Handles CutToolStripMenuItem.Click
        txtURL.Cut()
    End Sub

    Private Sub CopyToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles CopyToolStripMenuItem.Click
        txtURL.Copy()
    End Sub

    Private Sub PasteToolStripMenuItem_Click(ByVal sender As System.Object, _
                                             ByVal e As System.EventArgs) _
                                             Handles PasteToolStripMenuItem.Click
        txtURL.Paste()
    End Sub

    Private Sub SelectAllToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                 ByVal e As System.EventArgs) _
                                                 Handles SelectAllToolStripMenuItem.Click
        txtURL.SelectAll()
    End Sub

    Private Sub GoToToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles GoToToolStripMenuItem.Click
        Navigate(txtURL.Text)
    End Sub

    Private Sub HomeToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles HomeToolStripMenuItem.Click
        webMain.GoHome()
    End Sub

    Private Sub BackToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles BackToolStripMenuItem.Click
        webMain.GoBack()
    End Sub

    Private Sub ForwardToolStripMenuItem_Click(ByVal sender As System.Object, _
                                               ByVal e As System.EventArgs) _
                                               Handles ForwardToolStripMenuItem.Click
        webMain.GoForward()
    End Sub

    Private Sub RefreshToolStripMenuItem_Click(ByVal sender As System.Object, _
                                               ByVal e As System.EventArgs) _
                                               Handles RefreshToolStripMenuItem.Click
        If Not webMain.Url.Equals("about:blank") Then
            webMain.Refresh()
        End If
    End Sub

    Private Sub StopToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles StopToolStripMenuItem.Click
        webMain.Stop()
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs) _
                             Handles MyBase.Load
        Me.Text = "Web Browser"
    End Sub

    Private Sub txtURL_KeyDown(ByVal sender As Object, _
                               ByVal e As System.Windows.Forms.KeyEventArgs) _
                               Handles txtURL.KeyDown
        If (e.KeyCode = Keys.Enter) Then
            Navigate(txtURL.Text)
        End If
    End Sub

    Private Sub webMain_Navigated(ByVal sender As Object, _
                                  ByVal e As System.Windows.Forms.WebBrowserNavigatedEventArgs) _
                                  Handles webMain.Navigated
        Me.Text = "Web Browser - " & webMain.DocumentTitle
        txtURL.Text = webMain.Url.ToString
    End Sub
End Class

﻿Imports System.Xml
Public Class frmMain
    Private Const XML_VERSION As String = "1.0"
    Private Const XML_ENCODE As String = "utf-8"
    Private Const TAG_ROOT As String = "tasklist"
    Private Const TAG_TASK As String = "task"
    Private Const ATTR_VALUE As String = "value"
    Private Const VAL_CHECKED As String = "checked"
    Private Const VAL_UNCHECKED As String = "unchecked"

    Private Sub NewToolStripMenuItem_Click(ByVal sender As System.Object, _
                                           ByVal e As System.EventArgs) _
                                           Handles NewToolStripMenuItem.Click
        Dim Response As MsgBoxResult
        Response = MsgBox("Are you sure you want to start a New Task List?", _
                          MsgBoxStyle.Question + MsgBoxStyle.YesNo, _
                          "Task List")
        If Response = MsgBoxResult.Yes Then
            txtList.Text = ""
            lstMain.Items.Clear()
            Me.Text = "Task List - Untitled"
        End If
    End Sub

    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles OpenToolStripMenuItem.Click
        Dim Open As New OpenFileDialog()
        Dim xmlDoc As New XmlDocument ' XML Document
        Dim strStatus, strValue As String ' Status Strings
        Dim blnChecked As Boolean = False ' Checked Status
        Open.Filter = "Task List Files (*.tsk)|*.tsk|All files (*.*)|*.*"
        Open.CheckFileExists = True
        If Open.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            Try
                txtList.Text = "" ' Reset Item Text
                lstMain.Items.Clear() ' Reset Task List
                Open.OpenFile() ' Open Document
                xmlDoc.Load(Open.FileName) ' Load XML
                If xmlDoc.GetElementsByTagName(TAG_ROOT).Count > 0 Then ' Has correct Root
                    Dim elements As XmlNodeList = xmlDoc.GetElementsByTagName(TAG_TASK)
                    For Each node As XmlNode In elements ' Loop though Tasks
                        If node.Name = TAG_TASK Then ' Read Task
                            strStatus = node.Attributes.GetNamedItem(ATTR_VALUE).Value
                            strValue = node.InnerText ' Task Text
                            If LCase(strStatus) = VAL_CHECKED Then _
                            blnChecked = True Else blnChecked = False
                            lstMain.Items.Add(strValue, blnChecked) ' Add to List
                        End If
                    Next
                End If
                Me.Text = "Task List - " & Open.FileName
            Catch ex As Exception
                ' Do nothing on Exception
            End Try
            lstMain.Focus()
        End If
    End Sub

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles SaveToolStripMenuItem.Click
        Dim Save As New SaveFileDialog()
        Dim i As Integer
        Dim strValue As String
        Dim xmlDoc As New XmlDocument ' XML Document
        Dim xmlDec As XmlDeclaration = xmlDoc.CreateXmlDeclaration(XML_VERSION, XML_ENCODE, Nothing)
        Save.Filter = "Task List Files (*.tsk)|*.tsk|All files (*.*)|*.*"
        Save.CheckPathExists = True
        If Save.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            Try
                Dim rootNode As XmlElement = xmlDoc.CreateElement(TAG_ROOT) ' Root Note
                xmlDoc.InsertBefore(xmlDec, xmlDoc.DocumentElement) ' Document Declaration
                xmlDoc.AppendChild(rootNode) ' Append Declaration to Root
                For i = 0 To lstMain.Items.Count - 1
                    Dim taskNode = xmlDoc.CreateElement(TAG_TASK) ' Create Task Entry
                    If lstMain.GetItemChecked(i) Then _
                    strValue = VAL_CHECKED Else strValue = VAL_UNCHECKED
                    taskNode.SetAttribute(ATTR_VALUE, strValue) ' Set Checked Value
                    Dim taskText As XmlText = xmlDoc.CreateTextNode(CStr(lstMain.Items(i)))
                    taskNode.AppendChild(taskText) ' Add Task Text
                    xmlDoc.DocumentElement.AppendChild(taskNode) ' Append Node
                Next
                xmlDoc.Save(Save.FileName) ' Save Document
                Me.Text = "Task List - " & Save.FileName
            Catch ex As Exception
                ' Do nothing on Exception
            End Try
            lstMain.Focus()
        End If
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, _
                                        ByVal e As System.EventArgs) _
                                        Handles ExitToolStripMenuItem.Click
        Dim Response As MsgBoxResult
        Response = MsgBox("Are you sure you want to Exit Task List?", _
                          MsgBoxStyle.Question + MsgBoxStyle.YesNo, _
                          "Task List")
        If Response = MsgBoxResult.Yes Then
            End
        End If
    End Sub

    Private Sub CutToolStripMenuItem_Click(ByVal sender As System.Object, _
                                           ByVal e As System.EventArgs) _
                                           Handles CutToolStripMenuItem.Click
        If lstMain.SelectedIndex > -1 Then ' Make sure something is Selected
            Clipboard.SetData(System.Windows.Forms.DataFormats.Serializable, _
                              lstMain.Items.Item(lstMain.SelectedIndex)) ' Copy
            lstMain.Items.RemoveAt(lstMain.SelectedIndex) ' Remove Item
        End If
        lstMain.Focus()
    End Sub

    Private Sub CopyToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles CopyToolStripMenuItem.Click
        If lstMain.SelectedIndex > -1 Then ' Make sure something is Selected
            Clipboard.SetData(System.Windows.Forms.DataFormats.Serializable, _
                              lstMain.Items.Item(lstMain.SelectedIndex)) ' Copy
        End If
        lstMain.Focus()
    End Sub

    Private Sub PasteToolStripMenuItem_Click(ByVal sender As System.Object, _
                                             ByVal e As System.EventArgs) _
                                             Handles PasteToolStripMenuItem.Click
        If Not Clipboard.GetData(System.Windows.Forms.DataFormats.Serializable) Is Nothing Then
            If lstMain.SelectedIndex > -1 Then ' Paste after Selected Item
                lstMain.Items.Insert(lstMain.SelectedIndex, _
                                     Clipboard.GetData(System.Windows.Forms.DataFormats.Serializable))
            Else ' Or Paste at List End if no Selection
                lstMain.Items.Add(Clipboard.GetData(System.Windows.Forms.DataFormats.Serializable))
            End If
        End If
        lstMain.Focus()
    End Sub

    Private Sub AddToolStripMenuItem_Click(ByVal sender As System.Object, _
                                           ByVal e As System.EventArgs) _
                                           Handles AddToolStripMenuItem.Click
        If Trim(txtList.Text) <> "" Then ' Check for an item
            If lstMain.SelectedIndex > -1 Then ' Insert before Selected Item
                lstMain.Items.Insert(lstMain.SelectedIndex, txtList.Text)
            Else ' Or Add at List End
                lstMain.Items.Add(txtList.Text)
            End If
        End If
        lstMain.Focus()
    End Sub

    Private Sub RemoveToolStripMenuItem_Click(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) _
                                              Handles RemoveToolStripMenuItem.Click
        If lstMain.SelectedIndex > -1 Then
            lstMain.Items.RemoveAt(lstMain.SelectedIndex) ' Remove
        End If
        lstMain.Focus()
    End Sub

    Private Sub CheckAllToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                ByVal e As System.EventArgs) _
                                                Handles CheckAllToolStripMenuItem.Click
        If lstMain.Items.Count > 0 Then
            For i As Integer = 0 To lstMain.Items.Count - 1
                lstMain.SetItemChecked(i, True) ' Check to True
            Next
        End If
        lstMain.Focus()
    End Sub

    Private Sub UncheckAllToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                  ByVal e As System.EventArgs) _
                                                  Handles UncheckAllToolStripMenuItem.Click
        If lstMain.Items.Count > 0 Then
            For i As Integer = 0 To lstMain.Items.Count - 1
                lstMain.SetItemChecked(i, False) ' Check to False
            Next
        End If
        lstMain.Focus()
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, _
                     ByVal e As System.EventArgs) _
                     Handles MyBase.Load
        txtList.Text = ""
        lstMain.Items.Clear()
        Me.Text = "Task List - Untitled"
    End Sub
End Class
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.White
        Me.PictureBox1.Location = New System.Drawing.Point(8, 56)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(280, 200)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'ComboBox1
        '
        Me.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox1.Location = New System.Drawing.Point(8, 8)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(64, 21)
        Me.ComboBox1.TabIndex = 1
        '
        'ComboBox2
        '
        Me.ComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox2.Location = New System.Drawing.Point(80, 8)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(208, 21)
        Me.ComboBox2.TabIndex = 2
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.ComboBox2, Me.ComboBox1, Me.PictureBox1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private DrawBitmap As Bitmap
    Private DrawGraphics As Graphics
    Private DrawBrush As Brush
    Private DrawSize As Integer

    Private Sub Form1_Load(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles MyBase.Load

        DrawBitmap = New Bitmap(PictureBox1.Width, PictureBox1.Height)
        DrawGraphics = Graphics.FromImage(DrawBitmap)
        PictureBox1.Image = DrawBitmap

        With ComboBox1
            .Items.Add(2)
            .Items.Add(4)
            .Items.Add(8)
            .Items.Add(16)
            .Items.Add(32)
            .Items.Add(64)
        End With
        ComboBox1.SelectedIndex = 0

        With ComboBox2
            .Items.Add("Black")
            .Items.Add("Red")
            .Items.Add("Green")
            .Items.Add("Blue")
            .Items.Add("White")
        End With
        ComboBox2.SelectedIndex = 0
    End Sub

    Private Sub PictureBox1_MouseMove(ByVal sender As Object, _
    ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox1.MouseMove
        Select Case ComboBox2.SelectedIndex
            Case 0
                DrawBrush = Brushes.Black
            Case 1
                DrawBrush = Brushes.Red
            Case 2
                DrawBrush = Brushes.Green
            Case 3
                DrawBrush = Brushes.Blue
            Case 4
                DrawBrush = Brushes.White
            Case Else
                DrawBrush = Brushes.Black
        End Select

        If e.Button = Windows.Forms.MouseButtons.Left Then
            DrawSize = CType(ComboBox1.SelectedItem, Integer)
            DrawGraphics.FillEllipse(DrawBrush, e.X, e.Y, DrawSize, DrawSize)
            PictureBox1.Image = DrawBitmap
        End If
    End Sub

End Class

Public Class Form1

    Private DrawBitmap As Bitmap
    Private DrawGraphics As Graphics
    Private DrawBrush As Brush

    Private Sub Form1_Load(ByVal sender As Object, _
    ByVal e As System.EventArgs) Handles Me.Load
        DrawBitmap = New Bitmap(PictureBox1.Width, PictureBox1.Height)
        DrawGraphics = Graphics.FromImage(DrawBitmap)
        PictureBox1.Image = DrawBitmap
        With ComboBox1
            .Items.Add(2)
            .Items.Add(4)
            .Items.Add(8)
            .Items.Add(16)
            .Items.Add(32)
            .Items.Add(64)
        End With
        ComboBox1.SelectedIndex = 0
        With ComboBox2
            .Items.Add("Black")
            .Items.Add("Red")
            .Items.Add("Green")
            .Items.Add("Blue")
            .Items.Add("White")
        End With
        ComboBox2.SelectedIndex = 0
    End Sub

    Private Sub PictureBox1_MouseMove(ByVal sender As Object, _
    ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox1.MouseMove
        If e.Button = Windows.Forms.MouseButtons.Left Then
            Select Case ComboBox2.SelectedIndex
                Case 0
                    DrawBrush = Brushes.Black
                Case 1
                    DrawBrush = Brushes.Red
                Case 2
                    DrawBrush = Brushes.Green
                Case 3
                    DrawBrush = Brushes.Blue
                Case 4
                    DrawBrush = Brushes.White
                Case Else
                    DrawBrush = Brushes.Black
            End Select
            DrawGraphics.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
            DrawGraphics.FillEllipse(DrawBrush, e.X, e.Y, _
            CInt(ComboBox1.SelectedItem), CInt(ComboBox1.SelectedItem))
            PictureBox1.Image = DrawBitmap
        End If
    End Sub
End Class

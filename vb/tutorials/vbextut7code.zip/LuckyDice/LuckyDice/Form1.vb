Public Class Form1

    Private DrawBitmap As Bitmap
    Private DrawGraphics As Graphics
    Private Turn As Integer

    Private Sub Form1_Load(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles MyBase.Load
        Button2.PerformClick()
    End Sub

    Private Sub DiceTopLeft()
        DrawGraphics.FillEllipse(Brushes.Black, _
        6, 6, 12, 12)
    End Sub

    Private Sub DiceTopRight()
        DrawGraphics.FillEllipse(Brushes.Black, _
        DrawBitmap.Width - 18, 6, 12, 12)
    End Sub

    Private Sub DiceCentreLeft()
        DrawGraphics.FillEllipse(Brushes.Black, _
        6, CInt(DrawBitmap.Height / 2 - 6), 12, 12)
    End Sub

    Private Sub DiceCentre()
        DrawGraphics.FillEllipse(Brushes.Black, _
        CInt(DrawBitmap.Width / 2 - 6), _
        CInt(DrawBitmap.Height / 2 - 6), 12, 12)
    End Sub

    Private Sub DiceCentreRight()
        DrawGraphics.FillEllipse(Brushes.Black, _
        DrawBitmap.Width - 18, _
        CInt(DrawBitmap.Height / 2 - 6), 12, 12)
    End Sub

    Private Sub DiceBottomLeft()
        DrawGraphics.FillEllipse(Brushes.Black, _
        6, DrawBitmap.Height - 18, 12, 12)
    End Sub

    Private Sub DiceBottomRight()
        DrawGraphics.FillEllipse(Brushes.Black, _
        DrawBitmap.Width - 18, DrawBitmap.Height - 18, 12, 12)
    End Sub

    Private Sub DiceDraw(ByVal Value As Integer)
        DrawGraphics.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
        Select Case (Value)
            Case 1
                DiceCentre()
            Case 2
                DiceTopLeft()
                DiceBottomRight()
            Case 3
                DiceTopLeft()
                DiceCentre()
                DiceBottomRight()
            Case 4
                DiceTopLeft()
                DiceBottomLeft()
                DiceTopRight()
                DiceBottomRight()
            Case 5
                DiceTopLeft()
                DiceBottomLeft()
                DiceCentre()
                DiceTopRight()
                DiceBottomRight()
            Case 6
                DiceTopLeft()
                DiceCentreLeft()
                DiceBottomLeft()
                DiceTopRight()
                DiceCentreRight()
                DiceBottomRight()
        End Select
    End Sub

    Private Sub DiceOne(ByVal Value As Integer)
        DrawBitmap = New Bitmap(PictureBox1.Width, PictureBox1.Height)
        DrawGraphics = Graphics.FromImage(DrawBitmap)
        DiceDraw(Value)
        PictureBox1.Image = DrawBitmap
    End Sub

    Private Sub DiceTwo(ByVal Value As Integer)
        DrawBitmap = New Bitmap(PictureBox2.Width, PictureBox2.Height)
        DrawGraphics = Graphics.FromImage(DrawBitmap)
        DiceDraw(Value)
        PictureBox2.Image = DrawBitmap
    End Sub

    Private Function DiceValue() As Integer
        Randomize()
        DiceValue = CInt(Int((6 * Rnd()) + 1))
    End Function

    Private Sub Button1_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles Button1.Click
        If Turn = 1 Then
            DiceOne(DiceValue)
            Label1.Text = "Player One"
            Turn = 2
        Else
            DiceTwo(DiceValue)
            Label1.Text = "Player Two"
            Turn = 1
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles Button2.Click
        PictureBox1.Image = Nothing
        PictureBox2.Image = Nothing
        Turn = 1
        Label1.Text = "Player One"
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles Button3.Click
        End
    End Sub
End Class


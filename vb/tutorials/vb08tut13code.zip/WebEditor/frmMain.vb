﻿
Imports mshtml

Public Class frmMain
    Public doc As mshtml.IHTMLDocument2
    Public Sub Command(ByRef Name As String, _
                       Optional ByVal Value As Object = Nothing)
        doc.execCommand(Name, False, Value)
    End Sub

    Public Function SelectedItem(ByVal Command As String) As Object
        Dim Selection As IHTMLSelectionObject = doc.selection ' Get Selection
        If Not Selection Is Nothing Then
            Dim Range As IHTMLTxtRange = Selection.createRange ' Get the Range
            If Range.queryCommandSupported(Command) And _
            Range.queryCommandEnabled(Command) Then
                Return Range.queryCommandValue(Command)
            End If
        End If
        Return Nothing
    End Function

    Public Sub SelectedText(ByVal Value As String)
        Dim Selection As IHTMLSelectionObject = doc.selection ' Get Selection
        If Not Selection Is Nothing Then
            Dim Range As IHTMLTxtRange = Selection.createRange ' Get the Range
            If Not Range Is Nothing Then
                Range.pasteHTML(Value)
            End If
        End If
    End Sub

    Private Function FontSizeToHTML(ByVal Size As Integer) As Integer
        If Size < 10 Then
            Return 1
        ElseIf Size < 12 Then
            Return 2
        ElseIf Size < 14 Then
            Return 3
        ElseIf Size < 18 Then
            Return 4
        ElseIf Size < 24 Then
            Return 5
        ElseIf Size < 36 Then
            Return 6
        Else
            Return 7
        End If
    End Function

    Private Function FontSizeFromHTML(ByRef Size As Integer) As Single
        Select Case Size
            Case 1
                Return 8.0F
            Case 2
                Return 10.0F
            Case 3
                Return 12.0F
            Case 4
                Return 14.0F
            Case 5
                Return 18.0F
            Case 6
                Return 24.0F
            Case 7
                Return 36.0F
            Case Else
                Return 12.0F
        End Select
    End Function

    Public Function GetFormatFont() As Font
        Try
            Dim FontName As String = SelectedItem("FontName")
            Dim FontSize As String = FontSizeFromHTML(SelectedItem("FontSize"))
            Dim IsBold As Boolean = SelectedItem("Bold")
            Dim IsItalic As Boolean = SelectedItem("Italic")
            Dim TheFontStyle As Integer = 0
            If IsBold Then TheFontStyle = FontStyle.Bold
            If IsItalic Then TheFontStyle = FontStyle.Italic
            If IsBold And IsItalic Then TheFontStyle = FontStyle.Bold + FontStyle.Italic
            If Not (IsBold And IsItalic) Then TheFontStyle = FontStyle.Regular
            Return New Font(FontName, FontSize, TheFontStyle, GraphicsUnit.Point)
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Sub FormatFont(ByRef Font As Font)
        Command("FontName", Font.Name)
        Command("FontSize", FontSizeToHTML(Font.Size))
        If Font.Bold Then
            Command("Bold")
        End If
        If Font.Italic Then
            Command("Italic")
        End If
    End Sub

    Public Sub FormatColour(ByRef Colour As Color)
        Dim strColour As String
        If Not Colour.Equals(Color.Empty) Then
            strColour = ColorTranslator.ToHtml(Colour)
        Else
            strColour = Nothing
        End If
        Command("ForeColor", strColour)
    End Sub

    Public Sub FormatBackground(ByRef Colour As Color)
        Dim strColour As String
        If Not Colour.Equals(Color.Empty) Then
            strColour = ColorTranslator.ToHtml(Colour)
        Else
            strColour = String.Empty
        End If
        doc.bgColor = strColour
    End Sub

    Private Sub NewToolStripMenuItem_Click(ByVal sender As System.Object, _
                                           ByVal e As System.EventArgs) _
                                           Handles NewToolStripMenuItem.Click
        Dim Response As MsgBoxResult
        Response = MsgBox("Are you sure you want to start a New Document?", _
                          MsgBoxStyle.Question + MsgBoxStyle.YesNo, _
                          "Web Editor")
        If Response = MsgBoxResult.Yes Then
            doc.clear()
            webEditor.Navigate("about:blank") ' New Document
            Me.Text = "Web Editor - Untitled"
        End If
    End Sub

    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles OpenToolStripMenuItem.Click
        Dim Open As New OpenFileDialog()
        Open.Filter = "HTML Files (*.html,*.htm)|*.html;*.htm|All files (*.*)|*.*"
        Open.CheckFileExists = True
        If Open.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            Try
                webEditor.Navigate(Open.FileName)
                Me.Text = "Web Editor - " & Open.FileName
            Catch ex As Exception
                ' Do nothing on Exception
            End Try
        End If
    End Sub

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles SaveToolStripMenuItem.Click
        Dim Save As New SaveFileDialog()
        Dim myStreamWriter As System.IO.StreamWriter
        Save.Filter = "HTML Files (*.html)|*.html|All files (*.*)|*.*"
        Save.CheckPathExists = True
        If Save.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            Try
                myStreamWriter = System.IO.File.CreateText(Save.FileName)
                myStreamWriter.Write(webEditor.DocumentText)
                myStreamWriter.Flush()
                Me.Text = "Web Editor - " & Save.FileName
            Catch ex As Exception
                ' Do nothing on Exception
            End Try
        End If
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles ExitToolStripMenuItem.Click
        Dim Response As MsgBoxResult
        Response = MsgBox("Are you sure you want to Exit Web Editor?", _
                          MsgBoxStyle.Question + MsgBoxStyle.YesNo, _
                          "Web Editor")
        If Response = MsgBoxResult.Yes Then
            End
        End If
    End Sub

    Private Sub CutToolStripMenuItem_Click(ByVal sender As System.Object, _
                                           ByVal e As System.EventArgs) _
                                           Handles CutToolStripMenuItem.Click
        Command("Cut")
    End Sub

    Private Sub CopyToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles CopyToolStripMenuItem.Click
        Command("Copy")
    End Sub

    Private Sub PasteToolStripMenuItem_Click(ByVal sender As System.Object, _
                                             ByVal e As System.EventArgs) _
                                             Handles PasteToolStripMenuItem.Click
        Command("Paste")
    End Sub

    Private Sub DeleteToolStripMenuItem_Click(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) _
                                              Handles DeleteToolStripMenuItem.Click
        Command("Delete")
    End Sub

    Private Sub SelectAllToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                 ByVal e As System.EventArgs) _
                                                 Handles SelectAllToolStripMenuItem.Click
        Command("SelectAll")
    End Sub

    Private Sub TimeDateToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                ByVal e As System.EventArgs) _
                                                Handles TimeDateToolStripMenuItem.Click
        SelectedText(Format(Now, "HH:mm dd/MM/yyyy"))
    End Sub

    Private Sub TitleToolStripMenuItem_Click(ByVal sender As System.Object, _
                                             ByVal e As System.EventArgs) _
                                             Handles TitleToolStripMenuItem.Click
        Dim Response As String = "My Website"
        If webEditor.DocumentTitle <> "" Then
            Response = webEditor.DocumentTitle
        End If
        Response = InputBox("Title", "Web Editor", Response)
        If Response <> "" Then
            doc.title = Response
        End If
    End Sub

    Private Sub LinkToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles LinkToolStripMenuItem.Click
        Dim Response As String = "http://www.cespage.com/vb"
        Response = InputBox("Web Address", "Web Editor", Response)
        If Response <> "" Then
            Command("CreateLink", Response)
        End If
    End Sub

    Private Sub ImageToolStripMenuItem_Click(ByVal sender As System.Object, _
                                             ByVal e As System.EventArgs) _
                                             Handles ImageToolStripMenuItem.Click
        Dim Response As String = "http://www.cespage.com/vb/images/vb08tut13.png"
        Response = InputBox("Image URL", "Web Editor", Response)
        If Response <> "" Then
            Command("InsertImage", Response)
        End If
    End Sub

    Private Sub DividerToolStripMenuItem_Click(ByVal sender As System.Object, _
                                               ByVal e As System.EventArgs) _
                                               Handles DividerToolStripMenuItem.Click
        Command("InsertHorizontalRule")
    End Sub

    Private Sub FontToolStripMenuItem_Click(ByVal sender As System.Object, _
                                            ByVal e As System.EventArgs) _
                                            Handles FontToolStripMenuItem.Click
        Dim Font As New FontDialog()
        Font.MaxSize = 36
        Font.ShowEffects = False
        Font.AllowScriptChange = False
        Font.Font = GetFormatFont()
        Font.ShowDialog(Me)
        Try
            FormatFont(Font.Font)
        Catch ex As Exception
            ' Do nothing on Exception
        End Try
    End Sub

    Private Sub ColourToolStripMenuItem_Click(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) _
                                              Handles ColourToolStripMenuItem.Click
        Dim Colour As New ColorDialog()
        Colour.Color = ColorTranslator.FromHtml(doc.fgColor)
        Colour.ShowDialog(Me)
        Try
            FormatColour(Colour.Color)
        Catch ex As Exception
            ' Do nothing on Exception
        End Try
    End Sub

    Private Sub BackgroundToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                  ByVal e As System.EventArgs) _
                                                  Handles BackgroundToolStripMenuItem.Click
        Dim Colour As New ColorDialog()
        Colour.Color = ColorTranslator.FromHtml(doc.bgColor)
        Colour.ShowDialog(Me)
        Try
            FormatBackground(Colour.Color)
        Catch ex As Exception
            ' Do nothing on Exception
        End Try
    End Sub

    Private Sub AlignLeftToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                 ByVal e As System.EventArgs) _
                                                 Handles AlignLeftToolStripMenuItem.Click
        Command("JustifyLeft")
    End Sub

    Private Sub AlignCentreToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                   ByVal e As System.EventArgs) _
                                                   Handles AlignCentreToolStripMenuItem.Click
        Command("JustifyCenter")
    End Sub

    Private Sub AlignRightToolStripMenuItem_Click(ByVal sender As System.Object, _
                                                  ByVal e As System.EventArgs) _
                                                  Handles AlignRightToolStripMenuItem.Click
        Command("JustifyRight")
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs) _
                             Handles MyBase.Load
        webEditor.Navigate("about:blank") ' New Document
        doc = DirectCast(Me.webEditor.Document.DomDocument,  _
        mshtml.IHTMLDocument2) ' Prepare Document
        doc.designMode = "On" ' Design Mode
        Me.Text = "Web Editor - Untitled"
    End Sub
End Class

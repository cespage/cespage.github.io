﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.Clock = New AlarmClock.Clock
        Me.SetAlarm = New System.Windows.Forms.CheckBox
        Me.Alarm = New System.Windows.Forms.DateTimePicker
        Me.Display = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'Clock
        '
        Me.Clock.Alarm = New Date(CType(0, Long))
        Me.Clock.AlarmHand = True
        Me.Clock.AlarmHandColor = System.Drawing.Color.Orange
        Me.Clock.DrawSmoothing = System.Drawing.Drawing2D.SmoothingMode.AntiAlias
        Me.Clock.FaceColour = System.Drawing.Color.RoyalBlue
        Me.Clock.HourHand = True
        Me.Clock.HourHandColor = System.Drawing.Color.WhiteSmoke
        Me.Clock.Location = New System.Drawing.Point(30, 12)
        Me.Clock.MinuteHand = True
        Me.Clock.MinuteHandColor = System.Drawing.Color.Gainsboro
        Me.Clock.MinuteHandTickStyle = AlarmClock.Clock.TickStyle.Normal
        Me.Clock.Name = "Clock"
        Me.Clock.NumeralColour = System.Drawing.Color.WhiteSmoke
        Me.Clock.Numerals = True
        Me.Clock.RimColour = System.Drawing.Color.Blue
        Me.Clock.SecondHand = True
        Me.Clock.SecondHandColor = System.Drawing.Color.Tomato
        Me.Clock.SecondHandTickStyle = AlarmClock.Clock.TickStyle.Normal
        Me.Clock.Size = New System.Drawing.Size(225, 225)
        Me.Clock.TabIndex = 0
        Me.Clock.TextSmoothing = System.Drawing.Text.TextRenderingHint.AntiAlias
        Me.Clock.Time = New Date(2008, 9, 29, 16, 43, 16, 500)
        '
        'SetAlarm
        '
        Me.SetAlarm.AutoSize = True
        Me.SetAlarm.Location = New System.Drawing.Point(30, 244)
        Me.SetAlarm.Name = "SetAlarm"
        Me.SetAlarm.Size = New System.Drawing.Size(71, 17)
        Me.SetAlarm.TabIndex = 1
        Me.SetAlarm.Text = "Set Alarm"
        Me.SetAlarm.UseVisualStyleBackColor = True
        '
        'Alarm
        '
        Me.Alarm.CustomFormat = "hh:mm"
        Me.Alarm.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Alarm.Location = New System.Drawing.Point(116, 241)
        Me.Alarm.Name = "Alarm"
        Me.Alarm.ShowUpDown = True
        Me.Alarm.Size = New System.Drawing.Size(52, 20)
        Me.Alarm.TabIndex = 2
        '
        'Display
        '
        Me.Display.Enabled = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 264)
        Me.Controls.Add(Me.Alarm)
        Me.Controls.Add(Me.SetAlarm)
        Me.Controls.Add(Me.Clock)
        Me.Name = "frmMain"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Clock As AlarmClock.Clock
    Friend WithEvents SetAlarm As System.Windows.Forms.CheckBox
    Friend WithEvents Alarm As System.Windows.Forms.DateTimePicker
    Friend WithEvents Display As System.Windows.Forms.Timer

End Class

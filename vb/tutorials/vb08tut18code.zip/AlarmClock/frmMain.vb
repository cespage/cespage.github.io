﻿Public Class frmMain

    Private Sub Alarm_ValueChanged(ByVal sender As System.Object, _
                                   ByVal e As System.EventArgs) _
                                   Handles Alarm.ValueChanged
        Clock.Alarm = Alarm.Value
    End Sub

    Private Sub Display_Tick(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs) _
                             Handles Display.Tick
        Clock.Time = Now() ' Update Clock Time
        If Format(Clock.Time, "hh:mm:ss") = _
        Format(Clock.Alarm, "hh:mm") & ":00" And _
        SetAlarm.Checked Then
            Display.Stop() ' Stop Clock
            MsgBox("Alarm!", MsgBoxStyle.SystemModal, "Alarm Clock")
            Display.Start() ' Start Clock
        End If
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs) _
                             Handles MyBase.Load
        Clock.Alarm = Now()
        Alarm.Value = Now()
        Me.Text = "Alarm Clock"
    End Sub
End Class

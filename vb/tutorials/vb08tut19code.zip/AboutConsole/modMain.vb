﻿Module modMain

    Sub Main()
        Dim Output As String
        Output = "Computer Information" & vbCrLf & vbCrLf
        For Each Item As System.IO.DriveInfo In My.Computer.FileSystem.Drives
            If Item.IsReady Then
                Output = Output & "Drive:" & Item.VolumeLabel & "(" & Item.Name & ") Space " _
                & Item.TotalFreeSpace & ") Size (" & Item.TotalSize & ")" & vbCrLf
            End If
        Next
        For Each Item As Environment.SpecialFolder In [Enum].GetValues(GetType(Environment.SpecialFolder))
            Output = Output & "Special Folder:" & _
            [Enum].GetName(GetType(Environment.SpecialFolder), Item) _
            & " (" & Environment.GetFolderPath(Item) & ")" & vbCrLf
        Next
        Output = Output & "Memory (Physical):" & My.Computer.Info.AvailablePhysicalMemory & _
        " of " & My.Computer.Info.TotalPhysicalMemory & vbCrLf
        Output = Output & "Memory (Virtual):" & My.Computer.Info.AvailableVirtualMemory & _
        " of " & My.Computer.Info.TotalVirtualMemory & vbCrLf
        Output = Output & "Operating System:" & My.Computer.Info.OSFullName & _
        " Version " & My.Computer.Info.OSVersion & vbCrLf
        Output = Output & "Computer:" & My.Computer.Name & vbCrLf
        Output = Output & vbCrLf & vbCrLf & "Environment Variables" & vbCrLf & vbCrLf
        For Each Item As DictionaryEntry In Environment.GetEnvironmentVariables
            Output = Output & Item.Key & ":" & Item.Value & vbCrLf
        Next
        Console.Write(Output)
        Console.Read()
    End Sub

End Module

﻿Class Window1 
    Private Turn As Integer

    Private Sub Add(ByRef Canvas As Canvas, ByRef Left As Double, _
                ByRef Top As Double, ByRef Right As Double, _
                ByRef Bottom As Double, ByRef Brush As Brush)
        Dim Dot As New Ellipse
        Dot.Width = 12
        Dot.Height = 12
        Dot.Fill = Brush
        Dot.Margin = New Thickness(Left, Top, Right, Bottom)
        Canvas.Children.Add(Dot)
        Dot = Nothing
    End Sub

    Private Sub Face(ByRef Canvas As Canvas, ByRef Value As Integer)
        Dim Brush As SolidColorBrush = Brushes.Black
        Canvas.Children.Clear() ' Clear the Canvas
        Canvas.BitmapEffect = New Windows.Media.Effects.OuterGlowBitmapEffect
        Canvas.Background = Brushes.White
        Select Case Value
            Case 0
                ' Do nothing
            Case 1
                Add(Canvas, Canvas.Height / 2 - 6, Canvas.Height / 2 - 6, _
                   Canvas.Width / 2 - 6, Canvas.Height - 6, Brush) ' Centre
            Case 2
                Add(Canvas, 6, 6, Canvas.Width - 6, _
                    Canvas.Height - 6, Brush) ' Top Left
                Add(Canvas, Canvas.Width - 18, Canvas.Height - 18, _
                    Canvas.Width - 6, Canvas.Height - 6, Brush) ' Bottom Right
            Case 3
                Add(Canvas, 6, 6, Canvas.Width - 6, _
                    Canvas.Height - 6, Brush) ' Top Left
                Add(Canvas, Canvas.Height / 2 - 6, Canvas.Height / 2 - 6, _
                   Canvas.Width / 2 - 6, Canvas.Height - 6, Brush) ' Centre
                Add(Canvas, Canvas.Width - 18, Canvas.Height - 18, _
                    Canvas.Width - 6, Canvas.Height - 6, Brush) ' Bottom Right
            Case 4
                Add(Canvas, 6, 6, Canvas.Width - 6, _
                    Canvas.Height - 6, Brush) ' Top Left
                Add(Canvas, Canvas.Width - 18, 6, Canvas.Width - 12, _
                    Canvas.Height - 6, Brush) ' Top Right
                Add(Canvas, 6, Canvas.Height - 18, _
                    Canvas.Width - 6, Canvas.Height - 6, Brush) ' Bottom Left
                Add(Canvas, Canvas.Width - 18, Canvas.Height - 18, _
                    Canvas.Width - 6, Canvas.Height - 6, Brush) ' Bottom Right
            Case 5
                Add(Canvas, 6, 6, Canvas.Width - 6, _
                    Canvas.Height - 6, Brush) ' Top Left
                Add(Canvas, Canvas.Width - 18, 6, Canvas.Width - 12, _
                    Canvas.Height - 6, Brush) ' Top Right
                Add(Canvas, Canvas.Height / 2 - 6, Canvas.Height / 2 - 6, _
                   Canvas.Width / 2 - 6, Canvas.Height - 6, Brush) ' Centre
                Add(Canvas, 6, Canvas.Height - 18, _
                    Canvas.Width - 6, Canvas.Height - 6, Brush) ' Bottom Left
                Add(Canvas, Canvas.Width - 18, Canvas.Height - 18, _
                    Canvas.Width - 6, Canvas.Height - 6, Brush) ' Bottom Right
            Case 6
                Add(Canvas, 6, 6, Canvas.Width - 6, _
                    Canvas.Height - 6, Brush) ' Top Left
                Add(Canvas, Canvas.Width - 18, 6, Canvas.Width - 12, _
                    Canvas.Height - 6, Brush) ' Top Right
                Add(Canvas, 6, Canvas.Height / 2 - 6, _
                    Canvas.Width - 6, Canvas.Height - 6, Brush) ' Centre Left
                Add(Canvas, Canvas.Width - 18, Canvas.Height / 2 - 6, _
                    Canvas.Width - 12, Canvas.Height - 6, Brush) ' Centre Right
                Add(Canvas, 6, Canvas.Height - 18, _
                    Canvas.Width - 6, Canvas.Height - 6, Brush) ' Bottom Left
                Add(Canvas, Canvas.Width - 18, Canvas.Height - 18, _
                    Canvas.Width - 6, Canvas.Height - 6, Brush) ' Bottom Right
        End Select
    End Sub

    Private Function DiceValue() As Integer
        Randomize()
        DiceValue = CInt(Int((6 * Rnd()) + 1))
    End Function

    Private Sub NewGame()
        Face(DiceOne, 0)
        Face(DiceTwo, 0)
        Turn = 1
        Me.Title = "Player One"
    End Sub

    Private Sub btnRoll_Click(ByVal sender As System.Object, _
                              ByVal e As System.Windows.RoutedEventArgs) _
                              Handles btnRoll.Click
        If Turn = 1 Then
            Face(DiceOne, DiceValue)
            Me.Title = "Player One"
            Turn = 2
        Else
            Face(DiceTwo, DiceValue)
            Me.Title = "Player Two"
            Turn = 1
        End If
    End Sub

    Private Sub btnNew_Click(ByVal sender As System.Object, _
                             ByVal e As System.Windows.RoutedEventArgs) _
                             Handles btnNew.Click
        NewGame()
    End Sub

    Private Sub Window1_Loaded(ByVal sender As Object, _
                               ByVal e As System.Windows.RoutedEventArgs) _
                               Handles Me.Loaded
        NewGame()
    End Sub
End Class

Public Class Form1

    Private DrawBitmap As Bitmap
    Private DrawGraphics As Graphics


    Private Sub Form1_Load(ByVal sender As System.Object, _
                           ByVal e As System.EventArgs) _
                           Handles MyBase.Load
        DrawBitmap = New Bitmap(PictureBox1.Width, PictureBox1.Height)
        DrawGraphics = Graphics.FromImage(DrawBitmap)
        PictureBox1.Image = DrawBitmap
    End Sub

    Private Sub PictureBox1_MouseMove(ByVal sender As Object, _
                                      ByVal e As System.Windows.Forms.MouseEventArgs) _
                                      Handles PictureBox1.MouseMove
        If e.Button = Windows.Forms.MouseButtons.Left Then
            DrawGraphics.FillEllipse(Brushes.Blue, e.X, e.Y, 8, 8)
            PictureBox1.Image = DrawBitmap
        End If
    End Sub
End Class

﻿Partial Public Class MainPage
    Inherits UserControl

    Public Sub New()
        InitializeComponent()
        For H As Integer = 0 To 23
            AlarmHours.Items.Add(Format(H, "00"))
        Next
        AlarmHours.SelectedItem = CStr(Format(Now.Hour, "00"))
        For M As Integer = 0 To 59
            AlarmMinutes.Items.Add(Format(M, "00"))
        Next
        AlarmMinutes.SelectedItem = CStr(Format(Now.Minute, "00"))
    End Sub

    Private Sub AlarmClock_Triggered() Handles AlarmClock.Triggered
        MessageBox.Show("Alarm!", "Alarm Clock", MessageBoxButton.OK)
    End Sub

    Private Sub SetAlarm_Click(ByVal sender As System.Object, _
                               ByVal e As System.Windows.RoutedEventArgs) _
                           Handles SetAlarm.Click
        If SetAlarm.IsChecked Then
            AlarmClock.Alarm = New DateTime(Now.Year, Now.Month, Now.Day, _
                                         CInt(AlarmHours.SelectedItem), _
                                         CInt(AlarmMinutes.SelectedItem), 0)
        Else
            AlarmClock.Alarm = Nothing
        End If
    End Sub
End Class
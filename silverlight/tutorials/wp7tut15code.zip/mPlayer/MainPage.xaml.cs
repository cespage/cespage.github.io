﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Threading;

namespace mPlayer
{
    public partial class MainPage : PhoneApplicationPage
    {
        DispatcherTimer _position = new DispatcherTimer();

        // Constructor
        public MainPage()
        {
            InitializeComponent();
            ApplicationTitle.Text = "mPLAYER";
            Player.MediaOpened += (object s, RoutedEventArgs args) =>
            {
                // Media Opened Event
                Position.Maximum = (int)Player.NaturalDuration.TimeSpan.TotalMilliseconds;
                Player.Play();
            };
            Player.MediaEnded += (object s, RoutedEventArgs args) =>
            {
                // Media Ended Event
                Player.Stop();
            };
            Player.CurrentStateChanged += (object s, RoutedEventArgs args) =>
            {
                // Media State Changed Event
                if (Player.CurrentState == MediaElementState.Playing)
                {
                    _position.Start();
                }
                else
                {
                    _position.Stop();
                }
            };
            _position.Tick += (object s, EventArgs args) =>
            {
                // Position Tick Event
                Position.Value = (int)Player.Position.TotalMilliseconds;
            };
        }

        private void Go_Click(object sender, RoutedEventArgs e)
        {
            Player.Source = new Uri(Location.Text, UriKind.Absolute);
        }

        private void Volume_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (Volume != null)
            {
                Player.Volume = (double)Volume.Value;
            }
        }

        private void Play_Click(object sender, EventArgs e)
        {
            if (Player.CurrentState == MediaElementState.Playing)
            {
                Player.Pause();
            }
            else
            {
                Player.Play();
            }
        }

        private void Stop_Click(object sender, EventArgs e)
        {
            Player.Stop();
        }


    }
}

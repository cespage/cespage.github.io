﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace TweetView
{
    public class Tweet
    {
        private string _avatar;
        private string _title;
        private string _author;
        private DateTime _published;

        public string Avatar
        {
            get { return _avatar; }
            set { _avatar = value; }
        }

        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }

        public string Author
        {
            get { return _author; }
            set { _author = value; }
        }

        public DateTime Published
        {
            get { return _published; }
            set { _published = value; }
        }
    }
}

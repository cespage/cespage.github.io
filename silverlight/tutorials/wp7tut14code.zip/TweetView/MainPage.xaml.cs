﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Xml.Linq;

namespace TweetView
{
    public partial class MainPage : PhoneApplicationPage
    {

        private void Tweets(object Sender, DownloadStringCompletedEventArgs e)
        {
            XElement _xml;
            System.Globalization.CultureInfo provider =
            System.Globalization.CultureInfo.InvariantCulture;
            try
            {
                if (!e.Cancelled)
                {
                    _xml = XElement.Parse(e.Result);
                    foreach (XElement value in _xml.Elements("status"))
                    {
                        Tweet _tweet = new Tweet();
                        _tweet.Avatar = value.Element("user").Element("profile_image_url").Value;
                        _tweet.Title = value.Element("text").Value;
                        _tweet.Published = DateTime.ParseExact(value.Element("created_at").Value,
                        "ddd MMM dd HH:mm:ss zzzzz yyyy", provider);
                        _tweet.Author = value.Element("user").Element("screen_name").Value;
                        Results.Items.Add(_tweet);
                    }
                }
            }
            catch
            {
                // Ignore Errors
            }
        }

        private void Query(string Value)
        {
            WebClient _client = new WebClient();
            _client.DownloadStringCompleted += Tweets;
            _client.DownloadStringAsync(new Uri(("http://api.twitter.com/1/statuses/user_timeline.xml?screen_name="
            + HttpUtility.UrlEncode(Value))));
        }

        private void Lookup_Click(object sender, RoutedEventArgs e)
        {
            Query(Subject.Text);
        }

        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }
    }
}

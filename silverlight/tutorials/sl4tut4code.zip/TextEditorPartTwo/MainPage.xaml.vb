﻿Partial Public Class MainPage
    Inherits UserControl

    Public Sub New()
        InitializeComponent()
    End Sub

    Private Sub New_Click(ByVal sender As System.Object, _
                          ByVal e As System.Windows.RoutedEventArgs) _
                      Handles [New].Click
        If MessageBox.Show("Start a New Document?", "Text Editor", _
                   MessageBoxButton.OKCancel) = MessageBoxResult.OK Then
            Editor.Text = ""
        End If
    End Sub

    Private Sub Open_Click(ByVal sender As System.Object, _
                           ByVal e As System.Windows.RoutedEventArgs) _
                       Handles Open.Click
        Dim OpenDialog As New OpenFileDialog
        OpenDialog.Filter = "Plain Text Files (*.txt)|*.txt"
        If OpenDialog.ShowDialog Then
            Try
                If OpenDialog.File.Exists Then
                    Editor.Text = OpenDialog.File.OpenText.ReadToEnd
                End If
            Catch ex As Exception
                ' Ignore Errors
            End Try
        End If
    End Sub

    Private Sub Save_Click(ByVal sender As System.Object, _
                           ByVal e As System.Windows.RoutedEventArgs) _
                       Handles Save.Click
        Dim SaveDialog As New SaveFileDialog
        SaveDialog.Filter = "Plain Text Files (*.txt)|*.txt"
        If SaveDialog.ShowDialog Then
            Try
                Using FileStream As IO.StreamWriter = _
                    New IO.StreamWriter(SaveDialog.OpenFile)
                    FileStream.Write(Editor.Text)
                End Using
            Catch ex As Exception
                ' Ignore Errors
            End Try
        End If
    End Sub

    Private Sub Cut_Click(ByVal sender As System.Object, _
                          ByVal e As System.Windows.RoutedEventArgs) _
                      Handles Cut.Click
        Clipboard.SetText(Editor.SelectedText)
        Editor.SelectedText = ""
        Editor.Focus()
    End Sub

    Private Sub Copy_Click(ByVal sender As System.Object, _
                           ByVal e As System.Windows.RoutedEventArgs) _
                       Handles Copy.Click
        Clipboard.SetText(Editor.SelectedText)
        Editor.Focus()
    End Sub

    Private Sub Paste_Click(ByVal sender As System.Object, _
                            ByVal e As System.Windows.RoutedEventArgs) _
                        Handles Paste.Click
        If Clipboard.ContainsText Then
            Editor.SelectedText = Clipboard.GetText
        End If
        Editor.Focus()
    End Sub
End Class
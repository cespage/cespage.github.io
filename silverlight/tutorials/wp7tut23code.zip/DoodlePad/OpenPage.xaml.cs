﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.IO.IsolatedStorage;
using System.Xml.Linq;
using System.Windows.Ink;

namespace DoodlePad
{
    public partial class OpenPage : PhoneApplicationPage
    {
        public App app = (App)Application.Current;

        public OpenPage()
        {
            InitializeComponent();
            ApplicationTitle.Text = "DOODLE PAD";
            PageTitle.Text = "open";
            Loaded += (object sender, RoutedEventArgs e) =>
            {
                using (IsolatedStorageFile storage = IsolatedStorageFile.GetUserStoreForApplication())
                {
                    foreach (string filename in storage.GetFileNames("*.ipr"))
                    {
                        Files.Items.Add(filename.ToLower());
                    }
                }
            };
        }

        private void Open_Click(object sender, EventArgs e)
        {
            if (Files.SelectedItem != null)
            {
                app.Filename = (string)Files.SelectedItem;
                using (IsolatedStorageFile storage = IsolatedStorageFile.GetUserStoreForApplication())
                {
                    XElement _xml;
                    Stroke _stroke = new Stroke();
                    StrokeCollection _strokes = new StrokeCollection();
                    DrawingAttributes _drawAttr = new DrawingAttributes();
                    IsolatedStorageFileStream location = new IsolatedStorageFileStream(app.Filename,
                    System.IO.FileMode.Open, storage);
                    System.IO.StreamReader file = new System.IO.StreamReader(location);
                    _xml = XElement.Parse(file.ReadToEnd());
                    foreach (XElement element in _xml.Elements("Stroke"))
                    {
                        foreach (XElement item in element.Elements("Stroke.DrawingAttributes")
                        .Elements("DrawingAttributes"))
                        {
                            _drawAttr = new DrawingAttributes
                            {
                                Color = Color.FromArgb(
                                  byte.Parse(item.Attribute("Color").Value.Substring(1, 2),
                                  System.Globalization.NumberStyles.HexNumber),
                                  byte.Parse(item.Attribute("Color").Value.Substring(3, 2),
                                  System.Globalization.NumberStyles.HexNumber),
                                  byte.Parse(item.Attribute("Color").Value.Substring(5, 2),
                                  System.Globalization.NumberStyles.HexNumber),
                                  byte.Parse(item.Attribute("Color").Value.Substring(7, 2),
                                  System.Globalization.NumberStyles.HexNumber)),
                                Width = double.Parse(item.Attribute("Width").Value),
                                Height = double.Parse(item.Attribute("Height").Value)
                            };
                        }
                        foreach (XElement item in element.Elements("Stroke.StylusPoints"))
                        {
                            _stroke = new Stroke();
                            _stroke.DrawingAttributes = _drawAttr;
                            foreach (XElement point in item.Elements("StylusPoint"))
                            {
                                _stroke.StylusPoints.Add(new StylusPoint
                                {
                                    X = double.Parse(point.Attribute("X").Value),
                                    Y = double.Parse(point.Attribute("Y").Value)
                                });
                            }
                            _strokes.Add(_stroke);
                        }
                    }
                    app.Content = _strokes;
                    file.Dispose();
                    location.Dispose();
                }
                NavigationService.GoBack();
            }
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            if (Files.SelectedItem != null)
            {
                string _selected = (string)Files.SelectedItem;
                if (MessageBox.Show("Delete selected Item " + _selected + "?", "Doodle Pad",
                MessageBoxButton.OKCancel) == MessageBoxResult.OK)
                {
                    using (IsolatedStorageFile storage = IsolatedStorageFile.GetUserStoreForApplication())
                    {
                        if (storage.FileExists(_selected))
                        {
                            storage.DeleteFile(_selected);
                        }
                    }
                    NavigationService.GoBack();
                }
            }
        }


    }
}

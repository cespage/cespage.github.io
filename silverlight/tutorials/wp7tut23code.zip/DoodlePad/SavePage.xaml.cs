﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.IO.IsolatedStorage;
using System.Xml.Linq;
using System.Windows.Ink;

namespace DoodlePad
{
    public partial class SavePage : PhoneApplicationPage
    {
        public App app = (App)Application.Current;

        public SavePage()
        {
            InitializeComponent();
            ApplicationTitle.Text = "DOODLE PAD";
            PageTitle.Text = "save";
            Loaded += (object sender, RoutedEventArgs e) =>
            {
                if (app.Filename == null || app.Filename == "")
                {
                    Filename.Text = "untitled.ipr";
                }
                else
                {
                    Filename.Text = app.Filename;
                }
            };
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (Filename.Text != "")
            {
                try
                {
                    app.Filename = Filename.Text.Trim().ToLower();
                    using (IsolatedStorageFile storage = IsolatedStorageFile.GetUserStoreForApplication())
                    {
                        XDocument _doc = new XDocument();
                        StrokeCollection _strokes = new StrokeCollection();
                        _strokes = (StrokeCollection)app.Content;
                        XElement _strokecollection = new XElement("StrokeCollection");
                        foreach (Stroke item in _strokes)
                        {
                            XElement _stroke = new XElement("Stroke");
                            XElement _strokeAttr = new XElement("Stroke.DrawingAttributes");
                            XElement _attributes = new XElement("DrawingAttributes");
                            XAttribute _color = new XAttribute("Color", item.DrawingAttributes.Color);
                            XAttribute _width = new XAttribute("Width", item.DrawingAttributes.Width);
                            XAttribute _height = new XAttribute("Height", item.DrawingAttributes.Height);
                            _attributes.Add(_color, _width, _height);
                            _strokeAttr.Add(_attributes);
                            XElement _points = new XElement("Stroke.StylusPoints");
                            foreach (StylusPoint point in item.StylusPoints)
                            {
                                XElement _point = new XElement("StylusPoint");
                                XAttribute _x = new XAttribute("X", point.X);
                                XAttribute _y = new XAttribute("Y", point.Y);
                                _point.Add(_x, _y);
                                _points.Add(_point);
                            }
                            _stroke.Add(_strokeAttr, _points);
                            _strokecollection.Add(_stroke);
                        }
                        _doc = new XDocument(new XDeclaration("1.0", "utf-8", "yes"), _strokecollection);
                        IsolatedStorageFileStream location = new IsolatedStorageFileStream(app.Filename,
                        System.IO.FileMode.Create, storage);
                        System.IO.StreamWriter file = new System.IO.StreamWriter(location);
                        _doc.Save(file);
                        app.Content = null;
                        file.Dispose();
                        location.Dispose();
                    }
                    NavigationService.GoBack();
                }
                catch
                {
                    // Ignore Errors
                }
            }
        }


    }
}

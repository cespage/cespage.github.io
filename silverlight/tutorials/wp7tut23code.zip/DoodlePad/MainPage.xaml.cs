﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Xml.Linq;
using System.Windows.Ink;

namespace DoodlePad
{
    public partial class MainPage : PhoneApplicationPage
    {
        public App app = (App)Application.Current;
        public Stroke drawStroke;
        public Color drawColour = Colors.Black;
        public Size drawSize = new Size { Height = 5, Width = 5 };

        private void New_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Start a new Doodle?", "Doodle Pad",
            MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                PageTitle.Text = "untitled.ipr";
                Surface.Strokes.Clear();
                app.Filename = PageTitle.Text;
                app.Content = Surface.Strokes;
            }
        }

        private void Open_Click(object sender, EventArgs e)
        {
            app.Content = Surface.Strokes;
            NavigationService.Navigate(new Uri("/OpenPage.xaml", UriKind.Relative));
        }

        private void Save_Click(object sender, EventArgs e)
        {
            app.Content = Surface.Strokes;
            NavigationService.Navigate(new Uri("/SavePage.xaml", UriKind.Relative));
        }

        private void Surface_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            drawStroke = new Stroke();
            drawStroke.DrawingAttributes.Color = drawColour;
            drawStroke.DrawingAttributes.Width = drawSize.Width;
            drawStroke.DrawingAttributes.Height = drawSize.Height;
            drawStroke.StylusPoints.Add(new StylusPoint
            {
                X = e.GetPosition(Surface).X,
                Y = e.GetPosition(Surface).Y
            });
            Surface.Strokes.Add(drawStroke);
        }

        private void Surface_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            drawStroke = null;
        }

        private void Surface_MouseMove(object sender, MouseEventArgs e)
        {
            if (drawStroke != null)
            {
                drawStroke.StylusPoints.Add(new StylusPoint
                {
                    X = e.GetPosition(Surface).X,
                    Y = e.GetPosition(Surface).Y
                });
            }
        }

        private void Size_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Size != null)
            {
                double _drawWidth = double.Parse(((ListBoxItem)Size.SelectedItem).Tag.ToString());
                drawSize = new Size { Height = _drawWidth, Width = _drawWidth };
            }
        }

        private void Colour_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Colour != null)
            {
                string _colour = (string)((ListBoxItem)Colour.SelectedItem).Tag;
                drawColour = Color.FromArgb(
                  byte.Parse(_colour.Substring(0, 2),
                  System.Globalization.NumberStyles.HexNumber),
                  byte.Parse(_colour.Substring(2, 2),
                  System.Globalization.NumberStyles.HexNumber),
                  byte.Parse(_colour.Substring(4, 2),
                  System.Globalization.NumberStyles.HexNumber),
                  byte.Parse(_colour.Substring(6, 2),
                  System.Globalization.NumberStyles.HexNumber));
            }
        }

        // Constructor
        public MainPage()
        {
            InitializeComponent();
            ApplicationTitle.Text = "DOODLE PAD";
            PageTitle.Text = "untitled.ipr";
            Loaded += (object sender, RoutedEventArgs e) =>
            {
                if (app.Content != null)
                {
                    Surface.Strokes.Clear();
                    Surface.Strokes = (StrokeCollection)app.Content;
                }
                if (app.Filename == null || app.Filename == "")
                {
                    PageTitle.Text = "untitled.ipr";
                }
                else
                {
                    PageTitle.Text = app.Filename;
                }
            };
        }
    }
}


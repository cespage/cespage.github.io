﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.IO.IsolatedStorage;

namespace ApplicationSettings
{
    public class Settings : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String info)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(info));
            }
        }
        private IsolatedStorageSettings appSettings = IsolatedStorageSettings.ApplicationSettings;

        public object Get(string key)
        {
            return appSettings.Contains(key) ? appSettings[key] : null;
        }

        public void Set(string key, object value)
        {
            if (appSettings.Contains(key)) { appSettings[key] = value; }
            else { appSettings.Add(key, value); }
            appSettings.Save();
        }

        public object Default(object value, object fallback)
        {
            return value == null ? fallback : value;
        }

        public string PageTitle
        {
            get { return (string)Default(Get("pagetitle"), "page title"); }
            set
            {
                Set("pagetitle", value);
                NotifyPropertyChanged("PageTitle");
            }
        }

        public Visibility ShowTitle
        {
            get { return (Visibility)Default(Get("showtitle"), Visibility.Visible); }
        }

        public bool ShowTitleToggle
        {
            get { return ShowTitle == Visibility.Visible; }
            set
            {
                Set("showtitle", value ? Visibility.Visible : Visibility.Collapsed);
                NotifyPropertyChanged("ShowTitle");
                NotifyPropertyChanged("ShowTitleToggle");
                NotifyPropertyChanged("ShowTitleText");
            }
        }

        public string ShowTitleText
        {
            get { return ShowTitleToggle ? "on" : "off"; }
        }
    }
}

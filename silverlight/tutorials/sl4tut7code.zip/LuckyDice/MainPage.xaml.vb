﻿Partial Public Class MainPage
    Inherits UserControl

    Public Sub New()
        InitializeComponent()
    End Sub

    Private Sub Add(ByRef Grid As Grid, _
                    ByRef Row As Integer, _
                    ByRef Column As Integer)
        Dim _dot As New Ellipse
        _dot.Width = 12
        _dot.Height = 12
        _dot.Fill = New SolidColorBrush(Colors.Black)
        _dot.SetValue(Grid.ColumnProperty, Column)
        _dot.SetValue(Grid.RowProperty, Row)
        Grid.Children.Add(_dot)
    End Sub

    Private Function Dice(ByRef Value As Integer) As Grid
        Dim _grid As New Grid
        _grid.Height = 54
        _grid.Width = 54
        For Index As Integer = 0 To 2 ' 3 by 3 Grid
            _grid.RowDefinitions.Add(New RowDefinition)
            _grid.ColumnDefinitions.Add(New ColumnDefinition)
        Next
        Select Case Value
            Case 0
                ' No Dots
            Case 1
                Add(_grid, 1, 1) ' Middle
            Case 2
                Add(_grid, 0, 2) ' Top Right
                Add(_grid, 2, 0) ' Bottom Left
            Case 3
                Add(_grid, 0, 2) ' Top Right
                Add(_grid, 1, 1) ' Middle
                Add(_grid, 2, 0) ' Bottom Left
            Case 4
                Add(_grid, 0, 0) ' Top Left
                Add(_grid, 0, 2) ' Top Right
                Add(_grid, 2, 0) ' Bottom Left
                Add(_grid, 2, 2) ' Bottom Right
            Case 5
                Add(_grid, 0, 0) ' Top Left
                Add(_grid, 0, 2) ' Top Right
                Add(_grid, 1, 1) ' Middle
                Add(_grid, 2, 0) ' Bottom Left
                Add(_grid, 2, 2) ' Bottom Right
            Case 6
                Add(_grid, 0, 0) ' Top Left
                Add(_grid, 0, 2) ' Top Right
                Add(_grid, 1, 0) ' Middle Left
                Add(_grid, 1, 2) ' Middle Right
                Add(_grid, 2, 0) ' Bottom Left
                Add(_grid, 2, 2) ' Bottom Right
        End Select
        Return _grid
    End Function

    Private Function Roll() As Integer
        Randomize(Timer)
        Return CInt(Int((6 * Rnd()) + 1))
    End Function

    Private Sub New_Click(ByVal sender As System.Object, _
                          ByVal e As System.Windows.RoutedEventArgs) _
                      Handles [New].Click
        DiceOne.Content = Dice(0)
        DiceTwo.Content = Dice(0)
    End Sub

    Private Sub DiceOne_Click(ByVal sender As System.Object, _
                              ByVal e As System.Windows.RoutedEventArgs) _
                          Handles DiceOne.Click
        DiceOne.Content = Dice(Roll)
    End Sub

    Private Sub DiceTwo_Click(ByVal sender As System.Object, _
                              ByVal e As System.Windows.RoutedEventArgs) _
                          Handles DiceTwo.Click
        DiceTwo.Content = Dice(Roll)
    End Sub
End Class
﻿Imports System.Text.RegularExpressions
Partial Public Class MainPage
    Inherits UserControl

    Public Sub New()
        InitializeComponent()
    End Sub

    Private Sub Open_Click(ByVal sender As System.Object, _
                           ByVal e As System.Windows.RoutedEventArgs) _
                       Handles Open.Click
        Dim OpenDialog As New OpenFileDialog
        OpenDialog.Filter = "Internet Favourite (*.url)|*.url"
        If OpenDialog.ShowDialog Then
            Try
                If OpenDialog.File.Exists Then
                    Dim _url As New Regex("^URL=(?<URL>.*)$", RegexOptions.Multiline)
                    Address.Text = _url.Match(OpenDialog.File.OpenText.ReadToEnd).Groups("URL").Value
                End If
            Catch ex As Exception
                ' Ignore Errors
            End Try
        End If
    End Sub

    Private Sub Save_Click(ByVal sender As System.Object, _
                           ByVal e As System.Windows.RoutedEventArgs) _
                       Handles Save.Click
        Dim SaveDialog As New SaveFileDialog
        SaveDialog.Filter = "Internet Favourite (*.url)|*.url"
        If SaveDialog.ShowDialog Then
            Try
                Using FileStream As IO.StreamWriter = _
                  New IO.StreamWriter(SaveDialog.OpenFile)
                    FileStream.Write("[DEFAULT]" & vbCrLf & _
                                     "BASEURL=" & Browser.Source.AbsoluteUri & vbCrLf & _
                                     "[InternetShortcut]" & vbCrLf & _
                                     "URL=" & Browser.Source.AbsoluteUri)
                End Using
            Catch ex As Exception
                ' Ignore Errors
            End Try
        End If
    End Sub

    Private Sub Go_Click(ByVal sender As System.Object, _
                         ByVal e As System.Windows.RoutedEventArgs) _
                     Handles Go.Click
        If Not Address.Text.StartsWith("http://") _
            And Not Address.Text.StartsWith("https://") Then
            Address.Text = "http://" & Address.Text
        End If
        Browser.Navigate(New Uri(Address.Text))
    End Sub
End Class

﻿Public Class Tweet
    Private _title As String
    Private _author As String
    Private _link As String
    Private _published As DateTime

    Public Property Title As String
        Get
            Return _title
        End Get
        Set(ByVal Value As String)
            _title = Value
        End Set
    End Property
    Public Property Author As String
        Get
            Return _author
        End Get
        Set(ByVal Value As String)
            _author = Value
        End Set
    End Property
    Public Property Link As String
        Get
            Return _link
        End Get
        Set(ByVal Value As String)
            _link = Value
        End Set
    End Property
    Public Property Published As DateTime
        Get
            Return _published
        End Get
        Set(ByVal Value As DateTime)
            _published = Value
        End Set
    End Property

End Class

﻿Imports System.Xml.Linq
Partial Public Class MainPage
    Inherits UserControl

    Public Sub New()
        InitializeComponent()
    End Sub

    Private Sub Tweets(ByVal Sender As Object, _
                        ByVal e As DownloadStringCompletedEventArgs)
        Dim _xml As XElement
        Try
            If Not e.Cancelled Then
                _xml = XElement.Parse(e.Result)
                For Each Value As XElement In _xml.<channel>.<item>
                    Dim _tweet As New Tweet
                    _tweet.Title = Value.<title>.Value
                    _tweet.Published = Value.<pubDate>.Value
                    _tweet.Author = Replace(Value.<author>.Value, "@twitter.com", "")
                    _tweet.Link = Value.<link>.Value
                    Results.Items.Add(_tweet)
                Next
            End If
        Catch ex As Exception
            ' Ignore Errors
        End Try
    End Sub

    Private Sub Query(ByRef Value As String)
        Dim _client As New WebClient
        AddHandler _client.DownloadStringCompleted, AddressOf Tweets
        _client.DownloadStringAsync(New Uri("http://search.twitter.com/search.rss?rpp=50&q=" & Value))
    End Sub

    Private Sub Search_Click(ByVal sender As System.Object, _
                             ByVal e As System.Windows.RoutedEventArgs) _
                         Handles Search.Click
        Query(Subject.Text)
    End Sub
End Class

﻿Imports System.ServiceModel.Syndication
Imports System.Windows.Data
Imports System.Text.RegularExpressions
Imports System.Windows.Browser

Partial Public Class MainPage
    Inherits UserControl

    Public Sub New()
        InitializeComponent()
        Location.Text = "http://feeds.feedburner.com/cespageblog"
    End Sub

    Private Sub Go_Click(ByVal sender As System.Object, _
                         ByVal e As System.Windows.RoutedEventArgs) _
                     Handles Go.Click
        Dim _client As New WebClient
        AddHandler _client.OpenReadCompleted, Sub(s As Object, args As OpenReadCompletedEventArgs)
                                                  If Not args.Cancelled Then
                                                      Try
                                                          Dim _reader As XmlReader = XmlReader.Create(args.Result)
                                                          Dim _feed As SyndicationFeed = SyndicationFeed.Load(_reader)
                                                          Title.DataContext = _feed.Items
                                                          Title.SelectedIndex = 0
                                                      Catch ex As Exception
                                                          MessageBox.Show(ex.ToString, "RSS Reader", MessageBoxButton.OK)
                                                      End Try
                                                  End If
                                              End Sub
        _client.OpenReadAsync(New Uri(Location.Text))
    End Sub

    Private Sub Title_SelectionChanged(ByVal sender As System.Object, _
                                       ByVal e As System.Windows.Controls.SelectionChangedEventArgs) _
                                   Handles Title.SelectionChanged
        Content.DataContext = CType(CType(sender, ComboBox).SelectedItem, SyndicationItem)
    End Sub
End Class

Public Class LinkFormatter
    Implements IValueConverter
    Public Function Convert(ByVal value As Object, ByVal targetType As Type, _
                            ByVal parameter As Object, _
                            ByVal culture As System.Globalization.CultureInfo) As Object _
                        Implements IValueConverter.Convert
        Return DirectCast(value, System.Collections.ObjectModel.Collection(Of SyndicationLink)).FirstOrDefault.Uri
    End Function

    Public Function ConvertBack(ByVal value As Object, ByVal targetType As Type, _
                                ByVal parameter As Object, _
                                ByVal culture As System.Globalization.CultureInfo) As Object _
                            Implements IValueConverter.ConvertBack
        Throw New NotImplementedException()
    End Function
End Class

Public Class HtmlSanitiser
    Implements IValueConverter
    Public Function Convert(ByVal value As Object, ByVal targetType As Type, _
                            ByVal parameter As Object, _
                            ByVal culture As System.Globalization.CultureInfo) As Object _
                        Implements IValueConverter.Convert
        Dim _convert As String
        _convert = Regex.Replace(TryCast(value, String), "<.*?>", "") ' Remove HTML Tags
        _convert = Regex.Replace(_convert, "\n+\s+", vbLf & vbLf) ' Remove Spaces
        _convert = HttpUtility.HtmlDecode(_convert) ' Decode HTML Entities
        Return _convert
    End Function

    Public Function ConvertBack(ByVal value As Object, ByVal targetType As Type, _
                                ByVal parameter As Object, _
                                ByVal culture As System.Globalization.CultureInfo) As Object _
                            Implements IValueConverter.ConvertBack
        Throw New NotImplementedException()
    End Function
End Class
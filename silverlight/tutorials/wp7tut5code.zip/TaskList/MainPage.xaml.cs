﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace TaskList
{
    public partial class MainPage : PhoneApplicationPage
    {
        public App app = (App)Application.Current;

        // Constructor
        public MainPage()
        {
            InitializeComponent();
            ApplicationTitle.Text = "TASK LIST";
            PageTitle.Text = "untitled.tsk";
            Loaded += (object sender, RoutedEventArgs e) =>
            {
                if (app.Content != null)
                {
                    ListBox _tasks = new ListBox();
                    Tasks.Items.Clear();
                    _tasks = (ListBox)app.Content;
                    foreach (CheckBox Item in _tasks.Items)
                    {
                        CheckBox _task = new CheckBox();
                        _task.Content = Item.Content;
                        _task.IsChecked = Item.IsChecked;
                        Tasks.Items.Add(_task);
                    }
                }
                if (app.Filename != "")
                {
                    PageTitle.Text = app.Filename;
                }
                else
                {
                    PageTitle.Text = "untitled.tsk";
                }
            };
        }

        private void Add_Click(object sender, EventArgs e)
        {
            if (Subject.Text != "") // Has Subject
            {
                CheckBox _item = new CheckBox();
                _item.Content = Subject.Text;
                if (Tasks.SelectedIndex > -1) // Item Selected
                {
                    // Insert before Selected
                    Tasks.Items.Insert(Tasks.SelectedIndex, _item);
                }
                else
                {
                    // Add to List End
                    Tasks.Items.Add(_item);
                }
            }
        }

        private void Remove_Click(object sender, EventArgs e)
        {
            if (Tasks.SelectedIndex > -1) // Item Selected
            {
                // Remove Selected
                Tasks.Items.RemoveAt(Tasks.SelectedIndex);
            }
        }

        private void New_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Start a new Task List?", "Task List",
            MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                PageTitle.Text = "untitled.tsk";
                Tasks.Items.Clear();
                app.Filename = PageTitle.Text;
                app.Content = Tasks.Items;
            }
        }

        private void Open_Click(object sender, EventArgs e)
        {
            app.Content = Tasks;
            NavigationService.Navigate(new Uri("/OpenPage.xaml", UriKind.Relative));
        }

        private void Save_Click(object sender, EventArgs e)
        {
            app.Content = Tasks;
            NavigationService.Navigate(new Uri("/SavePage.xaml", UriKind.Relative));
        }


    }
}

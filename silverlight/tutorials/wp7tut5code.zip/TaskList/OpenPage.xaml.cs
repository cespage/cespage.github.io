﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.IO.IsolatedStorage;
using System.Xml.Linq;

namespace TaskList
{
    public partial class OpenPage : PhoneApplicationPage
    {
        public App app = (App)Application.Current;

        public OpenPage()
        {
            InitializeComponent();
            ApplicationTitle.Text = "TASK LIST";
            PageTitle.Text = "open";
            Loaded += (object sender, RoutedEventArgs e) =>
            {
                Files.Items.Clear();
                using (IsolatedStorageFile storage = IsolatedStorageFile.GetUserStoreForApplication())
                {
                    foreach (string filename in storage.GetFileNames("*.tsk"))
                    {
                        Files.Items.Add(filename.ToLower());
                    }
                }
            };
        }

        private void Open_Click(object sender, RoutedEventArgs e)
        {
            if (Files.SelectedItem != null)
            {
                app.Filename = (string)Files.SelectedItem;
                using (IsolatedStorageFile storage = IsolatedStorageFile.GetUserStoreForApplication())
                {
                    XElement _xml;
                    ListBox _tasks = new ListBox();
                    IsolatedStorageFileStream location = new IsolatedStorageFileStream(app.Filename,
                    System.IO.FileMode.Open, storage);
                    System.IO.StreamReader file = new System.IO.StreamReader(location);
                    _xml = XElement.Parse(file.ReadToEnd());
                    if (_xml.Name.LocalName == "tasklist") // Root
                    {
                        _tasks.Items.Clear();
                        foreach (XElement _task in _xml.Descendants("task"))
                        {
                            CheckBox _item = new CheckBox();
                            _item.IsChecked = _task.FirstAttribute.Value.ToLower() == "checked";
                            _item.Content = _task.Value;
                            _tasks.Items.Add(_item);
                        }
                    }
                    app.Content = _tasks;
                    file.Dispose();
                    location.Dispose();
                }
                NavigationService.GoBack();
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (Files.SelectedItem != null)
            {
                string _selected = (string)Files.SelectedItem;
                if (MessageBox.Show("Delete selected Item " + _selected + "?", "Task List",
                  MessageBoxButton.OKCancel) == MessageBoxResult.OK)
                {
                    using (IsolatedStorageFile storage = IsolatedStorageFile.GetUserStoreForApplication())
                    {
                        if (storage.FileExists(_selected))
                        {
                            storage.DeleteFile(_selected);
                        }
                    }
                    NavigationService.GoBack();
                }
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.IO.IsolatedStorage;
using System.Xml.Linq;

namespace TaskList
{
    public partial class SavePage : PhoneApplicationPage
    {
        public App app = (App)Application.Current;

        public SavePage()
        {
            InitializeComponent();
            ApplicationTitle.Text = "TASK LIST";
            PageTitle.Text = "save";
            Loaded += (object sender, RoutedEventArgs e) =>
            {
                if (app.Filename == "")
                {
                    Filename.Text = "untitled.tsk";
                }
                else
                {
                    Filename.Text = app.Filename;
                }
            };
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (Filename.Text != "")
            {
                try
                {
                    app.Filename = Filename.Text.Trim().ToLower();
                    using (IsolatedStorageFile storage = IsolatedStorageFile.GetUserStoreForApplication())
                    {
                        XDocument _doc = new XDocument();
                        ListBox _tasks = new ListBox();
                        _tasks = (ListBox)app.Content;
                        XElement _items = new XElement("tasklist");
                        foreach (CheckBox _task in _tasks.Items)
                        {
                            _items.Add(new XElement("task", _task.Content, new XAttribute("value",
                            ((bool)_task.IsChecked ? "checked" : "unchecked"))));
                        }
                        _doc = new XDocument(new XDeclaration("1.0", "utf-8", "yes"), _items);
                        IsolatedStorageFileStream location = new IsolatedStorageFileStream(app.Filename,
                        System.IO.FileMode.Create, storage);
                        System.IO.StreamWriter file = new System.IO.StreamWriter(location);
                        _doc.Save(file);
                        app.Content = null;
                        file.Dispose();
                        location.Dispose();
                    }
                    NavigationService.GoBack();
                }
                catch
                {
                    // Ignore Errors
                }
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

    }
}

﻿Imports System.Xml.Linq
Imports System.Windows.Printing
Partial Public Class MainPage
    Inherits UserControl

    Public Sub New()
        InitializeComponent()
    End Sub

    Private Sub Read(ByRef Stream As IO.Stream, ByRef Blocks As BlockCollection)
        Dim _doc As XDocument = XDocument.Load(Stream)
        Dim _colour As String
        For Each _element As XElement In _doc.Descendants("Paragraph")
            Dim _paragraph As New Paragraph
            _paragraph.FontFamily = New FontFamily(_element.Attribute(XName.[Get]("FontFamily")).Value)
            _paragraph.FontSize = Double.Parse(_element.Attribute(XName.[Get]("FontSize")).Value)
            _paragraph.FontStretch = DirectCast(GetType(FontStretches).GetProperty(
            _element.Attribute(XName.[Get]("FontStretch")).Value).GetValue(Nothing, Nothing), FontStretch)
            _paragraph.FontStyle = DirectCast(GetType(FontStyles).GetProperty(
            _element.Attribute(XName.[Get]("FontStyle")).Value).GetValue(Nothing, Nothing), FontStyle)
            _paragraph.FontWeight = DirectCast(GetType(FontWeights).GetProperty(
            _element.Attribute(XName.[Get]("FontWeight")).Value).GetValue(Nothing, Nothing), FontWeight)
            _colour = _element.Attribute(XName.[Get]("Foreground")).Value
            _colour = _colour.Remove(0, 1)
            _paragraph.Foreground = New SolidColorBrush(Color.FromArgb(
              Byte.Parse(_colour.Substring(0, 2), System.Globalization.NumberStyles.HexNumber),
              Byte.Parse(_colour.Substring(2, 2), System.Globalization.NumberStyles.HexNumber),
              Byte.Parse(_colour.Substring(4, 2), System.Globalization.NumberStyles.HexNumber),
              Byte.Parse(_colour.Substring(6, 2), System.Globalization.NumberStyles.HexNumber)))
            For Each _inline As XElement In _element.Descendants("Inline")
                If _inline.Attribute(XName.[Get]("Type")).Value = "Run" Then
                    Dim _run As New Run
                    _run.FontFamily = New FontFamily(_element.Attribute(XName.[Get]("FontFamily")).Value)
                    _run.FontSize = Double.Parse(_element.Attribute(XName.[Get]("FontSize")).Value)
                    _run.FontStretch = DirectCast(GetType(FontStretches).GetProperty(
                    _element.Attribute(XName.[Get]("FontStretch")).Value).GetValue(Nothing, Nothing), FontStretch)
                    _run.FontStyle = DirectCast(GetType(FontStyles).GetProperty(
                    _element.Attribute(XName.[Get]("FontStyle")).Value).GetValue(Nothing, Nothing), FontStyle)
                    _run.FontWeight = DirectCast(GetType(FontWeights).GetProperty(
                    _element.Attribute(XName.[Get]("FontWeight")).Value).GetValue(Nothing, Nothing), FontWeight)
                    _colour = _element.Attribute(XName.[Get]("Foreground")).Value
                    _colour = _colour.Remove(0, 1)
                    _run.Foreground = New SolidColorBrush(Color.FromArgb(
                      Byte.Parse(_colour.Substring(0, 2), System.Globalization.NumberStyles.HexNumber),
                      Byte.Parse(_colour.Substring(2, 2), System.Globalization.NumberStyles.HexNumber),
                      Byte.Parse(_colour.Substring(4, 2), System.Globalization.NumberStyles.HexNumber),
                      Byte.Parse(_colour.Substring(6, 2), System.Globalization.NumberStyles.HexNumber)))
                    If _inline.Attribute(XName.[Get]("TextDecorations")).Value = "Underline" Then
                        _run.TextDecorations = TextDecorations.Underline
                    End If
                    _run.Text = _inline.Attribute(XName.[Get]("Text")).Value
                    _paragraph.Inlines.Add(_run)
                End If
            Next
            Blocks.Add(_paragraph)
        Next
    End Sub

    Private Function Write(ByRef Blocks As BlockCollection) As String
        Dim _write As New Text.StringBuilder
        Dim _doc = From block In Blocks _
                   From inline In TryCast(block, Paragraph).Inlines
                   Where inline.GetType Is GetType(InlineUIContainer) _
                   Select inline
        If _doc.Count = 0 Then
            _write.Append("<doc>")
            For Each _block As Block In Blocks
                Dim _paragraph As New Paragraph
                _write.Append("<Paragraph ")
                _write.Append("Name='" & _paragraph.Name & "' ")
                _write.Append("FontFamily='" & _paragraph.FontFamily.ToString & "' ")
                _write.Append("FontSize='" & _paragraph.FontSize & "' ")
                _write.Append("FontStretch='" & _paragraph.FontStretch.ToString & "' ")
                _write.Append("FontStyle='" & _paragraph.FontStyle.ToString & "' ")
                _write.Append("FontWeight='" & _paragraph.FontWeight.ToString & "' ")
                _write.Append("Foreground='" & TryCast(_paragraph.Foreground, SolidColorBrush).Color.ToString & "'>")
                For Each _inline In TryCast(_block, Paragraph).Inlines
                    If TypeOf _inline Is Run Then
                        Dim _run As Run = TryCast(_inline, Run)
                        _write.Append("<Inline Type='Run' ")
                        _write.Append("Name='" & _run.Name & "' ")
                        _write.Append("FontFamily='" & _run.FontFamily.ToString & "' ")
                        _write.Append("FontSize='" & _run.FontSize & "' ")
                        _write.Append("FontStretch='" & _run.FontStretch.ToString & "' ")
                        _write.Append("FontStyle='" & _run.FontStyle.ToString & "' ")
                        _write.Append("FontWeight='" & _run.FontWeight.ToString & "' ")
                        _write.Append("Foreground='" & TryCast(_run.Foreground, SolidColorBrush).Color.ToString & "' ")
                        _write.Append("Text='" & _run.Text & "' ")
                        _write.Append("TextDecorations='" & If(_run.TextDecorations Is Nothing, "", "Underline") & "'/>")
                    End If
                Next
                _write.Append("</Paragraph>")
            Next
            _write.Append("</doc>")
            Return _write.ToString
        Else
            Return Nothing
        End If
    End Function

    Private Sub New_Click(ByVal sender As System.Object, _
                          ByVal e As System.Windows.RoutedEventArgs) _
                      Handles [New].Click
        If MessageBox.Show("Start a New Document?", "Rich Text Editor", _
          MessageBoxButton.OKCancel) = MessageBoxResult.OK Then
            Editor.Blocks.Clear()
        End If
    End Sub

    Private Sub Open_Click(ByVal sender As System.Object, _
                           ByVal e As System.Windows.RoutedEventArgs) _
                       Handles Open.Click
        Dim OpenDialog As New OpenFileDialog
        OpenDialog.Filter = "Saved Files (*.sav)|*.sav"
        If OpenDialog.ShowDialog Then
            Try
                If OpenDialog.File.Exists Then
                    Editor.Blocks.Clear()
                    Read(OpenDialog.File.OpenRead, Editor.Blocks)
                End If
            Catch ex As Exception
                ' Ignore Errors
            End Try
        End If
    End Sub

    Private Sub Save_Click(ByVal sender As System.Object, _
                           ByVal e As System.Windows.RoutedEventArgs) _
                       Handles Save.Click
        Dim SaveDialog As New SaveFileDialog
        SaveDialog.Filter = "Saved Files (*.sav)|*.sav"
        If SaveDialog.ShowDialog Then
            Try
                Using FileStream As IO.StreamWriter = _
                      New IO.StreamWriter(SaveDialog.OpenFile)
                    FileStream.Write(Write(Editor.Blocks))
                End Using
            Catch ex As Exception
                ' Ignore Errors
            End Try
        End If
    End Sub

    Private Sub Print_Click(ByVal sender As System.Object, _
                            ByVal e As System.Windows.RoutedEventArgs) _
                        Handles Print.Click
        Dim _print As New PrintDocument
        _print.DocumentName = "Rich Text Editor"
        AddHandler _print.PrintPage, Sub(s As Object, args As PrintPageEventArgs)
                                         args.PageVisual = Editor
                                         args.HasMorePages = False
                                     End Sub
        AddHandler _print.EndPrint, Sub(s As Object, args As EndPrintEventArgs)
                                        MessageBox.Show("Document Printed", _
                                          "Rich Text Editor", MessageBoxButton.OK)
                                    End Sub
        _print.Print()
        Editor.Focus()
    End Sub

    Private Sub Bold_Click(ByVal sender As System.Object, _
                           ByVal e As System.Windows.RoutedEventArgs) _
                       Handles Bold.Click
        If Editor.Selection.Text.Length > 0 Then ' Text Selected
            If TypeOf Editor.Selection.GetPropertyValue(Run.FontWeightProperty) Is FontWeight _
                AndAlso DirectCast(Editor.Selection.GetPropertyValue( _
                  Run.FontWeightProperty), FontWeight) = FontWeights.Normal Then
                Editor.Selection.SetPropertyValue(Run.FontWeightProperty, FontWeights.Bold)
            Else
                Editor.Selection.SetPropertyValue(Run.FontWeightProperty, FontWeights.Normal)
            End If
        End If
        Editor.Focus()
    End Sub

    Private Sub Italic_Click(ByVal sender As System.Object, _
                             ByVal e As System.Windows.RoutedEventArgs) _
                         Handles Italic.Click
        If Editor.Selection.Text.Length > 0 Then ' Text Selected
            If TypeOf Editor.Selection.GetPropertyValue(Run.FontStyleProperty) Is FontStyle _
                AndAlso DirectCast(Editor.Selection.GetPropertyValue( _
                        Run.FontStyleProperty), FontStyle) = FontStyles.Normal Then
                Editor.Selection.SetPropertyValue(Run.FontStyleProperty, FontStyles.Italic)
            Else
                Editor.Selection.SetPropertyValue(Run.FontStyleProperty, FontStyles.Normal)
            End If
        End If
        Editor.Focus()
    End Sub

    Private Sub Underline_Click(ByVal sender As System.Object, _
                                ByVal e As System.Windows.RoutedEventArgs) _
                            Handles Underline.Click
        If Editor.Selection.Text.Length > 0 Then ' Text Selected
            If Editor.Selection.GetPropertyValue(Run.TextDecorationsProperty) Is Nothing Then
                Editor.Selection.SetPropertyValue(Run.TextDecorationsProperty, TextDecorations.Underline)
            Else
                Editor.Selection.SetPropertyValue(Run.TextDecorationsProperty, Nothing)
            End If
        End If
        Editor.Focus()
    End Sub

    Private Sub TimeDate_Click(ByVal sender As System.Object, _
                               ByVal e As System.Windows.RoutedEventArgs) _
                           Handles TimeDate.Click
        Editor.Selection.Text = Format(Now, "HH:mm dd/MM/yyyy")
        Editor.Focus()
    End Sub

    Private Sub Font_SelectionChanged(ByVal sender As System.Object, _
                                      ByVal e As System.Windows.Controls.SelectionChangedEventArgs) _
                                  Handles Font.SelectionChanged
        If Editor IsNot Nothing AndAlso Editor.Selection.Text.Length > 0 Then ' Text Selected
            Editor.Selection.SetPropertyValue(Run.FontFamilyProperty, _
                                              New FontFamily(CType(Font.SelectedItem, ComboBoxItem).Tag))
            Editor.Focus()
        End If
    End Sub

    Private Sub Size_SelectionChanged(ByVal sender As System.Object, _
                                      ByVal e As System.Windows.Controls.SelectionChangedEventArgs) _
                                  Handles Size.SelectionChanged
        If Editor IsNot Nothing AndAlso Editor.Selection.Text.Length > 0 Then ' Text Selected
            Editor.Selection.SetPropertyValue(Run.FontSizeProperty, _
                                              Double.Parse(TryCast(Size.SelectedItem, ComboBoxItem).Tag))
            Editor.Focus()
        End If
    End Sub

    Private Sub Colour_SelectionChanged(ByVal sender As System.Object, _
                                        ByVal e As System.Windows.Controls.SelectionChangedEventArgs) _
                                    Handles Colour.SelectionChanged
        If Editor IsNot Nothing AndAlso Editor.Selection.Text.Length > 0 Then ' Text Selected
            Dim _colour As String = CType(Colour.SelectedItem, ComboBoxItem).Tag
            Dim _brush As New SolidColorBrush(Color.FromArgb(
                    Byte.Parse(_colour.Substring(0, 2), System.Globalization.NumberStyles.HexNumber),
                    Byte.Parse(_colour.Substring(2, 2), System.Globalization.NumberStyles.HexNumber),
                    Byte.Parse(_colour.Substring(4, 2), System.Globalization.NumberStyles.HexNumber),
                    Byte.Parse(_colour.Substring(6, 2), System.Globalization.NumberStyles.HexNumber)))
            Editor.Selection.SetPropertyValue(Run.ForegroundProperty, _brush)
            Editor.Focus()
        End If
    End Sub
End Class

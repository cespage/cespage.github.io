﻿Partial Public Class Carousel
    Inherits UserControl

    Private _rotate As New Storyboard
    Private _images As New List(Of ImageSource)
    Private _items As New List(Of CarouselItem)
    Private _position As Point
    Private _radius As Point = New Point With {.X = 150, .Y = -40}
    Private _speed As Double = 0.0125
    Private _perspective As Double = 200
    Private _distance As Double

    Private Sub Populate(ByRef Canvas As Canvas)
        Canvas.Children.Clear()
        For Each _image In _images
            Dim _index As Integer
            Dim _item As New CarouselItem
            _item.Image.Source = _image
            _item.Angle = _index * ((Math.PI * 2) / _images.Count)
            _position.X = Math.Cos(_item.Angle) * _radius.X
            _position.Y = Math.Sin(_item.Angle) * _radius.Y
            Canvas.SetLeft(_item, _position.X)
            Canvas.SetTop(_item, _position.Y)
            _distance = 1 / (1 - (_position.Y / _perspective))
            _item.ItemScale.ScaleY = _distance
            _item.ItemScale.ScaleX = _item.ItemScale.ScaleY
            _item.Opacity = _item.ItemScale.ScaleX
            _items.Add(_item)
            Canvas.Children.Add(_item)
            _index += 1
        Next
    End Sub

    Private Sub Rotate()
        For Each _item As CarouselItem In _items
            _item.Angle -= _speed
            _position.X = Math.Cos(_item.Angle) * _radius.X
            _position.Y = Math.Sin(_item.Angle) * _radius.Y
            Canvas.SetLeft(_item, _position.X)
            Canvas.SetTop(_item, _position.Y)
            If _radius.Y >= 0 Then
                _distance = 1 * (1 - (_position.Y / _perspective))
                Canvas.SetZIndex(_item, CInt(_position.Y))
            Else
                _distance = 1 / (1 - (_position.Y / _perspective))
                Canvas.SetZIndex(_item, CInt(_position.Y))
            End If
            _item.ItemScale.ScaleY = _distance
            _item.ItemScale.ScaleX = _item.ItemScale.ScaleY
            _item.Opacity = _item.ItemScale.ScaleX
        Next
        _rotate.Begin()
    End Sub

    Public Sub Add(ByVal Source As ImageSource)
        _images.Add(Source)
        Populate(Display)
    End Sub

    Public Sub RemoveLast()
        If _images.Count > 0 Then
            _images.RemoveAt(_images.Count - 1)
            Populate(Display)
        End If
    End Sub

    Public Sub Clear()
        _images.Clear()
        Populate(Display)
    End Sub

    Public Sub New 
        InitializeComponent()
        Canvas.SetLeft(Display, Container.Width / 2 - Display.Width / 2)
        Canvas.SetTop(Display, Container.Height / 2 - Display.Height / 2)
        AddHandler _rotate.Completed, AddressOf Rotate
        _rotate.Begin()
    End Sub

End Class

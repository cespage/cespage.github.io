﻿Partial Public Class CarouselItem
    Inherits UserControl
    Public Angle As Double = 0
    Public Sub New 
        InitializeComponent()
    End Sub

End Class

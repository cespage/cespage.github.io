﻿Partial Public Class MainPage
    Inherits UserControl

    Public Sub New()
        InitializeComponent()
    End Sub

    Private Sub Add_Click(ByVal sender As System.Object,
                          ByVal e As System.Windows.RoutedEventArgs) _
                      Handles Add.Click
        Dim OpenDialog As New OpenFileDialog
        OpenDialog.Filter = "JPEG Image (*.jpg;*.jpeg)|*.jpg;*.jpeg"
        If OpenDialog.ShowDialog Then
            Try
                If OpenDialog.File.Exists Then
                    Using FileStream As IO.Stream = OpenDialog.File.OpenRead
                        Dim Source As New Imaging.BitmapImage
                        Source.SetSource(FileStream)
                        Images.Add(Source)
                    End Using
                End If
            Catch ex As Exception
                ' Ignore Errors
            End Try
        End If
    End Sub

    Private Sub Remove_Click(ByVal sender As System.Object,
                             ByVal e As System.Windows.RoutedEventArgs) _
                         Handles Remove.Click
        Images.RemoveLast()
    End Sub

    Private Sub Clear_Click(ByVal sender As System.Object,
                            ByVal e As System.Windows.RoutedEventArgs) _
                        Handles Clear.Click
        Images.Clear()
    End Sub
End Class
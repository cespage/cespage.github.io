﻿Partial Public Class MainPage
    Inherits UserControl

    Public Sub New()
        InitializeComponent()
    End Sub

    Private Sub HelloWorld_Click(ByVal sender As System.Object, _
                                 ByVal e As System.Windows.RoutedEventArgs) _
                             Handles HelloWorld.Click
        MessageBox.Show("Hello World")
    End Sub
End Class
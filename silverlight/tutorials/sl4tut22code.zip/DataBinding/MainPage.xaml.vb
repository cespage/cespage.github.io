﻿Imports System.Collections.ObjectModel
Imports System.IO.IsolatedStorage
Imports System.Xml.Linq
Partial Public Class MainPage
    Inherits UserControl
    Public Filename As String = "Music.xml"
    Public Property Collection As New ObservableCollection(Of Music)

    Public Sub New()
        InitializeComponent()
        Using Storage As IsolatedStorageFile = IsolatedStorageFile.GetUserStoreForApplication
            If Storage.FileExists(Filename) Then ' Open File
                Using OpenFile As New IsolatedStorageFileStream(Filename, IO.FileMode.Open, Storage)
                    Dim _reader As XmlReader = XmlReader.Create(OpenFile)
                    Dim _doc As XDocument = XDocument.Load(_reader)
                    Collection.Clear()
                    For Each Element As XElement In _doc.Root.<music>
                        Collection.Add(New Music With {
                        .Album = Element.<album>.Value,
                        .Artist = Element.<artist>.Value,
                        .Released = Element.<released>.Value,
                        .Genre = Element.<genre>.Value})
                    Next
                End Using
            Else ' New File
                Collection.Add(New Music With {
                .Album = "Tubular Bells",
                .Artist = "Mike Oldfield",
                .Released = "1973",
                .Genre = "Prog Rock"})
            End If
        End Using
        Data.DataContext = Collection
    End Sub

    Private Sub Add_Click(ByVal sender As System.Object, _
                          ByVal e As System.Windows.RoutedEventArgs) _
                      Handles Add.Click
        Collection.Add(New Music)
    End Sub

    Private Sub Remove_Click(ByVal sender As System.Object, _
                             ByVal e As System.Windows.RoutedEventArgs) _
                         Handles Remove.Click
        Collection.Remove(CType(Data.SelectedItem, Music))
    End Sub

    Private Sub Save_Click(ByVal sender As System.Object, _
                           ByVal e As System.Windows.RoutedEventArgs) _
                       Handles Save.Click
        Dim _doc As XDocument =
                    <?xml version="1.0" encoding="utf-8"?>
                    <collection>
                        <%= From Item As Music In Collection Select
                            <music>
                                <album><%= Item.Album.Trim %></album>
                                <artist><%= Item.Artist.Trim %></artist>
                                <released><%= Item.Released.Trim %></released>
                                <genre><%= Item.Genre.Trim %></genre>
                            </music>
                        %>
                    </collection>
        Using Storage As IsolatedStorageFile = IsolatedStorageFile.GetUserStoreForApplication
            Using SaveFile As New IsolatedStorageFileStream(Filename, IO.FileMode.Create, Storage)
                _doc.Save(SaveFile)
            End Using
        End Using
    End Sub
End Class

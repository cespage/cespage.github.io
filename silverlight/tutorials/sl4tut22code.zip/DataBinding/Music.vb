﻿Imports System.ComponentModel
Public Class Music
    Implements INotifyPropertyChanged

    Private _album As String
    Private _artist As String
    Private _released As String
    Private _genre As String

    Public Event PropertyChanged As PropertyChangedEventHandler _
    Implements INotifyPropertyChanged.PropertyChanged

    Private Sub NotifyPropertyChanged(ByVal PropertyName As String)
        RaiseEvent PropertyChanged(Me, New PropertyChangedEventArgs(PropertyName))
    End Sub

    Public Sub New()
        _album = "Untitled"
    End Sub

    Public Property Album As String
        Get
            Return _album
        End Get
        Set(ByVal value As String)
            _album = value
            NotifyPropertyChanged("Album")
        End Set
    End Property

    Public Property Artist As String
        Get
            Return _artist
        End Get
        Set(ByVal value As String)
            _artist = value
            NotifyPropertyChanged("Artist")
        End Set
    End Property

    Public Property Released As String
        Get
            Return _released
        End Get
        Set(ByVal value As String)
            _released = value
            NotifyPropertyChanged("Released")
        End Set
    End Property

    Public Property Genre As String
        Get
            Return _genre
        End Get
        Set(ByVal value As String)
            _genre = value
            NotifyPropertyChanged("Genre")
        End Set
    End Property

End Class

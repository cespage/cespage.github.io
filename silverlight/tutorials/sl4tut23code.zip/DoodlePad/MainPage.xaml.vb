﻿Imports System.Globalization.NumberStyles
Imports System.Xml.Linq
Partial Public Class MainPage
    Inherits UserControl
    Public drawStroke As Stroke
    Public drawColour As Color = Colors.Black
    Public drawSize As Size = New Size With {.Height = 5, .Width = 5}

    Public Sub New()
        InitializeComponent()
    End Sub

    Private Sub Read(ByRef Stream As IO.Stream, ByRef Strokes As StrokeCollection)
        Dim _stroke As New Stroke
        Dim _drawAttr As New DrawingAttributes
        Dim _doc As XDocument = XDocument.Load(Stream)
        For Each Element As XElement In _doc.Root.<Stroke>
            For Each Item As XElement In Element.<Stroke.DrawingAttributes>.<DrawingAttributes>
                _drawAttr = New DrawingAttributes With {
                    .Color = Color.FromArgb(
                        Byte.Parse(Item.@Color.Substring(1, 2), HexNumber),
                        Byte.Parse(Item.@Color.Substring(3, 2), HexNumber),
                        Byte.Parse(Item.@Color.Substring(5, 2), HexNumber),
                        Byte.Parse(Item.@Color.Substring(7, 2), HexNumber)),
                    .Width = Item.@Width,
                    .Height = Item.@Height}
            Next
            For Each Item As XElement In Element.<Stroke.StylusPoints>
                _stroke = New Stroke
                _stroke.DrawingAttributes = _drawAttr
                For Each Point As XElement In Item.<StylusPoint>
                    _stroke.StylusPoints.Add(New StylusPoint With {
                                             .X = Point.@X,
                                             .Y = Point.@Y})
                Next
                Strokes.Add(_stroke)
            Next
        Next
    End Sub

    Private Function Write(ByRef Strokes As StrokeCollection) As String
        Dim _doc As XDocument =
            <?xml version="1.0" encoding="utf-8"?>
            <StrokeCollection>
                <%= From Item As Stroke In Strokes Select
                    <Stroke>
                        <Stroke.DrawingAttributes>
                            <DrawingAttributes
                                Color=<%= Item.DrawingAttributes.Color %>
                                Width=<%= Item.DrawingAttributes.Width %>
                                Height=<%= Item.DrawingAttributes.Height %>
                            />
                        </Stroke.DrawingAttributes>
                        <Stroke.StylusPoints>
                            <%= From Point As StylusPoint In Item.StylusPoints Select
                                <StylusPoint
                                    X=<%= Point.X %>
                                    Y=<%= Point.Y %>
                                />
                            %>
                        </Stroke.StylusPoints>
                    </Stroke>
                %>
            </StrokeCollection>
        Return _doc.ToString
    End Function

    Private Sub Surface_MouseLeftButtonDown(ByVal sender As System.Object,
                                            ByVal e As System.Windows.Input.MouseButtonEventArgs) _
                                        Handles Surface.MouseLeftButtonDown
        drawStroke = New Stroke
        drawStroke.DrawingAttributes.Color = drawColour
        drawStroke.DrawingAttributes.Width = drawSize.Width
        drawStroke.DrawingAttributes.Height = drawSize.Height
        drawStroke.StylusPoints.Add(New StylusPoint With {
                                    .X = e.GetPosition(Surface).X,
                                    .Y = e.GetPosition(Surface).Y})
        Surface.Strokes.Add(drawStroke)
    End Sub

    Private Sub Surface_MouseLeftButtonUp(ByVal sender As System.Object,
                                          ByVal e As System.Windows.Input.MouseButtonEventArgs) _
                                      Handles Surface.MouseLeftButtonUp
        drawStroke = Nothing
    End Sub

    Private Sub Surface_MouseMove(ByVal sender As System.Object,
                                  ByVal e As System.Windows.Input.MouseEventArgs) _
                              Handles Surface.MouseMove
        If Not drawStroke Is Nothing Then
            drawStroke.StylusPoints.Add(New StylusPoint With {
                                        .X = e.GetPosition(Surface).X,
                                        .Y = e.GetPosition(Surface).Y})
        End If
    End Sub

    Private Sub New_Click(ByVal sender As System.Object,
                      ByVal e As System.Windows.RoutedEventArgs) _
                  Handles [New].Click
        If MessageBox.Show("Start a New Doodle?", "Doodle Pad",
          MessageBoxButton.OKCancel) = MessageBoxResult.OK Then
            Surface.Strokes.Clear()
        End If
    End Sub

    Private Sub Open_Click(ByVal sender As System.Object,
                           ByVal e As System.Windows.RoutedEventArgs) _
                       Handles Open.Click
        Dim OpenDialog As New OpenFileDialog
        OpenDialog.Filter = "Drawing (*.ipr)|*.ipr"
        If OpenDialog.ShowDialog Then
            Try
                If OpenDialog.File.Exists Then
                    Surface.Strokes.Clear()
                    Read(OpenDialog.File.OpenRead, Surface.Strokes)
                End If
            Catch ex As Exception
                ' Ignore Errors
            End Try
        End If
    End Sub

    Private Sub Save_Click(ByVal sender As System.Object,
                           ByVal e As System.Windows.RoutedEventArgs) _
                       Handles Save.Click
        Dim SaveDialog As New SaveFileDialog
        SaveDialog.Filter = "Drawing (*.ipr)|*.ipr"
        If SaveDialog.ShowDialog Then
            Try
                Using FileStream As IO.StreamWriter =
                    New IO.StreamWriter(SaveDialog.OpenFile)
                    FileStream.Write(Write(Surface.Strokes))
                End Using
            Catch ex As Exception
                ' Ignore Errors
            End Try
        End If
    End Sub

    Private Sub Size_SelectionChanged(ByVal sender As System.Object,
                                      ByVal e As System.Windows.Controls.SelectionChangedEventArgs) _
                                  Handles Size.SelectionChanged
        Dim _drawWidth As Double = Double.Parse(TryCast(Size.SelectedItem, ComboBoxItem).Tag)
        drawSize = New Size With {.Height = _drawWidth, .Width = _drawWidth}
    End Sub

    Private Sub Colour_SelectionChanged(ByVal sender As System.Object,
                                        ByVal e As System.Windows.Controls.SelectionChangedEventArgs) _
                                    Handles Colour.SelectionChanged
        Dim _colour As String = CType(Colour.SelectedItem, ComboBoxItem).Tag
        drawColour = Color.FromArgb(
          Byte.Parse(_colour.Substring(0, 2), HexNumber),
          Byte.Parse(_colour.Substring(2, 2), HexNumber),
          Byte.Parse(_colour.Substring(4, 2), HexNumber),
          Byte.Parse(_colour.Substring(6, 2), HexNumber))
    End Sub
End Class

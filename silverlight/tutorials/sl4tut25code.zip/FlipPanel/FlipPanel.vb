﻿Imports System.Windows.Controls.Primitives
<TemplateVisualState(Name:="Normal", GroupName:="ViewStates"),
TemplateVisualState(Name:="Flipped", GroupName:="ViewStates"),
TemplatePart(Name:="FlipButton", Type:=GetType(ToggleButton)),
TemplatePart(Name:="FlipButtonAlternative", Type:=GetType(ToggleButton))>
Public Class FlipPanel
    Inherits Control

    Public Shared ReadOnly FrontContentProperty As DependencyProperty =
    DependencyProperty.Register("FrontContent", GetType(Object),
    GetType(FlipPanel), Nothing)

    Public Shared ReadOnly BackContentProperty As DependencyProperty =
    DependencyProperty.Register("BackContent", GetType(Object),
    GetType(FlipPanel), Nothing)

    Public Shared ReadOnly IsFlippedProperty As DependencyProperty =
    DependencyProperty.Register("IsFlipped", GetType(Boolean),
    GetType(FlipPanel), Nothing)

    Public Shared ReadOnly CornerRadiusProperty As DependencyProperty =
    DependencyProperty.Register("CornerRadius", GetType(CornerRadius),
    GetType(FlipPanel), Nothing)

    Public Property FrontContent() As Object
        Get
            Return GetValue(FrontContentProperty)
        End Get
        Set(ByVal value As Object)
            SetValue(FrontContentProperty, value)
        End Set
    End Property

    Public Property BackContent() As Object
        Get
            Return GetValue(BackContentProperty)
        End Get
        Set(ByVal value As Object)
            SetValue(BackContentProperty, value)
        End Set
    End Property

    Public Property IsFlipped() As Boolean
        Get
            Return CBool(GetValue(IsFlippedProperty))
        End Get
        Set(ByVal value As Boolean)
            SetValue(IsFlippedProperty, value)
            ChangeVisualState(True)
        End Set
    End Property

    Public Property CornerRadius() As CornerRadius
        Get
            Return CType(GetValue(CornerRadiusProperty), CornerRadius)
        End Get
        Set(ByVal value As CornerRadius)
            SetValue(CornerRadiusProperty, value)
        End Set
    End Property

    Public Sub New()
        DefaultStyleKey = GetType(FlipPanel)
    End Sub

    Private Sub ChangeVisualState(ByVal useTransitions As Boolean)
        If Not IsFlipped Then
            VisualStateManager.GoToState(Me, "Normal", useTransitions)
        Else
            VisualStateManager.GoToState(Me, "Flipped", useTransitions)
        End If
    End Sub

    Private Sub FlipButton_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        Me.IsFlipped = Not Me.IsFlipped
        ChangeVisualState(True)
    End Sub

    Public Overloads Overrides Sub OnApplyTemplate()
        MyBase.OnApplyTemplate()
        Dim _flipButton As ToggleButton =
            TryCast(MyBase.GetTemplateChild("FlipButton"), ToggleButton)
        If _flipButton IsNot Nothing Then
            AddHandler _flipButton.Click, AddressOf FlipButton_Click
        End If
        Dim _flipButtonAlternate As ToggleButton =
            TryCast(MyBase.GetTemplateChild("FlipButtonAlternate"), ToggleButton)
        If _flipButtonAlternate IsNot Nothing Then
            AddHandler _flipButtonAlternate.Click, AddressOf FlipButton_Click
        End If
        Me.ChangeVisualState(False)
    End Sub

End Class

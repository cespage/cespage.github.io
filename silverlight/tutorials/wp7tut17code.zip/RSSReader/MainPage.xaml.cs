﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Xml.Linq;
using System.Text.RegularExpressions;

namespace RSSReader
{
    public partial class MainPage : PhoneApplicationPage
    {

        private void Feed(object Sender, DownloadStringCompletedEventArgs e)
        {
            XElement _xml;
            try
            {
                if (!e.Cancelled)
                {
                    _xml = XElement.Parse(e.Result);
                    Results.Items.Clear();
                    foreach (XElement value in _xml.Elements("channel").Elements("item"))
                    {
                        FeedItem _item = new FeedItem();
                        _item.Title = value.Element("title").Value;
                        _item.Description = Regex.Replace(value.Element("description").Value,
                        @"<(.|\n)*?>", String.Empty);
                        _item.Link = value.Element("link").Value;
                        _item.Guid = value.Element("guid").Value;
                        _item.Published = DateTime.Parse(value.Element("pubDate").Value);
                        Results.Items.Add(_item);
                    }
                }
            }
            catch
            {
                // Ignore Errors
            }
        }

        private void Go_Click(object sender, RoutedEventArgs e)
        {
            WebClient _client = new WebClient();
            _client.DownloadStringCompleted += Feed;
            _client.DownloadStringAsync(new Uri((Location.Text)));
        }

        // Constructor
        public MainPage()
        {
            InitializeComponent();
            PageTitle.Text = "RSS Reader";
            Location.Text = "http://cespage.com/silverlight/tutorials.xml";
        }
    }
}

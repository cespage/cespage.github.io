﻿Partial Public Class MainPage
    Inherits UserControl
    Private Rotating As Boolean
    Private Rotation As New Storyboard
    Public Sub New()
        InitializeComponent()
    End Sub

    Private Sub Rotate(ByRef Parameter As Object)
        If Rotating Then
            Rotation.Stop()
            Rotating = False
        Else
            Dim _animation As New DoubleAnimation
            _animation.From = 0.0
            _animation.To = 360.0
            _animation.Duration = New Duration(TimeSpan.FromSeconds(10))
            _animation.RepeatBehavior = Animation.RepeatBehavior.Forever
            Storyboard.SetTarget(_animation, Target)
            Storyboard.SetTargetProperty(_animation, New PropertyPath(Parameter))
            Rotation.Children.Clear()
            Rotation.Children.Add(_animation)
            Rotation.Begin()
            Rotating = True
        End If
    End Sub

    Private Sub Open_Click(ByVal sender As System.Object, _
                           ByVal e As System.Windows.RoutedEventArgs) _
                       Handles Open.Click
        Dim OpenDialog As New OpenFileDialog
        OpenDialog.Filter = "JPEG Image (*.jpg;*.jpeg)|*.jpg;*.jpeg"
        If OpenDialog.ShowDialog Then
            Try
                If OpenDialog.File.Exists Then
                    Using FileStream As IO.Stream = OpenDialog.File.OpenRead
                        Dim Source As New Imaging.BitmapImage
                        Source.SetSource(FileStream)
                        Display.Source = Source
                    End Using
                End If
            Catch ex As Exception
                ' Ignore Errors
            End Try
        End If
    End Sub

    Private Sub Pitch_Click(ByVal sender As System.Object, _
                            ByVal e As System.Windows.RoutedEventArgs) _
                        Handles Pitch.Click
        Rotate(PlaneProjection.RotationXProperty)
    End Sub

    Private Sub Roll_Click(ByVal sender As System.Object, _
                           ByVal e As System.Windows.RoutedEventArgs) _
                       Handles Roll.Click
        Rotate(PlaneProjection.RotationZProperty)
    End Sub

    Private Sub Yaw_Click(ByVal sender As System.Object, _
                          ByVal e As System.Windows.RoutedEventArgs) _
                      Handles Yaw.Click
        Rotate(PlaneProjection.RotationYProperty)
    End Sub
End Class
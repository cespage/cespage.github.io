﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace FlipClock
{
    public partial class Flip : UserControl
    {
        public static readonly DependencyProperty TextPrevProperty =
        DependencyProperty.Register("TextPrev", typeof(string),
        typeof(Flip), null);

        public static readonly DependencyProperty TextNextProperty =
        DependencyProperty.Register("TextNext", typeof(string),
        typeof(Flip), null);

        public string TextPrev
        {
            get { return (string)GetValue(TextPrevProperty); }
            set
            {
                SetValue(TextPrevProperty, value);
                textBlockBottom.Text = TextPrev;
                textBlockFlipTop.Text = TextPrev;
            }
        }

        public string TextNext
        {
            get { return (string)GetValue(TextNextProperty); }
            set
            {
                SetValue(TextNextProperty, value);
                textBlockTop.Text = TextNext;
                textBlockFlipBottom.Text = TextNext;
            }
        }

        public void Value(string source, string target)
        {
            TextNext = target;
            TextPrev = source;
            FlipAnimation.Begin();
        }

        public Flip()
        {
            InitializeComponent();
        }
    }
}

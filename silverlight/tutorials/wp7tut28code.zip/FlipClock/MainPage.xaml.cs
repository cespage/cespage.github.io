﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Threading;

namespace FlipClock
{
    public partial class MainPage : PhoneApplicationPage
    {
        private DispatcherTimer _timer = new DispatcherTimer();
        private int _seconds = DateTime.Now.Second;
        private int _minutes = DateTime.Now.Minute;
        private int _hours = DateTime.Now.Hour;

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (_seconds == 59)
            {
                Seconds.Value(_seconds.ToString("00"), 0.ToString("00"));
                _seconds = 0;
                if (_minutes == 59)
                {
                    Minutes.Value(_minutes.ToString("00"), 0.ToString("00"));
                    _minutes = 0;
                    if (_hours == 23)
                    {
                        Hours.Value(_hours.ToString("00"), 0.ToString("00"));
                        _hours = 0;
                    }
                    else
                    {
                        Hours.Value(_hours.ToString("00"), (_hours + 1).ToString("00"));
                        _hours += 1;
                    }
                }
                else
                {
                    Minutes.Value(_minutes.ToString("00"), (_minutes + 1).ToString("00"));
                    _minutes += 1;
                }
            }
            else
            {
                Seconds.Value(_seconds.ToString("00"), (_seconds + 1).ToString("00"));
                _seconds += 1;
            }
        }

        // Constructor
        public MainPage()
        {
            InitializeComponent();
            PageTitle.Text = "flip clock";
            Seconds.TextPrev = _seconds.ToString("00");
            Minutes.TextPrev = _minutes.ToString("00");
            Hours.TextPrev = _hours.ToString("00");
            _timer.Tick += Timer_Tick;
            _timer.Interval = TimeSpan.FromSeconds(1);
            _timer.Start();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Media.Imaging;

namespace SlideShow
{
    public partial class MainPage : PhoneApplicationPage
    {
        public SlideShow SlideShow = new SlideShow();

        private void Go_Click(object sender, RoutedEventArgs e)
        {
            Display.Source = new BitmapImage(new Uri(Location.Text));
        }

        private void Add_Click(object sender, EventArgs e)
        {
            SlideShow.Add(new Uri(Location.Text));
            Position.Maximum = SlideShow.Count - 1;
        }

        private void Remove_Click(object sender, EventArgs e)
        {
            SlideShow.Remove((int)Position.Value);
            Position.Maximum = SlideShow.Count - 1;
        }

        private void Play_Click(object sender, EventArgs e)
        {
            if (SlideShow.Playing)
            {
                if (SlideShow.Paused)
                {
                    SlideShow.Play();
                }
                else
                {
                    SlideShow.Pause();
                }
            }
            else
            {
                SlideShow.Play();
            }
        }

        private void Stop_Click(object sender, EventArgs e)
        {
            SlideShow.Stop();
        }

        private void Position_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            SlideShow.Position = (int)Position.Value;
        }

        private void Speed_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (Speed != null)
            {
                SlideShow.Speed = TimeSpan.FromMilliseconds(Speed.Value);
            }
        }

        // Constructor
        public MainPage()
        {
            InitializeComponent();
            ApplicationTitle.Text = "SLIDESHOW";
            Location.Text = "http://";
            SlideShow.Slide += (BitmapImage image, int index) =>
            {
                Display.Source = image;
                Position.Value = index;
            };
        }
    }
}

﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Windows.Threading;
using System.Windows.Media.Imaging;
using System.IO;

namespace SlideShow
{
    public class SlideShow
    {
        private DispatcherTimer _slideshow = new DispatcherTimer();
        private List<BitmapImage> _images = new List<BitmapImage>();
        private int _index;
        private bool _hasImages;
        private bool _isPlaying;
        private bool _isPaused;

        public delegate void SlideEvent(BitmapImage image, int index);
        public event SlideEvent Slide;

        public SlideShow()
        {
            _slideshow.Interval = TimeSpan.FromSeconds(1.5);
            _slideshow.Tick += new EventHandler(SlideShow_Tick);
        }

        public bool Add(Uri uri)
        {
            BitmapImage _image = new BitmapImage(uri);
            _images.Add(_image);
            return _hasImages = _images.Count > 0;
        }

        public void Remove(int index)
        {
            if (index < _images.Count && index > -1)
            {
                _images.RemoveAt(index);
            }
        }

        public void Play()
        {
            if (_hasImages && (_isPaused || !_isPlaying))
            {
                _slideshow.Start();
                _isPlaying = true;
                _isPaused = false;
            }
        }

        public void Pause()
        {
            if (_hasImages && _isPlaying)
            {
                _slideshow.Stop();
                _isPaused = true;
                _isPlaying = false;
            }
        }

        public void Stop()
        {
            if (_hasImages)
            {
                _index = 0;
                _slideshow.Stop();
                _isPaused = false;
                _isPlaying = false;
            }
        }

        public void Selected(int index)
        {
            if (_hasImages && index < _images.Count)
            {
                _index = index;
                if (_isPlaying)
                {
                    this.Play();
                }
            }
        }

        private void SlideShow_Tick(object sender, EventArgs e)
        {
            if (_hasImages && _isPlaying)
            {
                if (_index < _images.Count)
                {
                    Slide(_images[_index], _index);
                    _index += 1;
                }
                else
                {
                    this.Stop();
                }
            }
        }

        public TimeSpan Speed
        {
            get { return _slideshow.Interval; }
            set
            {
                if (value != _slideshow.Interval)
                {
                    _slideshow.Interval = value;
                }
            }
        }

        public int Position
        {
            get { return _index; }
            set { _index = value; }
        }

        public int Count
        {
            get { return _images.Count; }
        }

        public bool Playing
        {
            get { return _isPlaying; }
        }

        public bool Paused
        {
            get { return _isPaused; }
        }
    }
}

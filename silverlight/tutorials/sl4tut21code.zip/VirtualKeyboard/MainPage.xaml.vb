﻿Partial Public Class MainPage
    Inherits UserControl

    Private _rowOne As String(,) = {{"`", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "="},
                                    {"¬", "!", """", "£", "$", "%", "^", "&", "*", "(", ")", "_", "+"}}
    Private _rowTwo As String(,) = {{"q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "[", "]"},
                                    {"q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "{", "}"}}
    Private _rowThree As String(,) = {{"a", "s", "d", "f", "g", "h", "j", "k", "l", ";", "'", "#"},
                                      {"a", "s", "d", "f", "g", "h", "j", "k", "l", ":", "@", "~"}}
    Private _rowFour As String(,) = {{"\", "z", "x", "c", "v", "b", "n", "m", ",", ".", "/"},
                                    {"|", "z", "x", "c", "v", "b", "n", "m", "<", ">", "?"}}
    Private _panel As New StackPanel
    Private _panelOne As New StackPanel
    Private _panelTwo As New StackPanel
    Private _panelThree As New StackPanel
    Private _panelFour As New StackPanel
    Private _panelFive As New StackPanel
    Private _isShift As Boolean = False
    Private _isCaps As Boolean = False

    Public Enum Special
        None = 0
        BackSpace = 1
        Tab = 2
        Enter = 3
        CapsLock = 4
        Shift = 5
        Space = 6
        Home = 7
        [End] = 8
        Insert = 9
        Delete = 10
        Copy = 11
        Paste = 12
    End Enum

    Public Event SpecialPressed(ByVal Value As Special)
    Public Event KeyPressed(ByVal Value As Object)

    Public Sub New()
        InitializeComponent()
        Layout(Keyboard)
    End Sub

    Private Sub Button_SpecialPressed(ByVal Value As Special) _
        Handles Me.SpecialPressed
        Buffer.Focus()
        Select Case Value
            Case Special.BackSpace
                If Not Buffer.SelectionStart = 0 Then
                    Buffer.Select(Buffer.SelectionStart - 1, 1)
                    Buffer.SelectedText = ""
                End If
            Case Special.Home
                Buffer.SelectionStart = 0
            Case Special.End
                Buffer.SelectionStart = Buffer.Text.Length
            Case Special.Delete
                If Not Buffer.SelectionStart = Buffer.Text.Length Then
                    Buffer.Select(Buffer.SelectionStart, 1)
                    Buffer.SelectedText = ""
                End If
            Case Special.Copy
                If Buffer.Text.Length > 0 Then
                    Clipboard.SetText(Buffer.Text)
                End If
            Case Special.Paste
                If Not Buffer.SelectionStart = 0 Then
                    Buffer.SelectedText = Clipboard.GetText
                End If
        End Select
    End Sub

    Private Sub Button_KeyPressed(ByVal Value As Object) _
        Handles Me.KeyPressed
        Buffer.Focus()
        Buffer.SelectedText = Value
    End Sub

    Private Sub UpdateRow(ByRef Row As StackPanel, ByRef Source As String(,), _
               ByRef Shift As Boolean, ByRef Count As Integer)
        For Each Item As Button In Row.Children
            For Index As Integer = 0 To Count
                If Shift Then
                    If CStr(Item.Content) = CStr(Source(0, Index)) Then
                        Item.Content = Source(1, Index)
                    End If
                Else
                    If CStr(Item.Content) = CStr(Source(1, Index)) Then
                        Item.Content = Source(0, Index)
                    End If
                End If
            Next
        Next
    End Sub

    Private Sub Button_Click(ByVal sender As System.Object, _
        ByVal e As System.Windows.RoutedEventArgs)
        Dim _value As New Object
        Dim _command As New Object
        _value = CType(sender, Button).Content
        _command = CType(sender, Button).Tag
        If Not _command Is Nothing Then
            _value = Nothing
            Select Case _command
                Case Special.BackSpace, Special.Copy, Special.Paste, _
                    Special.Home, Special.End, Special.Insert, Special.Delete
                    RaiseEvent SpecialPressed(_command)
                Case Special.Shift
                    _isShift = Not _isShift
                    UpdateRow(_panelOne, _rowOne, _isShift, 12)
                    UpdateRow(_panelTwo, _rowTwo, _isShift, 11)
                    UpdateRow(_panelThree, _rowThree, _isShift, 11)
                    UpdateRow(_panelFour, _rowFour, _isShift, 10)
                Case Special.CapsLock
                    _isCaps = Not _isCaps
                Case Special.Tab
                    _value = vbTab
                Case Special.Enter
                    _value = vbCrLf
                Case Special.Space
                    _value = " "
            End Select
        End If
        If Not _value Is Nothing Then
            If _isCaps Xor _isShift Then
                _value = CStr(_value).ToUpper
            Else
                _value = CStr(_value).ToLower
            End If
            RaiseEvent KeyPressed(_value)
        End If
    End Sub

    Private Sub Add(ByRef Panel As StackPanel, ByRef Content As Object, _
                    ByRef Tag As Object, ByRef Width As Double, ByRef Height As Double)
        Dim _btn As New Button
        AddHandler _btn.Click, AddressOf Button_Click
        _btn.Content = Content
        _btn.Tag = Tag
        _btn.Margin = New Thickness(0.5)
        _btn.Width = Width
        _btn.Height = Height
        Panel.Children.Add(_btn)
    End Sub

    Public Sub AddRow(ByRef Row As StackPanel, ByRef Source As String(,), _
                      ByRef Count As Integer)
        For Index As Integer = 0 To Count
            Add(Row, Source(0, Index).ToUpper, Nothing, 25, 25)
        Next
    End Sub

    Public Sub Layout(ByVal Panel As StackPanel)
        _panelOne.Orientation = Orientation.Horizontal
        _panelTwo.Orientation = Orientation.Horizontal
        _panelThree.Orientation = Orientation.Horizontal
        _panelFour.Orientation = Orientation.Horizontal
        _panelFive.Orientation = Orientation.Horizontal
        _panelOne.Margin = New Thickness(5, 0, 5, 0)
        _panelTwo.Margin = New Thickness(5, 0, 5, 0)
        _panelThree.Margin = New Thickness(5, 0, 5, 0)
        _panelFour.Margin = New Thickness(5, 0, 5, 0)
        _panelFive.Margin = New Thickness(5, 0, 5, 0)
        AddRow(_panelOne, _rowOne, 12)
        Add(_panelOne, "BkSp", Special.BackSpace, 50, 25)
        _panel.Children.Add(_panelOne)
        Add(_panelTwo, "Tab", Special.Tab, 37, 25)
        AddRow(_panelTwo, _rowTwo, 11)
        Add(_panelTwo, "↵", Special.Enter, 37, 25)
        _panel.Children.Add(_panelTwo)
        Add(_panelThree, "Caps", Special.CapsLock, 48, 25)
        AddRow(_panelThree, _rowThree, 11)
        Add(_panelThree, Nothing, Special.Enter, 25, 25)
        _panel.Children.Add(_panelThree)
        Add(_panelFour, "Shift", Special.Shift, 37, 25)
        AddRow(_panelFour, _rowFour, 10)
        Add(_panelFour, "Shift", Special.Shift, 62, 25)
        _panel.Children.Add(_panelFour)
        Add(_panelFive, "Copy", Special.Copy, 50, 25)
        Add(_panelFive, "Paste", Special.Paste, 50, 25)
        Add(_panelFive, "Space", Special.Space, 150, 25)
        Add(_panelFive, "Home", Special.Home, 40, 25)
        Add(_panelFive, "End", Special.End, 40, 25)
        Add(_panelFive, "Ins", Special.Insert, 25, 25)
        Add(_panelFive, "Del", Special.Delete, 25, 25)
        _panel.Children.Add(_panelFive)
        Panel.Children.Add(_panel)
    End Sub

End Class

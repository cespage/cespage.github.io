﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace PlayingCards
{
    public partial class MainPage : PhoneApplicationPage
    {
        const string CLUBS = "♣";
        const string DIAMONDS = "♦";
        const string HEARTS = "♥";
        const string SPADES = "♠";
        const string ACE = "A";
        const string JACK = "J";
        const string QUEEN = "Q";
        const string KING = "K";

        private List<int> _deckOne = new List<int>();
        private List<int> _deckTwo = new List<int>();
        private int _cardOne, _cardTwo;
        private int _first, _second;
        private int _score, _counter;

        private TextBlock Pip(string Content, Color Foreground,
        double FontSize, string FontFamily, double Left, double Top)
        {
            TextBlock _pip = new TextBlock();
            _pip.FontSize = FontSize;
            _pip.FontFamily = new FontFamily(FontFamily);
            _pip.Text = Content;
            _pip.Foreground = new SolidColorBrush(Foreground);
            _pip.SetValue(Canvas.LeftProperty, Left);
            _pip.SetValue(Canvas.TopProperty, Top);
            return _pip;
        }

        private Canvas Deck(ref int Card, ref Color BackColor)
        {
            Canvas _card = new Canvas();
            Color _fore = Colors.Black;
            string _suite = "";
            string _display = "";
            int _value;
            if (Card >= 1 && Card <= 13)
            {
                _fore = Colors.Black;
                _suite = CLUBS;
                _display = Card.ToString();
            }
            else if (Card >= 14 && Card <= 26)
            {
                _fore = Colors.Red;
                _suite = DIAMONDS;
                _display = (Card - 13).ToString();
            }
            else if (Card >= 27 && Card <= 39)
            {
                _fore = Colors.Red;
                _suite = HEARTS;
                _display = (Card - 26).ToString();
            }
            else if (Card >= 40 && Card <= 52)
            {
                _fore = Colors.Black;
                _suite = SPADES;
                _display = (Card - 39).ToString();
            }
            _value = int.Parse(_display);
            _card.Width = 170;
            _card.Height = 250;
            _card.Background = new SolidColorBrush(BackColor);
            switch (_value)
            {
                case 1:
                    _display = ACE;
                    _card.Children.Add(Pip(_suite, _fore, 100, "Times New Roman", 50, 60)); // Centre
                    break;
                case 2:
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 65, 20)); // Middle Top
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 65, 160)); // Middle Bottom
                    break;
                case 3:
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 65, 20)); // Middle Top
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 65, 90)); // Centre
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 65, 160)); // Middle Bottom
                    break;
                case 4:
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 20, 20)); // Top Left
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 110, 20)); // Top Right
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 20, 160)); // Bottom Left
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 110, 160)); // Bottom Right
                    break;
                case 5:
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 20, 20)); // Top Left
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 110, 20)); // Top Right
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 65, 90)); // Centre
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 20, 160)); // Bottom Left
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 110, 160)); // Bottom Right
                    break;
                case 6:
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 20, 20)); // Top Left
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 110, 20)); // Top Right
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 20, 90)); // Centre Left
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 110, 90)); // Centre Right
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 20, 160)); // Bottom Left
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 110, 160)); // Bottom Right
                    break;
                case 7:
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 20, 20)); // Top Left
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 110, 20)); // Top Right
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 20, 90)); // Centre Left
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 65, 55)); // Centre Top
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 110, 90)); // Centre Right
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 20, 160)); // Bottom Left
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 110, 160)); // Bottom Right
                    break;
                case 8:
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 20, 20)); // Top Left
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 110, 20)); // Top Right
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 20, 90)); // Centre Left
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 65, 55)); // Centre Top
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 65, 125)); // Centre Bottom
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 110, 90)); // Centre Right
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 20, 160)); // Bottom Left
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 110, 160)); // Bottom Right
                    break;
                case 9:
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 20, 20)); // Top Left
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 110, 20)); // Top Right
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 20, 65)); // Centre Left Top
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 20, 110)); // Centre Left Bottom
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 65, 90)); // Centre
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 110, 65)); // Centre Right Top
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 110, 110)); // Centre Right Bottom
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 20, 160)); // Bottom Left
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 110, 160)); // Bottom Right
                    break;
                case 10:
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 20, 20)); // Top Left
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 110, 20)); // Top Right
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 20, 65)); // Centre Left Top
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 20, 110)); // Centre Left Bottom
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 65, 55)); // Centre Top
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 65, 125)); // Centre Bottom
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 110, 65)); // Centre Right Top
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 110, 110)); // Centre Right Bottom
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 20, 160)); // Bottom Left
                    _card.Children.Add(Pip(_suite, _fore, 60, "Arial", 110, 160)); // Bottom Right
                    break;
                case 11:
                    _display = JACK;
                    _card.Children.Add(Pip(_display, _fore, 100, "Times New Roman", 65, 65)); // Centre
                    break;
                case 12:
                    _display = QUEEN;
                    _card.Children.Add(Pip(_display, _fore, 100, "Times New Roman", 50, 65)); // Centre
                    break;
                case 13:
                    _display = KING;
                    _card.Children.Add(Pip(_display, _fore, 100, "Times New Roman", 50, 65)); // Centre
                    break;
            }
            if ((_display.Length == 1))
            {
                _card.Children.Add(Pip(_display, _fore, 20, "Times New Roman", 10, 4));
                _card.Children.Add(Pip(_display, _fore, 20, "Times New Roman", 150, 204));
            }
            else
            {
                _card.Children.Add(Pip(_display, _fore, 20, "Times New Roman", 5, 4));
                _card.Children.Add(Pip(_display, _fore, 20, "Times New Roman", 145, 204));
            }
            _card.Children.Add(Pip(_suite, _fore, 30, "Arial", 7, 16));
            _card.Children.Add(Pip(_suite, _fore, 30, "Arial", 145, 215));
            return _card;
        }

        private Canvas Card(int Value, bool IsFacing, Color BackColor)
        {
            if (IsFacing)
            {
                return Deck(ref Value, ref BackColor);
            }
            else
            {
                Canvas _card = new Canvas();
                _card.Width = 170;
                _card.Height = 250;
                _card.Background = new SolidColorBrush(BackColor);
                return _card;
            }
        }

        private void Match()
        {
            if ((_cardOne < 52) && (_cardTwo < 52))
            {
                _first = _deckOne[_cardOne];
                PileOne.Content = Card(_first, true, Colors.White);
                _cardOne++;
                _second = _deckTwo[_cardTwo];
                PileTwo.Content = Card(_second, true, Colors.White);
                _cardTwo++;
                if ((_first % 13) == (_second % 13)) // Ignore Suite for Match
                {
                    _score++;
                    MessageBox.Show("Match!", "Playing Cards", MessageBoxButton.OK);
                }
                _counter++;
            }
            else
            {
                MessageBox.Show("Game Over! Matched " + _score + " out of " +
                _counter + " cards!", "Playing Cards", MessageBoxButton.OK);
            }
        }

        private List<int> Shuffle()
        {
            int number;
            List<int> _numbers = new List<int>();
            Random random = new Random();
            while ((_numbers.Count < 52)) // Select 52 Numbers
            {
                number = random.Next(1, 53); // Seeded Random Number
                if ((!_numbers.Contains(number)) || (_numbers.Count < 1))
                {
                    _numbers.Add(number); // Add if number Chosen or None
                }
            }
            return _numbers;
        }

        private void New_Click(object sender, RoutedEventArgs e)
        {
            _score = 0;
            PileOne.Content = Card(1, false, Colors.Red);
            PileTwo.Content = Card(1, false, Colors.Blue);
            _deckOne = Shuffle();
            _deckTwo = Shuffle();
        }

        private void PileOne_Click(object sender, RoutedEventArgs e)
        {
            if (PileOne.Content != null)
            {
                Match();
            }
        }

        private void PileTwo_Click(object sender, RoutedEventArgs e)
        {
            if (PileTwo.Content != null)
            {
                Match();
            }
        }

        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }
    }
}

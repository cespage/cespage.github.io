﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Media.Imaging;

namespace Imager
{
    public partial class MainPage : PhoneApplicationPage
    {
        private bool Rotating = false;
        private Storyboard Rotation = new Storyboard();

        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        private void Rotate(object Parameter)
        {
            if (Rotating)
            {
                Rotation.Stop();
                Rotating = false;
            }
            else
            {
                DoubleAnimation _animation = new DoubleAnimation();
                _animation.From = 0.0;
                _animation.To = 360.0;
                _animation.Duration = new Duration(TimeSpan.FromSeconds(10));
                _animation.RepeatBehavior = RepeatBehavior.Forever;
                Storyboard.SetTarget(_animation, Target);
                Storyboard.SetTargetProperty(_animation, new PropertyPath(Parameter));
                Rotation.Children.Clear();
                Rotation.Children.Add(_animation);
                Rotation.Begin();
                Rotating = true;
            }
        }

        private void Go_Click(object sender, RoutedEventArgs e)
        {
            Display.Source = new BitmapImage(new Uri(Location.Text));
        }

        private void Pitch_Click(object sender, RoutedEventArgs e)
        {
            Rotate(PlaneProjection.RotationXProperty);
        }

        private void Roll_Click(object sender, RoutedEventArgs e)
        {
            Rotate(PlaneProjection.RotationZProperty);
        }

        private void Yaw_Click(object sender, RoutedEventArgs e)
        {
            Rotate(PlaneProjection.RotationYProperty);
        }

    }
}

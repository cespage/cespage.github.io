﻿Imports System.Xml.Linq
Partial Public Class MainPage
    Inherits UserControl
    Public Sub New()
        InitializeComponent()
    End Sub

    Private Sub New_Click(ByVal sender As System.Object, _
                          ByVal e As System.Windows.RoutedEventArgs) _
                      Handles [New].Click
        If MessageBox.Show("Start a New Task List?", "Task List", _
          MessageBoxButton.OKCancel) = MessageBoxResult.OK Then
            Subject.Text = ""
            Tasks.Items.Clear()
        End If
    End Sub

    Private Sub Open_Click(ByVal sender As System.Object, _
                           ByVal e As System.Windows.RoutedEventArgs) _
                       Handles Open.Click
        Dim OpenDialog As New OpenFileDialog
        Dim _xml As XElement
        OpenDialog.Filter = "Task List Files (*.tsk)|*.tsk"
        If OpenDialog.ShowDialog Then
            Try
                If OpenDialog.File.Exists Then
                    _xml = XElement.Parse(OpenDialog.File.OpenText.ReadToEnd)
                    If _xml.Name.LocalName = "tasklist" Then ' Root
                        Tasks.Items.Clear()
                        For Each _Task As XElement In _xml.Descendants("task")
                            Dim _item As New CheckBox
                            _item.IsChecked = _Task.FirstAttribute.Value.ToLower = "checked"
                            _item.Content = _Task.Value
                            Tasks.Items.Add(_item)
                        Next
                    End If
                End If
            Catch ex As Exception
                ' Ignore Errors
            End Try
        End If
    End Sub

    Private Sub Save_Click(ByVal sender As System.Object, _
                           ByVal e As System.Windows.RoutedEventArgs) _
                       Handles Save.Click
        Dim SaveDialog As New SaveFileDialog
        Dim _doc As XDocument
        SaveDialog.Filter = "Task List Files (*.tsk)|*.tsk"
        If SaveDialog.ShowDialog Then
            Try
                Dim _items As New XElement("tasklist")
                For Each _Task As CheckBox In Tasks.Items
                    _items.Add(New XElement("task", _Task.Content, _
                                              New XAttribute("value", IIf(_Task.IsChecked, _
                                                                          "checked", "unchecked"))))
                Next
                _doc = New XDocument(New XDeclaration("1.0", "utf-8", "yes"), _items)
                Using FileStream As IO.StreamWriter = New IO.StreamWriter(SaveDialog.OpenFile)
                    _doc.Save(FileStream)
                End Using
            Catch ex As Exception
                ' Ignore Errors
            End Try
        End If
    End Sub

    Private Sub Remove_Click(ByVal sender As System.Object, _
                             ByVal e As System.Windows.RoutedEventArgs) _
                         Handles Remove.Click
        If Tasks.SelectedIndex > -1 Then ' Item Selected
            Tasks.Items.RemoveAt(Tasks.SelectedIndex) ' Remove Selected
        End If
    End Sub

    Private Sub Add_Click(ByVal sender As System.Object, _
                          ByVal e As System.Windows.RoutedEventArgs) _
                      Handles Add.Click
        If Subject.Text <> "" Then ' Has Subject
            Dim _item As New CheckBox
            _item.Content = Subject.Text
            If Tasks.SelectedIndex > -1 Then ' Item Selected
                Tasks.Items.Insert(Tasks.SelectedIndex, _item) ' Insert before Selected
            Else
                Tasks.Items.Add(_item) ' Add to List End
            End If
        End If
    End Sub
End Class

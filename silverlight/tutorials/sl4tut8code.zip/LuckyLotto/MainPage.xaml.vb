﻿Partial Public Class MainPage
    Inherits UserControl

    Public Sub New()
        InitializeComponent()
    End Sub

    Private Function Numbers() As List(Of Integer)
        Dim _number As Integer
        Dim _numbers As New List(Of Integer)
        While _Numbers.Count < 6 ' Select 6 Numbers
            Randomize(Timer) ' Random Number with Seed
            _number = Int((49 * Rnd()) + 1) ' Between 1 - 49
            If Not _numbers.Contains(_number) _
                Or _numbers.Count < 1 Then ' If Chosen or None
                _numbers.Add(_number) ' Add Number
            End If
        End While
        Return _Numbers
    End Function

    Private Sub Draw(ByRef Stack As StackPanel)
        Stack.Children.Clear()
        For Each _number As Integer In Numbers() ' Choose Numbers
            Dim _container As New Canvas
            Dim _ball As New Ellipse
            Dim _text As New TextBlock
            _container.Margin = New Thickness(2)
            _container.Width = 48
            _container.Height = 48
            _ball.Width = _container.Width
            _ball.Height = _container.Height
            Select Case _number
                Case 1 To 9
                    _ball.Fill = New SolidColorBrush(Colors.White)
                Case 10 To 19 ' Sky Blue
                    _ball.Fill = New SolidColorBrush(Color.FromArgb(255, 112, 200, 236))
                Case 20 To 29
                    _ball.Fill = New SolidColorBrush(Colors.Magenta)
                Case 30 To 39 ' Lawn Green
                    _ball.Fill = New SolidColorBrush(Color.FromArgb(255, 112, 255, 0))
                Case 40 To 49
                    _ball.Fill = New SolidColorBrush(Colors.Yellow)
            End Select
            _ball.Effect = New Effects.DropShadowEffect
            _container.Children.Add(_ball)
            _text.FontSize = 12
            _text.Text = _number
            _text.Margin = New Thickness(16)
            _container.Children.Add(_text)
            Stack.Children.Add(_container)
        Next
    End Sub

    Private Sub Choose_Click(ByVal sender As System.Object, _
                             ByVal e As System.Windows.RoutedEventArgs) _
                         Handles Choose.Click
        Draw(Lottery)
    End Sub
End Class

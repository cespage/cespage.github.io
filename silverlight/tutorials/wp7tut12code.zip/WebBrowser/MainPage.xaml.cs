﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Text.RegularExpressions;
using System.IO.IsolatedStorage;

namespace WebBrowser
{
    public partial class MainPage : PhoneApplicationPage
    {
        string filename = "favourite.url";
        Regex favourite = new Regex("^URL=(?<URL>.*)$", RegexOptions.Multiline);
        IsolatedStorageFile storage = IsolatedStorageFile.GetUserStoreForApplication();

        private void Go_Click(object sender, RoutedEventArgs e)
        {
            if (!Location.Text.StartsWith("http://")
            && !Location.Text.StartsWith("https://"))
            {
                Location.Text = ("http://" + Location.Text);
            }
            Browser.Navigate(new Uri(Location.Text));
        }

        private void Open_Click(object sender, EventArgs e)
        {
            if (storage.FileExists(filename))
            {
                IsolatedStorageFileStream location = new IsolatedStorageFileStream(filename,
                System.IO.FileMode.Open, storage);
                System.IO.StreamReader file = new System.IO.StreamReader(location);
                Location.Text = favourite.Match(file.ReadToEnd()).Groups["URL"].Value;
                Browser.Navigate(new Uri(Location.Text));
            }
        }

        private void Save_Click(object sender, EventArgs e)
        {
            IsolatedStorageFileStream location = new IsolatedStorageFileStream(filename,
            System.IO.FileMode.Create, storage);
            System.IO.StreamWriter file = new System.IO.StreamWriter(location);
            file.Write("[DEFAULT]\r\n" +
            "BASEURL=" + Browser.Source.AbsoluteUri + "\r\n" +
            "[InternetShortcut]\r\n" +
            "URL=" + Browser.Source.AbsoluteUri);
            file.Dispose();
            location.Dispose();
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Delete Favourite?", "Web Browser",
            MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                if (storage.FileExists(filename))
                {
                    storage.DeleteFile(filename);
                }
            }
        }

        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }
    }
}

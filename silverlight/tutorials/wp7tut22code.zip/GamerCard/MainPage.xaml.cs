﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Xml.Linq;
using System.Text.RegularExpressions;

namespace GamerCard
{
    public partial class MainPage : PhoneApplicationPage
    {
        private XElement xml;
        private Gamer gamer = new Gamer();

        private void Download(object Sender, DownloadStringCompletedEventArgs e)
        {
            try
            {
                if (!e.Cancelled)
                {
                    xml = XElement.Parse(Regex.Match(e.Result, @"\<body\>(.*?)\</body\>",
                    RegexOptions.IgnoreCase).Value);
                    // Tag
                    gamer.Tag = Subject.Text;
                    PageTitle.Text = gamer.Tag;
                    // Avatar
                    gamer.Avatar = new Uri(String.Format("http://avatar.xboxlive.com/avatar/{0}/avatar-body.png",
                    gamer.Tag));
                    // Account
                    string gamerAccount = (from account in xml.Descendants("h3")
                                           where account.Attribute("class").Value.StartsWith("XbcGamertag")
                                           select account.Attribute("class").Value).Single();
                    gamer.Account = gamerAccount.EndsWith("Gold") ? gamer.Gold : gamer.Silver;
                    // Gamer Picture
                    gamer.Picture = new Uri((from picture in xml.Descendants()
                                             where (string)picture.Attribute("class") == "XbcgcGamertile"
                                             select picture.Attribute("src").Value).Single());
                    // Gamer Score
                    gamer.Score = int.Parse((from score in xml.Descendants()
                                             where (string)score.Attribute("alt") == "Gamerscore"
                                             select score.Parent.ElementsAfterSelf("span").First()
                                           .Value).Single());
                    // Reputation
                    gamer.Reputation = (double.Parse(String.Join(String.Empty,
                      Regex.Split((from rep in xml.Descendants("span")
                                   where rep.Value == "Rep"
                                   select rep.ElementsAfterSelf("span").First()
                                   .Element("img").Attribute("src").Value).Single(),
                      "[^\\d,]"))) / 4).ToString();
                    // Zone
                    gamer.Zone = (from zone in xml.Descendants("span")
                                  where zone.Value == "Zone"
                                  select zone.ElementsAfterSelf("span").First().Value).Single();
                    // Played
                    var gamerPlayed = (from play in xml.Descendants("div").Elements("a")
                                       where (string)play.Parent.Attribute("class") == "XbcgcGames"
                                       select new
                                       {
                                           gamerTitle = play.Element("img").Attribute("title").Value,
                                           gamerImage = play.Element("img").Attribute("src").Value
                                       });
                    List<Game> played = new List<Game>();
                    foreach (var item in gamerPlayed)
                    {
                        Game game = new Game();
                        game.Title = item.gamerTitle;
                        game.Image = new Uri(item.gamerImage);
                        played.Add(game);
                    }
                    gamer.Played = played;
                    // Data Context
                    this.DataContext = gamer;
                }
            }
            catch
            {
                // Ignore Errors
            }
        }

        private void Lookup_Click(object sender, RoutedEventArgs e)
        {
            WebClient _client = new WebClient();
            _client.DownloadStringCompleted += Download;
            _client.DownloadStringAsync(new Uri(String.Format("http://gamercard.xbox.com/{0}.card",
            HttpUtility.UrlEncode(Subject.Text))));
        }

        // Constructor
        public MainPage()
        {
            InitializeComponent();
            ApplicationTitle.Text = "GAMER CARD";
            PageTitle.Text = "gamer card";
            Subject.Text = "RoguePlanetoid";
        }
    }
}

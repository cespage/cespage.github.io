﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Collections.Generic;

namespace GamerCard
{
    public class Game
    {
        public string Title { get; set; }
        public Uri Image { get; set; }
    }

    public class Gamer : INotifyPropertyChanged
    {
        private string _tag;
        private string _zone;
        private string _reputation;
        private Uri _avatar;
        private Uri _picture;
        private int _score;
        private SolidColorBrush _account;
        private List<Game> _played = new List<Game>();

        public SolidColorBrush Gold = new
        SolidColorBrush(Color.FromArgb(255, 225, 215, 0));
        public SolidColorBrush Silver = new
        SolidColorBrush(Color.FromArgb(255, 194, 194, 194));

        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String info)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(info));
            }
        }

        public string Tag
        {
            get { return _tag; }
            set
            {
                _tag = value;
                NotifyPropertyChanged("Tag");
            }
        }

        public string Zone
        {
            get { return "Zone:" + _zone; }
            set
            {
                _zone = value;
                NotifyPropertyChanged("Zone");
            }
        }

        public string Reputation
        {
            get { return "Rep:" + _reputation; }
            set
            {
                _reputation = value;
                NotifyPropertyChanged("Reputation");
            }
        }

        public Uri Avatar
        {
            get { return _avatar; }
            set
            {
                _avatar = value;
                NotifyPropertyChanged("Avatar");
            }
        }

        public Uri Picture
        {
            get { return _picture; }
            set
            {
                _picture = value;
                NotifyPropertyChanged("Picture");
            }
        }

        public int Score
        {
            get { return _score; }
            set
            {
                _score = value;
                NotifyPropertyChanged("Score");
            }
        }

        public SolidColorBrush Account
        {
            get { return _account; }
            set
            {
                _account = value;
                NotifyPropertyChanged("Account");
            }
        }

        public List<Game> Played
        {
            get { return _played; }
            set
            {
                _played = value;
                NotifyPropertyChanged("Played");
            }
        }

    }
}

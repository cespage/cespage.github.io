﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;

namespace FlipPanel
{
    [TemplateVisualState(Name = "Normal", GroupName = "ViewStates")]
    [TemplateVisualState(Name = "Flipped", GroupName = "ViewStates")]
    [TemplatePart(Name = "FlipButton", Type = typeof(ToggleButton))]
    [TemplatePart(Name = "FlipButtonAlternative", Type = typeof(ToggleButton))]
    public class FlipPanel : Control
    {
        public static readonly DependencyProperty FrontContentProperty =
        DependencyProperty.Register("FrontContent", typeof(object),
        typeof(FlipPanel), null);

        public static readonly DependencyProperty BackContentProperty =
        DependencyProperty.Register("BackContent", typeof(object),
        typeof(FlipPanel), null);

        public static readonly DependencyProperty IsFlippedProperty =
        DependencyProperty.Register("IsFlipped", typeof(bool),
        typeof(FlipPanel), new PropertyMetadata(true));

        public static readonly DependencyProperty CornerRadiusProperty =
        DependencyProperty.Register("CornerRadius", typeof(CornerRadius),
        typeof(FlipPanel), null);

        public object FrontContent
        {
            get { return GetValue(FrontContentProperty); }
            set { SetValue(FrontContentProperty, value); }
        }

        public object BackContent
        {
            get { return GetValue(BackContentProperty); }
            set { SetValue(BackContentProperty, value); }
        }

        public bool IsFlipped
        {
            get { return (bool)GetValue(IsFlippedProperty); }
            set { SetValue(IsFlippedProperty, value); }
        }

        public CornerRadius CornerRadius
        {
            get { return (CornerRadius)GetValue(CornerRadiusProperty); }
            set { SetValue(CornerRadiusProperty, value); }
        }

        public FlipPanel()
        {
            DefaultStyleKey = typeof(FlipPanel);
        }

        private void ChangeVisualState(bool useTransitions)
        {
            if (IsFlipped)
            {
                VisualStateManager.GoToState(this, "Normal", useTransitions);
            }
            else
            {
                VisualStateManager.GoToState(this, "Flipped", useTransitions);
            }
        }

        private void FlipButton_Click(object sender, RoutedEventArgs e)
        {
            IsFlipped = !IsFlipped;
            ChangeVisualState(true);
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            ToggleButton _flipButton = (ToggleButton)GetTemplateChild("FlipButton");
            if (_flipButton != null)
            {
                _flipButton.Click += FlipButton_Click;
            }
            ToggleButton _flipButtonAlt = (ToggleButton)GetTemplateChild("FlipButtonAlternative");
            if (_flipButtonAlt != null)
            {
                _flipButtonAlt.Click += FlipButton_Click;
            }
            ChangeVisualState(false);
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace NoughtsAndCrosses
{
    public partial class MainPage : PhoneApplicationPage
    {
        bool _hasWon = false;
        string _piece = "";
        string _nought = "O";
        string _cross = "X";
        string[,] _board = new string[3, 3];

        private bool Winner()
        {
            return
            (_board[0, 0] == _piece && _board[0, 1] == _piece && _board[0, 2] == _piece) ||
            (_board[1, 0] == _piece && _board[1, 1] == _piece && _board[1, 2] == _piece) ||
            (_board[2, 0] == _piece && _board[2, 1] == _piece && _board[2, 2] == _piece) ||
            (_board[0, 0] == _piece && _board[1, 0] == _piece && _board[2, 0] == _piece) ||
            (_board[0, 1] == _piece && _board[1, 1] == _piece && _board[2, 1] == _piece) ||
            (_board[0, 2] == _piece && _board[1, 2] == _piece && _board[2, 2] == _piece) ||
            (_board[0, 0] == _piece && _board[1, 1] == _piece && _board[2, 2] == _piece) ||
            (_board[0, 2] == _piece && _board[1, 1] == _piece && _board[2, 0] == _piece);
        }

        private bool Drawn()
        {
            return
            _board[0, 0] != "" && _board[0, 1] != "" && _board[0, 2] != "" &&
            _board[1, 0] != "" && _board[1, 1] != "" && _board[1, 2] != "" &&
            _board[2, 0] != "" && _board[2, 1] != "" && _board[2, 2] != "";
        }

        private Path GetPiece()
        {
            if ((_piece == _cross)) // Draw X
            {
                Path _lines = new Path();
                LineGeometry _line1 = new LineGeometry();
                LineGeometry _line2 = new LineGeometry();
                GeometryGroup _linegroup = new GeometryGroup();
                _line1.StartPoint = new Point(0, 0);
                _line1.EndPoint = new Point(64, 64);
                _line2.StartPoint = new Point(64, 0);
                _line2.EndPoint = new Point(0, 64);
                _linegroup.Children.Add(_line1);
                _linegroup.Children.Add(_line2);
                _lines.Data = _linegroup;
                _lines.Stroke = new SolidColorBrush(Colors.Red);
                _lines.StrokeThickness = 6;
                _lines.Margin = new Thickness(5);
                return _lines;
            }
            else // Draw O
            {
                EllipseGeometry _ellipse = new EllipseGeometry();
                Path _circle = new Path();
                _ellipse.Center = new Point(32, 32);
                _ellipse.RadiusX = 32;
                _ellipse.RadiusY = 32;
                _circle.Data = _ellipse;
                _circle.Stroke = new SolidColorBrush(Colors.Blue);
                _circle.StrokeThickness = 6;
                _circle.Margin = new Thickness(5);
                return _circle;
            }
        }

        private void Button_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (!_hasWon)
            {
                Button _btn = new Button();
                _btn = ((Button)(sender));
                if ((_btn.Content == null))
                {
                    _btn.Content = GetPiece();
                    _board[(int)_btn.GetValue(Grid.RowProperty),
                    (int)_btn.GetValue(Grid.ColumnProperty)] = _piece;
                }
                if (Winner())
                {
                    _hasWon = true;
                    MessageBox.Show((_piece + " wins!"), "Noughts and Crosses", MessageBoxButton.OK);
                }
                else if (Drawn())
                {
                    MessageBox.Show("Draw!", "Noughts and Crosses", MessageBoxButton.OK);
                }
                else
                {
                    _piece = ((_piece == _cross) ? _nought : _cross); // Swap Players
                }
            }
            else
            {
                MessageBox.Show("Game Over!", "Noughts and Crosses", MessageBoxButton.OK);
            }
        }

        private void Add(ref Grid Grid, int Row, int Column)
        {
            Button _btn = new Button();
            _btn.Click += Button_Click;
            _btn.Content = null;
            _btn.Margin = new Thickness(2);
            _btn.SetValue(Grid.ColumnProperty, Column);
            _btn.SetValue(Grid.RowProperty, Row);
            Grid.Children.Add(_btn);
        }

        private void Layout(ref Grid Grid)
        {
            Grid.Children.Clear();
            Grid.ColumnDefinitions.Clear();
            Grid.RowDefinitions.Clear();
            // Setup 3x3 Grid
            for (int Index = 0; (Index <= 2); Index++)
            {
                Grid.RowDefinitions.Add(new RowDefinition());
                Grid.ColumnDefinitions.Add(new ColumnDefinition());
            }
            Add(ref Grid, 0, 0); // Top Left
            Add(ref Grid, 0, 1); // Top Middle
            Add(ref Grid, 0, 2); // Top Right
            Add(ref Grid, 1, 0); // Middle Left
            Add(ref Grid, 1, 1); // Centre
            Add(ref Grid, 1, 2); // Middle Right
            Add(ref Grid, 2, 0); // Bottom Left
            Add(ref Grid, 2, 1); // Bottom Middle
            Add(ref Grid, 2, 2); // Bottom Right
        }

        private void New_Click(object sender, RoutedEventArgs e)
        {
            Layout(ref Display);
            _board[0, 0] = "";
            _board[0, 1] = "";
            _board[0, 2] = "";
            _board[1, 0] = "";
            _board[1, 1] = "";
            _board[1, 2] = "";
            _board[2, 0] = "";
            _board[2, 1] = "";
            _board[2, 2] = "";
            _hasWon = false;
            if ((MessageBox.Show((_cross + " to go first?"), "Noughts and Crosses",
            MessageBoxButton.OKCancel) == MessageBoxResult.OK))
            {
                _piece = _cross;
            }
            else
            {
                _piece = _nought;
            }
        }

        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }
    }
}

﻿Imports System.Windows.Media.Imaging
Public Class SlideShow
    Private WithEvents _slideshow As New Windows.Threading.DispatcherTimer
    Private _images As New List(Of BitmapImage)
    Private _index As Integer
    Private _hasImages As Boolean
    Private _isPlaying As Boolean
    Private _isPaused As Boolean
    Private _isRepeat As Boolean

    Public Event Slide(ByVal Image As BitmapImage, ByVal Index As Integer)

    ''' <summary>Constructor</summary>
    ''' <remarks>Initialise Values</remarks>
    Public Sub New()
        _slideshow.Interval = TimeSpan.FromSeconds(1.5)
    End Sub

    ''' <summary>Browse</summary>
    ''' <param name="Path">Directory to Browse</param>
    ''' <returns>True if Success, False if no JPEGs Found</returns>
    ''' <remarks>Requires Full Trust</remarks>
    Public Function Browse(ByRef Path As String) As Boolean
        Dim _dirInfo As New IO.DirectoryInfo(Path)
        _images.Clear()
        For Each File In _dirInfo.EnumerateFiles("*.j*pg")
            Using FileStream As IO.Stream = File.OpenRead
                Dim Source As New BitmapImage
                Source.SetSource(FileStream)
                _images.Add(Source)
            End Using
        Next
        _hasImages = _images.Count > 0
        Return _hasImages
    End Function

    ''' <summary>Play</summary>
    ''' <remarks>Play Slideshow</remarks>
    Public Sub Play()
        If _hasImages Then
            If _isPaused Or Not _isPlaying Then
                _slideshow.Start()
                _isPlaying = True
                _isPaused = False
            End If
        End If
    End Sub

    ''' <summary>Pause</summary>
    ''' <remarks>Pause Slideshow</remarks>
    Public Sub Pause()
        If _hasImages Then
            If _isPlaying Then
                _slideshow.Stop()
                _isPaused = True
                _isPlaying = False
            End If
        End If
    End Sub

    ''' <summary>Stop</summary>
    ''' <remarks>Stop Slideshow</remarks>
    Public Sub [Stop]()
        If _hasImages Then
            _index = 0
            _slideshow.Stop()
            _isPaused = False
            _isPlaying = False
        End If
    End Sub

    ''' <summary>Selected</summary>
    ''' <param name="Index">Selected Index</param>
    ''' <remarks>Selected Slide</remarks>
    Public Sub Selected(ByRef index As Integer)
        If _hasImages Then
            If index < _images.Count Then
                _index = index
                If _isPlaying Then
                    Me.Play()
                End If
            End If
        End If
    End Sub

    ''' <summary>SlideShow_Tick</summary>
    ''' <param name="sender">Object</param>
    ''' <param name="e">Event</param>
    ''' <remarks>SlideShow DispatcherTimer</remarks>
    Private Sub SlideShow_Tick(ByVal sender As Object, _
                              ByVal e As EventArgs) _
                                Handles _slideshow.Tick
        If _hasImages And _isPlaying Then
            If _index < _images.Count Then
                RaiseEvent Slide(_images.Item(_index), _index)
                _index += 1
            Else
                If _isRepeat Then
                    _index = 0 ' Reset if Repeat
                Else
                    Me.Stop() ' Stop
                End If
            End If
        End If
    End Sub

    ''' <summary>Speed</summary>
    ''' <value>TimeSpan</value>
    ''' <returns>DispatchTimer TimeSpan</returns>
    ''' <remarks>SlideShow Interval (Speed)</remarks>
    Public Property Speed As TimeSpan
        Get
            Return _slideshow.Interval
        End Get
        Set(ByVal value As TimeSpan)
            If value <> _slideshow.Interval Then
                _slideshow.Interval = value
            End If
        End Set
    End Property

    ''' <summary>Position</summary>
    ''' <value>Integer</value>
    ''' <returns>Integer</returns>
    ''' <remarks>SlideShow Current Position</remarks>
    Public Property Position As Integer
        Get
            Return _index
        End Get
        Set(ByVal value As Integer)
            _index = value
        End Set
    End Property

    ''' <summary>Count</summary>
    ''' <value>Integer</value>
    ''' <returns>Images List(Of BitmapImage) Count</returns>
    ''' <remarks>SlideShow Count</remarks>
    Public ReadOnly Property Count As Integer
        Get
            Return _images.Count
        End Get
    End Property

    ''' <summary>Playing</summary>
    ''' <value>Boolean</value>
    ''' <returns>True if Playing, False if Not</returns>
    ''' <remarks>SlideShow Playing</remarks>
    Public ReadOnly Property Playing As Boolean
        Get
            Return _isPlaying
        End Get
    End Property

    ''' <summary>Paused</summary>
    ''' <value>Boolean</value>
    ''' <returns>True if Paused, False if Not</returns>
    ''' <remarks>SlideShow Paused</remarks>
    Public ReadOnly Property Paused As Boolean
        Get
            Return _isPaused
        End Get
    End Property

    ''' <summary>Repeat</summary>
    ''' <value>Boolean</value>
    ''' <returns>Boolean</returns>
    ''' <remarks>Repeat SlideShow</remarks>
    Public Property Repeat() As Boolean
        Get
            Return _isRepeat
        End Get
        Set(ByVal value As Boolean)
            _isRepeat = value
        End Set
    End Property

End Class

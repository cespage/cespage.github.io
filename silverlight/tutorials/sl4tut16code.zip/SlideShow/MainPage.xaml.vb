﻿Partial Public Class MainPage
    Inherits UserControl
    Public WithEvents SlideShow As New SlideShow

    Public Sub New()
        InitializeComponent()
    End Sub

    Private Sub SlideShow_Slide(ByVal Image As Imaging.BitmapImage, _
                                ByVal Index As Integer) _
                            Handles SlideShow.Slide
        Display.Source = Image
        Position.Value = Index
    End Sub

    Private Sub Browse_Click(ByVal sender As System.Object, _
                             ByVal e As System.Windows.RoutedEventArgs) _
                         Handles Browse.Click
        Dim OpenDialog As New OpenFileDialog
        OpenDialog.Filter = "JPEG Images (*.jpg;*.jpeg)|*.jpg;*.jpeg"
        If OpenDialog.ShowDialog Then
            Try
                If OpenDialog.File.Exists Then
                    If App.Current.HasElevatedPermissions Then ' Show All Images
                        If SlideShow.Browse(OpenDialog.File.DirectoryName) Then
                            Position.Value = 0
                            Position.Minimum = 0
                            Position.Maximum = SlideShow.Count - 1
                            SlideShow.Play()
                        End If
                    Else ' Show Single Image
                        Using FileStream As IO.Stream = OpenDialog.File.OpenRead
                            Dim Source As New Imaging.BitmapImage
                            Source.SetSource(FileStream)
                            Display.Source = Source
                        End Using
                    End If
                End If
            Catch ex As Exception
                ' Ignore Errors
            End Try
        End If
    End Sub

    Private Sub PlayPause_Click(ByVal sender As System.Object, _
                                ByVal e As System.Windows.RoutedEventArgs) _
                            Handles PlayPause.Click
        If SlideShow.Playing Then
            If SlideShow.Paused Then
                SlideShow.Play()
            Else
                SlideShow.Pause()
            End If
        Else
            SlideShow.Play()
        End If
    End Sub

    Private Sub Stop_Click(ByVal sender As System.Object, _
                           ByVal e As System.Windows.RoutedEventArgs) _
                       Handles [Stop].Click
        SlideShow.Stop()
    End Sub

    Private Sub Repeat_Click(ByVal sender As System.Object, _
                             ByVal e As System.Windows.RoutedEventArgs) _
                         Handles Repeat.Click
        SlideShow.Repeat = Repeat.IsChecked
    End Sub

    Private Sub Position_ValueChanged(ByVal sender As System.Object, _
                                      ByVal e As System.Windows.RoutedPropertyChangedEventArgs(Of System.Double)) _
                                  Handles Position.ValueChanged
        SlideShow.Position = CInt(Position.Value)
    End Sub

    Private Sub Speed_ValueChanged(ByVal sender As System.Object, _
                                   ByVal e As System.Windows.RoutedPropertyChangedEventArgs(Of System.Double)) _
                               Handles Speed.ValueChanged
        SlideShow.Speed = TimeSpan.FromMilliseconds(Speed.Value)
    End Sub
End Class

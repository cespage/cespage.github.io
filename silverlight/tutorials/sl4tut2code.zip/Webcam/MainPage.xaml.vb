﻿Partial Public Class MainPage
    Inherits UserControl
    Private Source As New CaptureSource
    Public Sub New()
        InitializeComponent()
        Source.VideoCaptureDevice = CaptureDeviceConfiguration.GetDefaultVideoCaptureDevice()
        Display.SetSource(Source)
    End Sub
    Private Sub Capture_Click(ByVal sender As System.Object, _
                              ByVal e As System.Windows.RoutedEventArgs) _
                          Handles Capture.Click
        If CaptureDeviceConfiguration.AllowedDeviceAccess Or _
            CaptureDeviceConfiguration.RequestDeviceAccess() Then
            If Source.State = CaptureState.Stopped Then
                Source.Start()
            Else
                Source.Stop()
            End If
        End If
    End Sub
End Class
﻿Partial Public Class MainPage
    Inherits UserControl

    Public Sub New()
        InitializeComponent()
    End Sub

    Private Sub Player_MediaOpened(ByVal sender As Object, _
                               ByVal args As RoutedEventArgs) _
                           Handles Player.MediaOpened
        Position.Maximum = Player.NaturalDuration.TimeSpan.TotalMilliseconds
    End Sub

    Private Sub Player_MediaEnded(ByVal sender As Object, _
                                   ByVal args As RoutedEventArgs) _
                               Handles Player.MediaEnded
        Player.Stop()
    End Sub

    Private Sub Open_Click(ByVal sender As System.Object, _
                           ByVal e As System.Windows.RoutedEventArgs) _
                       Handles Open.Click
        Dim OpenDialog As New OpenFileDialog
        OpenDialog.Filter = "Audio|*.wma;*.mp3|Video|*.wmv;*mp4"
        If OpenDialog.ShowDialog Then
            Try
                If OpenDialog.File.Exists Then
                    Player.SetSource(OpenDialog.File.OpenRead())
                End If
            Catch ex As Exception
                ' Ignore Errors
            End Try
        End If
    End Sub

    Private Sub PlayPause_Click(ByVal sender As System.Object, _
                                ByVal e As System.Windows.RoutedEventArgs) _
                            Handles PlayPause.Click
        If Player.CurrentState = MediaElementState.Playing Then
            Player.Pause()
        Else
            Player.Play()
        End If
    End Sub

    Private Sub Stop_Click(ByVal sender As System.Object, _
                           ByVal e As System.Windows.RoutedEventArgs) _
                       Handles [Stop].Click
        Player.Stop()
    End Sub

    Private Sub Balance_ValueChanged(ByVal sender As System.Object, _
                                     ByVal e As System.Windows.RoutedPropertyChangedEventArgs(Of System.Double)) _
                                 Handles Balance.ValueChanged
        Player.Balance = Balance.Value
    End Sub

    Private Sub Position_ValueChanged(ByVal sender As System.Object, _
                                      ByVal e As System.Windows.RoutedPropertyChangedEventArgs(Of System.Double)) _
                                  Handles Position.ValueChanged
        Player.Position = TimeSpan.FromMilliseconds(CInt(Position.Value))
    End Sub

    Private Sub Volume_ValueChanged(ByVal sender As System.Object, _
                                    ByVal e As System.Windows.RoutedPropertyChangedEventArgs(Of System.Double)) _
                                Handles Volume.ValueChanged
        Player.Volume = Volume.Value
    End Sub
End Class
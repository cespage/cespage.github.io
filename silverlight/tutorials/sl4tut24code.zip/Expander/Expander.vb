﻿Imports System.Windows.Controls.Primitives
<TemplateVisualState(Name:="Collapsed", GroupName:="ViewStates"),
TemplateVisualState(Name:="Expanded", GroupName:="ViewStates"),
TemplatePart(Name:="Content", Type:=GetType(FrameworkElement)),
TemplatePart(Name:="ExpandCollapseButton", Type:=GetType(ToggleButton))>
Public Class Expander
    Inherits ContentControl

    Private _useTransitions As Boolean = True
    Private _collapsedState As VisualState
    Private _toggleExpander As ToggleButton
    Private _contentElement As FrameworkElement

    Public Shared ReadOnly HeaderContentProperty As DependencyProperty =
    DependencyProperty.Register("HeaderContent", GetType(Object),
    GetType(Expander), Nothing)

    Public Shared ReadOnly IsExpandedProperty As DependencyProperty =
    DependencyProperty.Register("IsExpanded", GetType(Boolean),
    GetType(Expander), New PropertyMetadata(True))

    Public Shared ReadOnly CornerRadiusProperty As DependencyProperty =
    DependencyProperty.Register("CornerRadius", GetType(CornerRadius),
    GetType(Expander), Nothing)

    Public Property HeaderContent() As Object
        Get
            Return GetValue(HeaderContentProperty)
        End Get
        Set(ByVal value As Object)
            SetValue(HeaderContentProperty, value)
        End Set
    End Property

    Public Property IsExpanded() As Boolean
        Get
            Return CBool(GetValue(IsExpandedProperty))
        End Get
        Set(ByVal value As Boolean)
            SetValue(IsExpandedProperty, value)
        End Set
    End Property

    Public Property CornerRadius() As CornerRadius
        Get
            Return CType(GetValue(CornerRadiusProperty), CornerRadius)
        End Get
        Set(ByVal value As CornerRadius)
            SetValue(CornerRadiusProperty, value)
        End Set
    End Property

    Public Sub New()
        DefaultStyleKey = GetType(Expander)
    End Sub

    Private Sub ChangeVisualState(ByVal useTransitions As Boolean)
        If IsExpanded Then
            If _contentElement IsNot Nothing Then
                _contentElement.Visibility = Visibility.Visible
            End If
            VisualStateManager.GoToState(Me, "Expanded", useTransitions)
        Else
            VisualStateManager.GoToState(Me, "Collapsed", useTransitions)
            _collapsedState = TryCast(GetTemplateChild("Collapsed"), VisualState)
            If _collapsedState Is Nothing Then
                If _contentElement IsNot Nothing Then
                    _contentElement.Visibility = Visibility.Collapsed
                End If
            End If
        End If
    End Sub

    Private Sub Toggle_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        IsExpanded = Not IsExpanded
        _toggleExpander.IsChecked = IsExpanded
        ChangeVisualState(_useTransitions)
    End Sub

    Private Sub Collapsed_Completed(ByVal sender As Object, ByVal e As EventArgs)
        _contentElement.Visibility = Visibility.Collapsed
    End Sub

    Public Overrides Sub OnApplyTemplate()
        MyBase.OnApplyTemplate()
        _toggleExpander = TryCast(GetTemplateChild("ExpandCollapseButton"), ToggleButton)
        If _toggleExpander IsNot Nothing Then
            AddHandler _toggleExpander.Click, AddressOf Toggle_Click
        End If
        _contentElement = TryCast(GetTemplateChild("Content"), FrameworkElement)
        If _contentElement IsNot Nothing Then
            _collapsedState = TryCast(GetTemplateChild("Collapsed"), VisualState)
            If (_collapsedState IsNot Nothing) AndAlso (_collapsedState.Storyboard IsNot Nothing) Then
                AddHandler _collapsedState.Storyboard.Completed, AddressOf Collapsed_Completed
            End If
        End If
        ChangeVisualState(False)
    End Sub

End Class

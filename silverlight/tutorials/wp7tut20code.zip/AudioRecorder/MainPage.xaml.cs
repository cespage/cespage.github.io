﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Xna.Framework.Audio;
using System.IO;

namespace AudioRecorder
{
    public partial class MainPage : PhoneApplicationPage
    {
        private Microphone microphone = Microphone.Default;
        private byte[] buffer;
        private MemoryStream stream = new MemoryStream();
        private SoundEffect sound;

        // Constructor
        public MainPage()
        {
            InitializeComponent();
            ApplicationTitle.Text = "AUDIO RECORDER";
            PageTitle.Text = "ready";
            microphone.BufferReady += (object sender, EventArgs e) =>
            {
                microphone.GetData(buffer);
                stream.Write(buffer, 0, buffer.Length);
            };
        }

        private void Record_Click(object sender, EventArgs e)
        {
            microphone.BufferDuration = TimeSpan.FromMilliseconds(1000);
            buffer = new byte[microphone.GetSampleSizeInBytes(microphone.BufferDuration)];
            microphone.Start();
            PageTitle.Text = "record";
        }

        private void Play_Click(object sender, EventArgs e)
        {
            sound = new SoundEffect(stream.ToArray(), microphone.SampleRate, AudioChannels.Mono);
            sound.Play();
            PageTitle.Text = "play";
        }

        private void Stop_Click(object sender, EventArgs e)
        {
            if (microphone.State == MicrophoneState.Started)
            {
                microphone.Stop();
                PageTitle.Text = "stop";
            }
            else
            {
                PageTitle.Text = "ready";
            }
        }

    }
}

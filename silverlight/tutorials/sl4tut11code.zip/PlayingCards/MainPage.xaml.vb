﻿Partial Public Class MainPage
    Inherits UserControl
    Private Const CLUBS As String = "♣"
    Private Const DIAMONDS As String = "♦"
    Private Const HEARTS As String = "♥"
    Private Const SPADES As String = "♠"
    Private Const ACE As String = "A"
    Private Const JACK As String = "J"
    Private Const QUEEN As String = "Q"
    Private Const KING As String = "K"

    Private _deckOne, _deckTwo As List(Of Integer)
    Private _cardOne, _cardTwo As Integer
    Private _first, _second As Integer
    Private _score, _counter As Integer
    Public Sub New()
        InitializeComponent()
    End Sub

    Private Function Pip(ByRef Content As String, ByRef Foreground As Color, _
                     ByRef FontSize As Double, ByRef FontFamily As String, _
                     ByRef Left As Double, ByRef Top As Double) As TextBlock
        Dim _pip As New TextBlock
        _pip.FontSize = FontSize
        _pip.FontFamily = New FontFamily(FontFamily)
        _pip.Text = Content
        _pip.Foreground = New SolidColorBrush(Foreground)
        _pip.SetValue(Canvas.LeftProperty, Left)
        _pip.SetValue(Canvas.TopProperty, Top)
        Return _pip
    End Function

    Private Function Deck(ByRef Card As Integer, ByRef BackColor As Color) As Canvas
        Dim _card As New Canvas
        Dim _text As TextBlock = Nothing
        Dim _fore As Color = Colors.Black
        Dim _suite As String = ""
        Dim _display As String = ""
        Dim _value As String = ""
        Select Case Card
            Case 1 To 13
                _fore = Colors.Black
                _suite = CLUBS
                _display = Card
            Case 14 To 26
                _fore = Colors.Red
                _suite = DIAMONDS
                _display = Card - 13
            Case 27 To 39
                _fore = Colors.Red
                _suite = HEARTS
                _display = Card - 26
            Case 40 To 52
                _fore = Colors.Black
                _suite = SPADES
                _display = Card - 39
        End Select
        _value = _display
        _card.Width = 110
        _card.Height = 150
        _card.Background = New SolidColorBrush(BackColor)
        Select Case _value
            Case 1
                _display = ACE
                _card.Children.Add(Pip(_suite, _fore, 70, "Times New Roman", 35, 30)) ' Centre
            Case 2
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 42, 0)) ' Middle Top
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 42, 104)) ' Middle Bottom
            Case 3
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 42, 0)) ' Middle Top
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 42, 52)) ' Centre
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 42, 104)) ' Middle Bottom
            Case 4
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 16, 0)) ' Top Left
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 68, 0)) ' Top Right
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 16, 104)) ' Bottom Left
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 68, 104)) ' Bottom Right
            Case 5
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 16, 0)) ' Top Left
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 68, 0)) ' Top Right
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 42, 52)) ' Centre
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 16, 104)) ' Bottom Left
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 68, 104)) ' Bottom Right
            Case 6
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 16, 0)) ' Top Left
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 68, 0)) ' Top Right
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 16, 52)) ' Centre Left
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 68, 52)) ' Centre Right
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 16, 104)) ' Bottom Left
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 68, 104)) ' Bottom Right
            Case 7
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 16, 0)) ' Top Left
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 68, 0)) ' Top Right
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 16, 52)) ' Centre Left
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 42, 26)) ' Centre Top
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 68, 52)) ' Centre Right
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 16, 104)) ' Bottom Left
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 68, 104)) ' Bottom Right
            Case 8
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 16, 0)) ' Top Left
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 68, 0)) ' Top Right
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 16, 52)) ' Centre Left
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 42, 26)) ' Centre Top
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 42, 78)) ' Centre Bottom
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 68, 52)) ' Centre Right
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 16, 104)) ' Bottom Left
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 68, 104)) ' Bottom Right
            Case 9
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 16, 0)) ' Top Left
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 68, 0)) ' Top Right
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 16, 34)) ' Centre Left Top
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 16, 70)) ' Centre Left Bottom
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 42, 52)) ' Centre
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 68, 34)) ' Centre Right Top
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 68, 70)) ' Centre Right Bottom
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 16, 104)) ' Bottom Left
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 68, 104)) ' Bottom Right
            Case 10
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 16, 0)) ' Top Left
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 68, 0)) ' Top Right
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 16, 34)) ' Centre Left Top
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 16, 70)) ' Centre Left Bottom
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 42, 26)) ' Centre Top
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 42, 78)) ' Centre Bottom
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 68, 34)) ' Centre Right Top
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 68, 70)) ' Centre Right Bottom
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 16, 104)) ' Bottom Left
                _card.Children.Add(Pip(_suite, _fore, 40, "Arial", 68, 104)) ' Bottom Right
            Case 11
                _display = JACK
                _card.Children.Add(Pip(_display, _fore, 70, "Times New Roman", 40, 35)) ' Centre
            Case 12
                _display = QUEEN
                _card.Children.Add(Pip(_display, _fore, 70, "Times New Roman", 30, 30)) ' Centre
            Case 13
                _display = KING
                _card.Children.Add(Pip(_display, _fore, 70, "Times New Roman", 30, 35)) ' Centre
        End Select
        If Len(_display) = 1 Then
            _card.Children.Add(Pip(_display, _fore, 16, "Times New Roman", 2, 4))
            _card.Children.Add(Pip(_display, _fore, 16, "Times New Roman", 96, 116))
        Else
            _card.Children.Add(Pip(_display, _fore, 16, "Times New Roman", 0, 4))
            _card.Children.Add(Pip(_display, _fore, 16, "Times New Roman", 93, 116))
        End If
        _card.Children.Add(Pip(_suite, _fore, 20, "Arial", 1, 16))
        _card.Children.Add(Pip(_suite, _fore, 20, "Arial", 94, 130))
        Return _card
    End Function

    Private Function Card(ByRef Value As Integer, ByRef IsFacing As Boolean, _
                      ByRef BackColor As Color) As Canvas
        If IsFacing Then
            Return Deck(Value, BackColor)
        Else
            Dim _card As New Canvas
            _card.Width = 110
            _card.Height = 150
            _card.Background = New SolidColorBrush(BackColor)
            Return _card
        End If
    End Function

    Private Sub Match()
        If _cardOne < 52 And _cardTwo < 52 Then
            _first = _deckOne(_cardOne)
            PileOne.Content = Card(_first, True, Colors.White)
            _cardOne += 1
            _second = _deckTwo(_cardTwo)
            PileTwo.Content = Card(_second, True, Colors.White)
            _cardTwo += 1
            If _first Mod 13 = _second Mod 13 Then ' Ignore Suite for Match
                _score += 1
                MessageBox.Show("Match!", "Playing Cards", MessageBoxButton.OK)
            End If
            _counter += 1
        Else
            MessageBox.Show("Game Over! Matched " & _score & " out of " & _counter & " cards!", _
                            "Playing Cards", MessageBoxButton.OK)
        End If
    End Sub

    Private Function Shuffle() As List(Of Integer)
        Dim _number As Integer
        Dim _numbers As New List(Of Integer)
        While _numbers.Count < 52 ' Select 52 Numbers
            Randomize() ' Random Number
            _number = Int((52 * Rnd()) + 1) ' Between 1 - 52
            If Not _numbers.Contains(_number) _
                Or _numbers.Count < 1 Then ' If Chosen or None
                _numbers.Add(_number) ' Add Number
            End If
        End While
        Return _numbers
    End Function

    Private Sub New_Click(ByVal sender As System.Object, _
                          ByVal e As System.Windows.RoutedEventArgs) _
                      Handles [New].Click
        _score = 0
        PileOne.Content = Card(1, False, Colors.Red)
        PileTwo.Content = Card(1, False, Colors.Blue)
        _deckOne = Shuffle()
        _deckTwo = Shuffle()
    End Sub

    Private Sub PileOne_Click(ByVal sender As System.Object, _
                              ByVal e As System.Windows.RoutedEventArgs) _
                          Handles PileOne.Click
        If Not PileOne.Content Is Nothing Then
            Match()
        End If
    End Sub

    Private Sub PileTwo_Click(ByVal sender As System.Object, _
                              ByVal e As System.Windows.RoutedEventArgs) _
                          Handles PileTwo.Click
        If Not PileTwo.Content Is Nothing Then
            Match()
        End If
    End Sub
End Class

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Xml.Linq;

namespace TweetSearch
{
    public partial class MainPage : PhoneApplicationPage
    {

        private void Tweets(object Sender, DownloadStringCompletedEventArgs e)
        {
            XElement _xml;
            try
            {
                if (!e.Cancelled)
                {
                    _xml = XElement.Parse(e.Result);
                    foreach (XElement value in _xml.Elements("channel").Elements("item"))
                    {
                        Tweet _tweet = new Tweet();
                        XNamespace _google = "http://base.google.com/ns/1.0";
                        _tweet.Avatar = value.Element(_google + "image_link").Value;
                        _tweet.Title = value.Element("title").Value;
                        _tweet.Published = DateTime.Parse(value.Element("pubDate").Value);
                        _tweet.Author = value.Element("author").Value.Replace("@twitter.com", "");
                        Results.Items.Add(_tweet);
                    }
                }
            }
            catch
            {
                // Ignore Errors
            }
        }

        private void Query(string Value)
        {
            WebClient _client = new WebClient();
            _client.DownloadStringCompleted += Tweets;
            _client.DownloadStringAsync(new Uri(("http://search.twitter.com/search.rss?rpp=50&q="
            + HttpUtility.UrlEncode(Value))));
        }

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            Query(Subject.Text);
        }
        
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }
    }
}

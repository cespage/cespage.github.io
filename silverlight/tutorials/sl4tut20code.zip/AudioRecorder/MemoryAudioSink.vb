﻿Imports System.IO
Public Class MemoryAudioSink
    Inherits AudioSink
    Private _stream As MemoryStream ' Memory Sink
    Private _format As AudioFormat ' Recording Format

    Protected Overloads Overrides Sub OnCaptureStarted()
        _stream = New MemoryStream(1024)
    End Sub

    Protected Overloads Overrides Sub OnCaptureStopped()
    End Sub

    Protected Overloads Overrides Sub OnFormatChange(ByVal Format As AudioFormat)
        If Format.WaveFormat <> WaveFormatType.PCM Then
            Throw New InvalidOperationException("MemoryAudioSink only supports PCM Audio")
        End If
        _format = Format
    End Sub

    Protected Overloads Overrides Sub OnSamples(ByVal sampleTime As Long, _
                                                ByVal sampleDuration As Long, _
                                                ByVal sampleData As Byte())
        _stream.Write(sampleData, 0, sampleData.Length) ' Write Audio to Stream
    End Sub

    Public ReadOnly Property BackingStream() As Stream
        Get
            Return _stream
        End Get
    End Property

    Public ReadOnly Property CurrentFormat() As AudioFormat
        Get
            Return _format
        End Get
    End Property

End Class

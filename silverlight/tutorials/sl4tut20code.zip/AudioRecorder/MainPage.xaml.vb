﻿Imports System.IO
Partial Public Class MainPage
    Inherits UserControl
    Private _source As New CaptureSource
    Private _sink As MemoryAudioSink
    Private _isRecording As Boolean
    Private _hasRecorded As Boolean

    Public Sub New()
        InitializeComponent()
        _source.AudioCaptureDevice = CaptureDeviceConfiguration.GetDefaultAudioCaptureDevice
    End Sub

    Private Function InlineAssignHelper(Of T)(ByRef target As T, ByVal value As T) As T
        target = value
        Return value
    End Function

    Public Sub SavePcmToWav(ByRef Data As Stream, ByRef Output As Stream, _
                            ByRef Format As AudioFormat)
        If Format.WaveFormat <> WaveFormatType.PCM Then
            Throw New ArgumentException("Only PCM coding is supported.")
        End If
        Dim _output As New BinaryWriter(Output)
        ' WAV header
        _output.Write("RIFF".ToCharArray()) ' RIFF chunk
        _output.Write(CUInt((Data.Length + 36))) ' Total Length Of Package To Follow
        _output.Write("WAVE".ToCharArray()) ' WAV chunk
        _output.Write("fmt ".ToCharArray()) ' FORMAT chunk
        _output.Write(CUInt(&H10)) ' Length Of FORMAT Chunk (Binary, always 0x10)
        _output.Write(CUShort(&H1)) ' Always 0x01
        ' Channel Numbers (Always 0x01=Mono, 0x02=Stereo)
        _output.Write(CUShort(Format.Channels))
        _output.Write(CUInt(Format.SamplesPerSecond)) ' Sample Rate (Binary, in Hz)
        _output.Write(CUInt((Format.BitsPerSample * _
                             Format.SamplesPerSecond * _
                             Format.Channels / 8))) ' Bytes Per Second
        ' Bytes Per Sample: 1=8 bit Mono, 2=8 bit Stereo or 16 bit Mono, 4=16 bit Stereo
        _output.Write(CUShort((Format.BitsPerSample * _
                               Format.Channels / 8)))
        _output.Write(CUShort(Format.BitsPerSample)) ' Bits Per Sample
        _output.Write("data".ToCharArray()) ' DATA chunk
        _output.Write(CUInt(Data.Length)) ' Length Of Data To Follow
        ' Raw PCM data
        Dim originalPosition As Long = Data.Position ' Remember Original Position
        Data.Seek(0, SeekOrigin.Begin) ' Reset position in Data
        ' Append all data from Data stream into output stream.
        Dim buffer As Byte() = New Byte(4095) {}
        Dim read As Integer ' number of bytes read in one iteration
        While (InlineAssignHelper(read, Data.Read(buffer, 0, 4096))) > 0
            _output.Write(buffer, 0, read)
        End While
        Data.Seek(originalPosition, SeekOrigin.Begin) ' Restore Original Position
    End Sub

    Private Sub Record_Click(ByVal sender As System.Object, _
                             ByVal e As System.Windows.RoutedEventArgs) _
                         Handles Record.Click
        If Not _isRecording Then
            If (CaptureDeviceConfiguration.AllowedDeviceAccess _
            Or CaptureDeviceConfiguration.RequestDeviceAccess) _
            And _source.State = CaptureState.Stopped Then
                _sink = New MemoryAudioSink
                _sink.CaptureSource = _source
                _source.Start()
                _isRecording = True
                _hasRecorded = False
                Status.Text = "Recording..."
            End If
        End If
    End Sub

    Private Sub Stop_Click(ByVal sender As System.Object, _
                           ByVal e As System.Windows.RoutedEventArgs) _
                       Handles [Stop].Click
        If _source.State = CaptureState.Started Then
            _source.Stop()
            _isRecording = False
            _hasRecorded = True
            Status.Text = "Recording Complete"
        End If
    End Sub

    Private Sub Save_Click(ByVal sender As System.Object, _
                           ByVal e As System.Windows.RoutedEventArgs) _
                       Handles Save.Click
        If _hasRecorded Then
            Dim SaveDialog As New SaveFileDialog
            SaveDialog.Filter = "Audio Files (*.wav)|*.wav"
            If SaveDialog.ShowDialog Then
                Try
                    Status.Text = "Saving..."
                    Using FileStream As Stream = SaveDialog.OpenFile
                        SavePcmToWav(_sink.BackingStream, FileStream, _sink.CurrentFormat)
                    End Using
                    Status.Text = "Recording Saved"
                Catch ex As Exception
                    ' Ignore Errors
                End Try
            End If
        Else
            MessageBox.Show("Complete a Recording before Saving", _
                            "Audio Recorder", MessageBoxButton.OK)
        End If
    End Sub
End Class

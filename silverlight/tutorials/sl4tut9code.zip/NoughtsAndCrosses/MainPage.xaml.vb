﻿Partial Public Class MainPage
    Inherits UserControl
    Private _hasWon As Boolean = False
    Private _piece As String = ""
    Private _nought As String = "O"
    Private _cross As String = "X"
    Private _board(3, 3) As String
    Public Sub New()
        InitializeComponent()
    End Sub

    Private Function Winner() As Boolean
        Return (_board(0, 0) = _piece And _board(0, 1) = _piece And _board(0, 2) = _piece) Or _
        (_board(1, 0) = _piece And _board(1, 1) = _piece And _board(1, 2) = _piece) Or _
        (_board(2, 0) = _piece And _board(2, 1) = _piece And _board(2, 2) = _piece) Or _
        (_board(0, 0) = _piece And _board(1, 0) = _piece And _board(2, 0) = _piece) Or _
        (_board(0, 1) = _piece And _board(1, 1) = _piece And _board(2, 1) = _piece) Or _
        (_board(0, 2) = _piece And _board(1, 2) = _piece And _board(2, 2) = _piece) Or _
        (_board(0, 0) = _piece And _board(1, 1) = _piece And _board(2, 2) = _piece) Or _
        (_board(0, 2) = _piece And _board(1, 1) = _piece And _board(2, 0) = _piece)
    End Function

    Private Function Drawn() As Boolean
        Return _board(0, 0) <> "" And _board(0, 1) <> "" And _board(0, 2) <> "" _
        And _board(1, 0) <> "" And _board(1, 1) <> "" And _board(1, 2) <> "" _
        And _board(2, 0) <> "" And _board(2, 1) <> "" And _board(2, 2) <> ""
    End Function

    Private Function GetPiece() As Path
        If _piece = _cross Then ' Draw X
            Dim _lines As New Path
            Dim _line1, _line2 As New LineGeometry
            Dim _linegroup As New GeometryGroup
            _line1.StartPoint = New Point(0, 0)
            _line1.EndPoint = New Point(50, 50)
            _line2.StartPoint = New Point(50, 0)
            _line2.EndPoint = New Point(0, 50)
            _linegroup.Children.Add(_line1)
            _linegroup.Children.Add(_line2)
            _lines.Data = _linegroup
            _lines.Stroke = New SolidColorBrush(Colors.Red)
            _lines.StrokeThickness = 4.0
            _lines.Margin = New Thickness(5)
            Return _lines
        Else ' Draw O
            Dim _ellipse As New EllipseGeometry
            Dim _circle As New Path
            _ellipse.Center = New Point(25, 25)
            _ellipse.RadiusX = 25
            _ellipse.RadiusY = 25
            _circle.Data = _ellipse
            _circle.Stroke = New SolidColorBrush(Colors.Blue)
            _circle.StrokeThickness = 4.0
            _circle.Margin = New Thickness(5)
            Return _circle
        End If
    End Function

    Private Sub Button_Click(ByVal sender As System.Object, _
      ByVal e As System.Windows.RoutedEventArgs)
        If Not _hasWon Then
            Dim _btn As New Button
            _btn = CType(sender, Button)
            If _btn.Content Is Nothing Then
                _btn.Content = GetPiece()
                _board(_btn.GetValue(Grid.RowProperty), _
                  _btn.GetValue(Grid.ColumnProperty)) = _piece
            End If
            If Winner() Then
                _hasWon = True
                MessageBox.Show(_piece & " wins!", "Noughts and Crosses", MessageBoxButton.OK)
            ElseIf Drawn() Then
                MessageBox.Show("Draw!", "Noughts and Crosses", MessageBoxButton.OK)
            Else
                _piece = IIf(_piece = _cross, _nought, _cross) ' Swap Players
            End If
        Else
            MessageBox.Show("Game Over!", "Noughts and Crosses", MessageBoxButton.OK)
        End If
    End Sub

    Private Sub Add(ByRef Grid As Grid, ByRef Row As Integer, ByRef Column As Integer)
        Dim _btn As New Button
        AddHandler _btn.Click, AddressOf Button_Click
        _btn.Content = Nothing
        _btn.Margin = New Thickness(5)
        _btn.SetValue(Grid.ColumnProperty, Column)
        _btn.SetValue(Grid.RowProperty, Row)
        Grid.Children.Add(_btn)
    End Sub

    Private Sub Layout(ByRef Grid As Grid)
        Grid.Children.Clear()
        Grid.ColumnDefinitions.Clear()
        Grid.RowDefinitions.Clear()
        For Index As Integer = 0 To 2 ' Setup 3x3 Grid
            Grid.RowDefinitions.Add(New RowDefinition)
            Grid.ColumnDefinitions.Add(New ColumnDefinition)
        Next
        Add(Grid, 0, 0) ' Top Left
        Add(Grid, 0, 1) ' Top Middle
        Add(Grid, 0, 2) ' Top Right
        Add(Grid, 1, 0) ' Middle Left
        Add(Grid, 1, 1) ' Centre
        Add(Grid, 1, 2) ' Middle Right
        Add(Grid, 2, 0) ' Bottom Left
        Add(Grid, 2, 1) ' Bottom Middle
        Add(Grid, 2, 2) ' Bottom Right
    End Sub

    Private Sub New_Click(ByVal sender As System.Object, _
                          ByVal e As System.Windows.RoutedEventArgs) _
                      Handles [New].Click
        Layout(Display)
        _board(0, 0) = "" ' Top Left
        _board(0, 1) = "" ' Top Middle
        _board(0, 2) = "" ' Top Right
        _board(1, 0) = "" ' Middle Left
        _board(1, 1) = "" ' Centre
        _board(1, 2) = "" ' Middle Right
        _board(2, 0) = "" ' Bottom Left
        _board(2, 1) = "" ' Bottom Middle
        _board(2, 2) = "" ' Bottom Right
        _hasWon = False
        If MessageBox.Show(_cross & " to go first?", "Noughts and Crosses", _
            MessageBoxButton.OKCancel) = MessageBoxResult.OK Then
            _piece = _cross
        Else
            _piece = _nought
        End If
    End Sub
End Class

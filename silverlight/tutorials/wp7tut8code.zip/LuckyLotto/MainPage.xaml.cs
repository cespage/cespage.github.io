﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace LuckyLotto
{
    public partial class MainPage : PhoneApplicationPage
    {

        private List<int> Numbers()
        {
            int number;
            List<int> _numbers = new List<int>();
            while ((_numbers.Count < 6)) // Select 6 Numbers
            {
                Random random = new Random((int)DateTime.Now.Ticks);
                number = random.Next(1, 50); // Random Number 1 - 49
                if ((!_numbers.Contains(number)) || (_numbers.Count < 1))
                {
                    _numbers.Add(number); // Add if number Chosen or None
                }
            }
            return _numbers;
        }

        private void Draw(ref StackPanel Stack)
        {
            Stack.Children.Clear();
            foreach (int _number in Numbers())
            {
                // Choose Numbers
                Canvas _container = new Canvas();
                Ellipse _ball = new Ellipse();
                TextBlock _text = new TextBlock();
                _container.Margin = new Thickness(2);
                _container.Width = 74;
                _container.Height = 74;
                _ball.Width = _container.Width;
                _ball.Height = _container.Height;
                if (_number >= 1 && _number <= 9)
                {
                    _ball.Fill = new SolidColorBrush(Colors.White);
                }
                else if (_number >= 10 && _number <= 19)
                {
                    // Sky Blue
                    _ball.Fill = new SolidColorBrush(Color.FromArgb(255, 112, 200, 236));
                }
                else if (_number >= 20 && _number <= 29)
                {
                    _ball.Fill = new SolidColorBrush(Colors.Magenta);
                }
                else if (_number >= 30 && _number <= 39)
                {
                    // Lawn Green
                    _ball.Fill = new SolidColorBrush(Color.FromArgb(255, 112, 255, 0));
                }
                else if (_number >= 40 && _number <= 49)
                {
                    _ball.Fill = new SolidColorBrush(Colors.Yellow);
                }
                _container.Children.Add(_ball);
                _text.Foreground = new SolidColorBrush(Colors.Black);
                _text.FontSize = 24;
                _text.Text = _number.ToString();
                _text.Margin = new Thickness(20);
                _container.Children.Add(_text);
                Stack.Children.Add(_container);
            }
        }

        private void Choose_Click(object sender, RoutedEventArgs e)
        {
            Draw(ref Lottery);
        }

        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }
    }
}

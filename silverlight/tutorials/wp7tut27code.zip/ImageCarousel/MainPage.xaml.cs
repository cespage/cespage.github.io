﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace ImageCarousel
{
    public partial class MainPage : PhoneApplicationPage
    {

        private void Add_Click(object sender, EventArgs e)
        {
            Images.Add(new Uri(Location.Text));
        }

        private void Remove_Click(object sender, EventArgs e)
        {
            Images.RemoveLast();
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            Images.Clear();
        }

        // Constructor
        public MainPage()
        {
            InitializeComponent();
            ApplicationTitle.Text = "IMAGE CAROUSEL";
            Location.Text = "http://cespage.com/phone.jpg";
        }
    }
}

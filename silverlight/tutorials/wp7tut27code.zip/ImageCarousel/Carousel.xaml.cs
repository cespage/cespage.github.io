﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;

namespace ImageCarousel
{
    public partial class Carousel : UserControl
    {
        private Storyboard _rotate = new Storyboard();
        private List<BitmapImage> _images = new List<BitmapImage>();
        private List<CarouselItem> _items = new List<CarouselItem>();
        private Point _position;
        private Point _radius = new Point { X = -25, Y = 200 };
        private double _speed = 0.0125;
        private double _perspective = 75;
        private double _distance;

        public Carousel()
        {
            InitializeComponent();
            Canvas.SetLeft(Display, Container.Width / 2 - Display.Width / 2);
            Canvas.SetTop(Display, Container.Height / 2 - Display.Height / 2);
            _rotate.Completed += Rotate;
            _rotate.Begin();
        }

        private void Populate(ref Canvas canvas)
        {
            canvas.Children.Clear();
            for (int index = 0; index < _images.Count(); index++)
            {
                CarouselItem item = new CarouselItem();
                item.Image.Source = _images[index];
                item.Angle = index * ((Math.PI * 2) / _images.Count);
                _position.X = Math.Cos(item.Angle) * _radius.X;
                _position.Y = Math.Sin(item.Angle) * _radius.Y;
                Canvas.SetLeft(item, _position.X);
                Canvas.SetTop(item, _position.Y);
                _distance = 1 / (1 - (_position.X / _perspective));
                item.Opacity = item.ItemScale.ScaleX =
                  item.ItemScale.ScaleY = _distance;
                _items.Add(item);
                canvas.Children.Add(item);
            }
        }

        private void Rotate(object sender, EventArgs e)
        {
            foreach (CarouselItem item in _items)
            {
                item.Angle -= _speed;
                _position.X = Math.Cos(item.Angle) * _radius.X;
                _position.Y = Math.Sin(item.Angle) * _radius.Y;
                Canvas.SetLeft(item, _position.X);
                Canvas.SetTop(item, _position.Y);
                if (_radius.X >= 0)
                {
                    _distance = 1 * (1 - (_position.X / _perspective));
                    Canvas.SetZIndex(item, -(int)(_position.X));
                }
                else
                {
                    _distance = 1 / (1 - (_position.X / _perspective));
                    Canvas.SetZIndex(item, (int)(_position.X));
                }
                item.Opacity = item.ItemScale.ScaleX =
                  item.ItemScale.ScaleY = _distance;
            }
            _rotate.Begin();
        }

        public void Add(Uri uri)
        {
            BitmapImage _image = new BitmapImage(uri);
            _images.Add(_image);
            Populate(ref Display);
        }

        public void RemoveLast()
        {
            if (_images.Count > 0)
            {
                _images.RemoveAt(_images.Count - 1);
                Populate(ref Display);
            }
        }

        public void Clear()
        {
            _images.Clear();
            Populate(ref Display);
        }

    }
}

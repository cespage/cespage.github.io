﻿Partial Public Class MainPage
    Inherits UserControl
    Private WithEvents _timer As New Windows.Threading.DispatcherTimer
    Private _timeSeconds As Integer = Now.Second
    Private _timeMinutes As Integer = Now.Minute
    Private _timeHours As Integer = Now.Hour

    Public Sub New()
        InitializeComponent()
        Seconds.TextPrev = _timeSeconds.ToString("00")
        Minutes.TextPrev = _timeMinutes.ToString("00")
        Hours.TextPrev = _timeHours.ToString("00")
        _timer.Interval = TimeSpan.FromSeconds(1)
        _timer.Start()
    End Sub

    Private Sub Timer_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles _timer.Tick
        If _timeSeconds = 59 Then
            Seconds.Flip(_timeSeconds.ToString("00"), 0.ToString("00"))
            _timeSeconds = 0
            If _timeMinutes = 59 Then
                Minutes.Flip(_timeMinutes.ToString("00"), 0.ToString("00"))
                _timeMinutes = 0
                If _timeHours = 23 Then
                    Hours.Flip(_timeHours.ToString("00"), 0.ToString("00"))
                    _timeHours = 0
                Else
                    Hours.Flip(_timeHours.ToString("00"), (_timeHours + 1).ToString("00"))
                    _timeHours += 1
                End If
            Else
                Minutes.Flip(_timeMinutes.ToString("00"), (_timeMinutes + 1).ToString("00"))
                _timeMinutes += 1
            End If
        Else
            Seconds.Flip(_timeSeconds.ToString("00"), (_timeSeconds + 1).ToString("00"))
            _timeSeconds += 1
        End If
    End Sub

End Class

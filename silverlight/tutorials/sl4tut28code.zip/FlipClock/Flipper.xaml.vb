﻿Partial Public Class Flipper
    Inherits UserControl

    Public Shared ReadOnly TextPrevProperty As DependencyProperty =
    DependencyProperty.Register("TextPrev", GetType(String),
    GetType(Flipper), Nothing)

    Public Shared ReadOnly TextNextProperty As DependencyProperty =
    DependencyProperty.Register("TextNext", GetType(String),
    GetType(Flipper), Nothing)

    Public Sub New 
        InitializeComponent()
    End Sub

    Public Sub Flip(ByVal FromValue As String, ByVal ToValue As String)
        TextNext = ToValue
        TextPrev = FromValue
        FlipAnimation.Begin()
    End Sub

    Public Property TextPrev() As Object
        Get
            Return GetValue(TextPrevProperty)
        End Get
        Set(ByVal value As Object)
            SetValue(TextPrevProperty, value)
            textBlockBottom.Text = TextPrev
            textBlockFlipTop.Text = TextPrev
        End Set
    End Property

    Public Property TextNext() As Object
        Get
            Return GetValue(TextNextProperty)
        End Get
        Set(ByVal value As Object)
            SetValue(TextNextProperty, value)
            textBlockTop.Text = TextNext
            textBlockFlipBottom.Text = TextNext
        End Set
    End Property

End Class

// gamecode.exe 
// An empty windows program with a game loop for you

// Chris Rook

// version 1 28/1/02


#include "mydraw.h"
#include "mysurface.h"
#include "myplayer.h"
#include "mysound.h"
#include "string.h"

// Includes *************************************************************************************

#define WIN32_LEAN_AND_MEAN		// Gives you SDK windows rather than that horrible

//#include "mytools.h"


#include <ddraw.h>
#include <stdio.h>				// IO stuff
#include <windows.h>			// Windows headers all-in-one
#include <iostream.h>			// IO stuff
#include <windowsx.h>			// Windows macros
#include <math.h>				// Math stuff
#include <mmsystem.h>			// Multimedia stuff
#include <stdlib.h>				// Standard stuff
#include <dsound.h>				// Direct sound




// Defines **************************************************************************************

#define WINDOW_CLASS_NAME "WINCLASS1"	
								// Defines the name of the window class I am going to use
#define SCREENWIDTH 800
#define SCREENHEIGHT 600
#define COLOURDEPTH 16
#define SUCCESS 0
#define FAILURE -1 

// For reading keyboard
#define KEYPRESSED(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)

#define PI 3.142



// Globals **************************************************************************************

HINSTANCE g_hinstance;
HWND gHwnd;
bool WindowClosed;
MyDraw* pDrawEngine;
MyPlayer* pSoundEngine;
MySurface* pChopper; // My Surface : Helicopter
MySurface* pNumbers; // My Surface : Numbers
MySurface* pPlayer; // My Surface : Player
MySurface* pFlames; // My Surface : Flames
MySurface* pShot; // My Surface : Shot
MySound* pSoundObject; // My Sound Object
long lTimeCount; // Frame Time Counter
bool gbKPressed; // K Button Pressed
double gdAccelerate; // Global Accelerate
double gdRAccelerate; // Global Rotation Accelerate
double gdFriction; // Global Friction
double gdGravity; // Global Gravity
double gdThrust; // Global Thrust
double gdMaxThrust; // Global Max Thrust
double gdThrustRate; // Global Thrust Rate
double gdMySin[32]; // Array of Sines
double gdMyCos[32]; // Array of Cosines

// Structs **************************************************************************************

struct PlasmaBolt {
	// Attributes
	double dXCoord; 
	double dYCoord;
	double dVSpeed;
	double dHSpeed;

	// Methods
	
	// Name: Draw
	// Param: None
	// Returns: None
	void Draw()
	{
		RECT boltRect, destRect;

		boltRect.top = 0;
		boltRect.right = 5;
		boltRect.left = 0;
		boltRect.bottom = 5;

		// Determine Destination Rectangle
		destRect.top = int(dYCoord);
		destRect.bottom = destRect.top + 5;
		destRect.left = int(dXCoord);
		destRect.right = destRect.left + 5;

		pDrawEngine->Blit(destRect, boltRect, pShot);
	} // Draw()

	// Name: Move
	// Param: None
	// Returns: None
	void Move()
	{
		dVSpeed = dVSpeed - gdGravity; // Apply Gravity
		dHSpeed += 0.1; 

		dXCoord = dXCoord + dHSpeed; // Increase Horizontal 
		dYCoord = dYCoord - dVSpeed; // Increase Vertical 
	} // Move()

	// Name: Initialise
	// Param: Init
	// Returns: None
	void Init()
	{
	} // Init()

	// Name: Die
	// Param: None
	// Returns: None
	void Die()
	{
	} // Die()

};

PlasmaBolt myBolts;

struct Player {
	// Attributes
	double dXCoord; 
	double dYCoord;
	double dVSpeed;
	double dHSpeed;
	double dAngle;
	double dASpeed;
	int playerPosition;
	// Methods

	// Name: Draw Flame1 Method
	// Param: Full (Boolean)
	// Returns: None
	void DrawFlame1(bool full)
	{

		RECT flameRect, destRect;

		flameRect.left = playerPosition * 16;
		flameRect.right = ((playerPosition + 1) * 16) - 1;

		if (full==true) {
			flameRect.top = 0;
			flameRect.bottom = 16;
		}
		else {
			flameRect.top = 17;
			flameRect.bottom = 31;
		}

		// Determine Destination Rectangle
		destRect.top = int(dYCoord + 23.0 + 13.0 * gdMyCos[playerPosition] - 9.0 * gdMySin[playerPosition]);
		destRect.bottom = destRect.top + 15;
		destRect.left = int(dXCoord + 23.0 - 13.0 * gdMySin[playerPosition] - 9.0 * gdMyCos[playerPosition]);
		destRect.right = destRect.left + 15;

		pDrawEngine->Blit(destRect, flameRect, pFlames);

	} // DrawFlame1()


	// Name: Draw Flame2 Method
	// Param: Full (Boolean)
	// Returns: None
	void DrawFlame2(bool full)
	{

		RECT flameRect, destRect;

		flameRect.left = playerPosition * 16;
		flameRect.right = ((playerPosition + 1) * 16) - 1;

		if (full==true) {
			flameRect.top = 0;
			flameRect.bottom = 16;
		}
		else {
			flameRect.top = 17;
			flameRect.bottom = 31;
		}

		// Determine Destination Rectangle
		destRect.top = int(dYCoord + 23.0 + 13.0 * gdMyCos[playerPosition] + 9.0 * gdMySin[playerPosition]);
		destRect.bottom = destRect.top + 15;
		destRect.left = int(dXCoord + 23.0 - 13.0 * gdMySin[playerPosition] + 9.0 * gdMyCos[playerPosition]);
		destRect.right = destRect.left + 15;

		pDrawEngine->Blit(destRect, flameRect, pFlames);

	} // DrawFlame1()

	// Name: Draw Method
	// Param: None
	// Returns: None
	void Draw()
	{
		RECT playerRect, destRect;
		double dLeft, dRight;
		double dTop, dBottom;

		// Determine Rotation Angle
		if (dAngle > 31.99)
		{
			dAngle = 0.0;
			playerPosition = 0;
		}
		if (dAngle < 0.0)
		{
			dAngle = 31.99;
			playerPosition = 31;
		}
			 
		switch (int(dAngle))
		{
			case 0:
				dLeft = 0;
				dRight = 63;
				dTop = 0;
				dBottom = 63;
				playerPosition = 0;
				break;
			case 1:
				dLeft = 64;
				dRight = 127;
				dTop = 0;
				dBottom = 63;
				playerPosition = 1;
				break;
			case 2:
				dLeft = 128;
				dRight = 191;
				dTop = 0;
				dBottom = 63;
				playerPosition = 2;
				break;
			case 3:
				dLeft = 192;
				dRight = 255;
				dTop = 0;
				dBottom = 63;
				playerPosition = 3;
				break;
			case 4:
				dLeft = 256;
				dRight = 319;
				dTop = 0;
				dBottom = 63;
				playerPosition = 4;
				break;
			case 5:
				dLeft = 320;
				dRight = 383;
				dTop = 0;
				dBottom = 63;
				playerPosition = 5;
				break;
			case 6:
				dLeft = 384;
				dRight = 447;
				dTop = 0;
				dBottom = 63;
				playerPosition = 6;
				break;
			case 7:
				dLeft = 448;
				dRight = 511;
				dTop = 0;
				dBottom = 63;
				playerPosition = 7;
				break;
			case 8:
				dLeft = 0;
				dRight = 63;
				dTop = 64;
				dBottom = 127;
				playerPosition = 8;
				break;
			case 9:
				dLeft = 64;
				dRight = 127;
				dTop = 64;
				dBottom = 127;
				playerPosition = 9;
				break;
			case 10:
				dLeft = 128;
				dRight = 191;
				dTop = 64;
				dBottom = 127;
				playerPosition = 10;
				break;
			case 11:
				dLeft = 192;
				dRight = 255;
				dTop = 64;
				dBottom = 127;
				playerPosition = 11;
				break;
			case 12:
				dLeft = 256;
				dRight = 319;
				dTop = 64;
				dBottom = 127;
				playerPosition = 12;
				break;
			case 13:
				dLeft = 320;
				dRight = 383;
				dTop = 64;
				dBottom = 127;
				playerPosition = 13;
				break;
			case 14:
				dLeft = 384;
				dRight = 447;
				dTop = 64;
				dBottom = 127;
				playerPosition = 14;
				break;
			case 15:
				dLeft = 448;
				dRight = 511;
				dTop = 64;
				dBottom = 127;
				playerPosition = 15;
				break;
			case 16:
				dLeft = 0;
				dRight = 63;
				dTop = 128;
				dBottom = 191;
				playerPosition = 16;
				break;
			case 17:
				dLeft = 64;
				dRight = 127;
				dTop = 128;
				dBottom = 191;
				playerPosition = 17;
				break;
			case 18:
				dLeft = 128;
				dRight = 191;
				dTop = 128;
				dBottom = 191;
				playerPosition = 18;
				break;
			case 19:
				dLeft = 192;
				dRight = 255;
				dTop = 128;
				dBottom = 191;
				playerPosition = 19;
				break;
			case 20:
				dLeft = 256;
				dRight = 319;
				dTop = 128;
				dBottom = 191;
				playerPosition = 20;
				break;
			case 21:
				dLeft = 320;
				dRight = 383;
				dTop = 128;
				dBottom = 191;
				playerPosition = 21;
				break;
			case 22:
				dLeft = 384;
				dRight = 447;
				dTop = 128;
				dBottom = 191;
				playerPosition = 22;
				break;
			case 23:
				dLeft = 448;
				dRight = 511;
				dTop = 128;
				dBottom = 191;
				playerPosition = 23;
				break;
			case 24:
				dLeft = 0;
				dRight = 63;
				dTop = 192;
				dBottom = 255;
				playerPosition = 24;
				break;
			case 25:
				dLeft = 64;
				dRight = 127;
				dTop = 192;
				dBottom = 255;
				playerPosition = 25;
				break;
			case 26:
				dLeft = 128;
				dRight = 191;
				dTop = 192;
				dBottom = 255;
				playerPosition = 26;
				break;
			case 27:
				dLeft = 192;
				dRight = 255;
				dTop = 192;
				dBottom = 255;
				playerPosition = 27;
				break;
			case 28:
				dLeft = 256;
				dRight = 319;
				dTop = 192;
				dBottom = 255;
				playerPosition = 28;
				break;
			case 29:
				dLeft = 320;
				dRight = 383;
				dTop = 192;
				dBottom = 255;
				playerPosition = 29;
				break;
			case 30:
				dLeft = 384;
				dRight = 447;
				dTop = 192;
				dBottom = 255;
				playerPosition = 30;
				break;
			case 31:
				dLeft = 448;
				dRight = 511;
				dTop = 192;
				dBottom = 255;
				playerPosition = 31;
				break;

		}

		playerRect.top = int(dTop);
		playerRect.bottom = int(dBottom);
		playerRect.left = int(dLeft);
		playerRect.right = int(dRight);

		// Render the Player

		// Determine Destination Rectangle
		destRect.top = int(dYCoord);
		destRect.bottom = int(dYCoord) + 64;
		destRect.left = int(dXCoord);
		destRect.right = int(dXCoord) + 64;

		
			if (gdThrust < 2.0)
			{
				// Draw Nothing
			}
			else if (gdThrust > 2.0 && gdThrust < 4.0) {	
				DrawFlame1(false);
				DrawFlame2(false);
			} 
			else if (gdThrust > 4.0) {
				DrawFlame1(true);
				DrawFlame2(true);
			}

		// Draw to the back buffer
		pDrawEngine->Blit(destRect, playerRect, pPlayer);

	} // Draw(...)


	// Name: Move Method
	// Param: None
	// Returns: None
	void Move()
	{

		/*if (KEYPRESSED(VK_UP))
			dVSpeed -= gdAccelerate; // Acceleration
		else if (KEYPRESSED(VK_DOWN))
			dVSpeed += gdAccelerate; // Acceleration
		else*/
			//dVSpeed = 0;
		/*if (KEYPRESSED(VK_LEFT))
			dHSpeed -= gdAccelerate; // Acceleration
		else if (KEYPRESSED(VK_RIGHT))
			dHSpeed += gdAccelerate; // Acceleration
		else*/
			//dHSpeed = 0;

		if (KEYPRESSED('F'))
		{
			// Fire Bolt
			myBolts.Init();
			myBolts.dXCoord = dXCoord + 29 + 28 * gdMyCos[playerPosition] - 4 * gdMySin[playerPosition];
			myBolts.dYCoord = dYCoord + 29 + 28 * gdMySin[playerPosition] - 4 * gdMyCos[playerPosition];
		}


		if (KEYPRESSED(VK_RIGHT))
			dASpeed += gdRAccelerate; // Acceleration
		else if (KEYPRESSED(VK_LEFT))
			dASpeed -= gdRAccelerate; // Acceleration
		else
			// dASpeed = 0;

		if (KEYPRESSED(VK_UP))
		{
			// Increase Thrust
			if (gdThrust < gdMaxThrust)
			{
				gdThrust += (gdMaxThrust) * gdThrustRate;
			}

			// Thrust
			dVSpeed = gdThrust * gdMyCos[playerPosition];
			dHSpeed = gdThrust * gdMySin[playerPosition];
		}
		else
		{
			gdThrust = gdThrust * (1.0 - gdThrustRate);
		}

		dVSpeed = dVSpeed - gdGravity; // Apply Gravity
		dHSpeed = dHSpeed * gdFriction; // Friction
		dVSpeed = dVSpeed * gdFriction; // Apply Friction
		dASpeed = dASpeed * gdFriction; // Apply Friction

		dXCoord = dXCoord + dHSpeed; // Increase Horizontal 
		dYCoord = dYCoord - dVSpeed; // Increase Vertical 
		dAngle = dAngle + dASpeed; // Increase Angle Speed

		// Wrap Around

		if (dXCoord > 799) {
			dXCoord = 0;
		}
		else if (dXCoord < 0) {
			dXCoord = 799;
		}
		if (dYCoord > 599) {
			dYCoord = 0;
		}
		else if (dYCoord < 0) {
			dYCoord = 599;
		}

	} // Move()


	// Name: Init Method
	// Param: None
	// Returns: None
	void Init()
	{
		dXCoord = 100;
		dYCoord = 100;
	}

	// Name: Kill Method
	// Param: None
	// Returns: None
	void Kill()
	{
		if (KEYPRESSED('Q'))
		{
			if (gbKPressed)
			{
				Init(); // Kill Player
				gbKPressed = false;
			}
		}
		else
		{
			gbKPressed = true;
		}
		
	}

};



struct Helicopter {
	// Attributes
	double dXCoord; 
	double dYCoord;
	double dVSpeed;
	double dHSpeed;
	int frameCounter;
	// Methods

	// Name: Draw Chopper Method
	// Param: Frame Number
	// Returns: None
	void Draw(int FrameNumber)
	{
		RECT chopperRect, destRect;
		double dLeft, dRight;

		switch (FrameNumber)
		{
			case 0:
				dLeft = 0;
				dRight = 63;
				break;
			case 1:
				dLeft = 64;
				dRight = 127;
				break;
			case 2:
				dLeft = 128;
				dRight = 191;
				break;
		}

		chopperRect.top = 0;
		chopperRect.bottom = 31;
		chopperRect.left = int(dLeft);
		chopperRect.right = int(dRight);

		// Render the Helicopter

		// Determine Destination Rectangle
		destRect.top = int(dYCoord);
		destRect.bottom = int(dYCoord) + 32;
		destRect.left = int(dXCoord);
		destRect.right = int(dXCoord) + 64;

		// Draw to the back buffer
		pDrawEngine->Blit(destRect, chopperRect, pChopper);


	} // Draw(...)

	// Name: Move Chopper Method
	// Param: None
	// Returns: None
	void Move()
	{

		if (KEYPRESSED(VK_UP))
			dVSpeed -= gdAccelerate; // Acceleration
		else if (KEYPRESSED(VK_DOWN))
			dVSpeed += gdAccelerate; // Acceleration
		else
			//dVSpeed = 0;
		if (KEYPRESSED(VK_LEFT))
			dHSpeed -= gdAccelerate; // Acceleration
		else if (KEYPRESSED(VK_RIGHT))
			dHSpeed += gdAccelerate; // Acceleration
		else
			//dHSpeed = 0;
		dVSpeed = dVSpeed + gdGravity; // Apply Gravity
		dHSpeed = dHSpeed * gdFriction; // Friction
		dVSpeed = dVSpeed * gdFriction; // Apply Friction


		dXCoord = dXCoord + dHSpeed; // Increase Horizontal 
		dYCoord = dYCoord + dVSpeed; // Increase Vertical 

		// Wrap Around

		if (dXCoord > 799) {
			dXCoord = 0;
		}
		else if (dXCoord < 0) {
			dXCoord = 799;
		}
		if (dYCoord > 599) {
			dYCoord = 0;
		}
		else if (dYCoord < 0) {
			dYCoord = 599;
		}

	} // Move()

	// Name: Init Method
	// Param: None
	// Returns: None
	void Init()
	{
		dXCoord = 100;
		dYCoord = 100;
	}

	// Name: Kill Method
	// Param: None
	// Returns: None
	void Kill()
	{
		if (KEYPRESSED('K'))
		{
			if (gbKPressed)
			{
				Init(); // Kill Chopper
				gbKPressed = false;
			}
		}
		else
		{
			gbKPressed = true;
		}
			
	}

};

// Structs **************************************************************************************

Helicopter myChopper; // Helicopter
Player myPlayer; // Player
PlasmaBolt myPlasmaBolt; // Plasma Bolt

// Constants ************************************************************************************



// Functions ************************************************************************************

int GameInit();
int GameMain();
void GameShutdown();

	// Name: Draw Number
	// Param: Number
	// Returns: None
	void DrawNumber(double X, double Y, int Number)
	{
		RECT numberRect, destRect;
		double gdLeft, gdRight;

		gdLeft = Number * 16;
		gdRight = ((Number + 1) * 16) - 1;

		numberRect.top = 0;
		numberRect.bottom = 23;
		numberRect.left = int(gdLeft);
		numberRect.right = int(gdRight);

		// Determine Destination Rectangle
		destRect.top = int(Y);
		destRect.bottom = int(Y) + 24;
		destRect.left = int(X);
		destRect.right = int(X) + 16;

		// Draw to the back buffer
		pDrawEngine->Blit(destRect, numberRect, pNumbers);

	} // DrawNumber(...)

	// Name: Draw Digits
	// Param: Number
	// Returns: None
	void DrawDigits(double X, double Y, int Number)
	{
		while (Number > 0)
		{
			DrawNumber(X,Y,(Number%10));
			X-=18;
			Number = Number / 10;
		}
		
	} // DrawDigits(...)


// Window proc **********************************************************************************


// Remember -- all the windows will use this winproc!!!

LRESULT CALLBACK WindowProc(	// The event handler. It's a callback function
							HWND hwnd,		// The handle to the window that called
							UINT msg,		// The message sent
							WPARAM wparam,
							LPARAM lparam)	// These further subclass the message sent,
											// but I don't plan to use them
{
	PAINTSTRUCT ps;				// Use by WM_PAINT
	HDC hdc;					// A handle to a device context. May be used by WM_PAINT,
								// but not right now.

	// Decide what the message is
	switch(msg)
	{
	case WM_CREATE:				// If window has been created
		{
								// Do any initialisation
			return(0);			// Return success
		}
		break;

	case WM_PAINT:
		{
			hdc=BeginPaint(hwnd, &ps);		// Validate the window
			EndPaint(hwnd, &ps);

			// I havn't really done much here - just did a standard paint-job to pretend
			// the window has been properly painted.
			// hwnd tells it what to paint - the window, of course
			// ps is the address of a structure holding the rectangle to bve drawn
			// hdc is a graphics context that describes the video system

			return(0);			// return success
		}
		break;

	case WM_DESTROY:
		{
			// Wants to kill the application
			PostQuitMessage(0);	// Sends a quit message onto the windows queue

			return(0);			// return success
		}
		break;

	default:
		break;

	}	// End the switch

	// Any messages not handled are done by the default handler
	return (DefWindowProc(hwnd, msg, wparam, lparam));
					// Ever feel like switching round wparam and lparam,
					// just to see what happens?

}	// End of WinProc


// Winmain **************************************************************************************

int WINAPI WinMain(HINSTANCE hInstance,			// A number that registers the instance of this program
				   HINSTANCE hPrevInstance,		// Not used in W95+. Null
				   LPSTR lpCmdLine,				// Pointer to a string that started this whole thing off
				   int nCmdShow)				// Integer that tells how the window is to appear. Active/maximized, etc
{
	WNDCLASSEX	winclass;				// The window class to be created
	HWND		hwnd;					// A general window handle
	MSG			msg;					// A general message

	// Fill in the window class structure
	winclass.cbSize	=	sizeof(WNDCLASSEX);		// The size of the class in case anyone wants to know
	winclass.style	=	CS_DBLCLKS |			// Responds to double-clicks
						CS_OWNDC	|			// Has own device context (speed)
						CS_HREDRAW |			// Redraws if vertically changed
						CS_VREDRAW;				// Redraws if horizontally changed
	winclass.lpfnWndProc = WindowProc;			// Sets pointer to WindowProc function
	winclass.cbClsExtra	=	0;					// No-one used these
	winclass.cbWndExtra	=	0;					// nowadays
	winclass.hInstance	=	hInstance;			// The handle to the instance created at startup
	winclass.hIcon		= LoadIcon				// Set the icon to use
							(NULL,				// use a standard one
							IDI_APPLICATION);	// this standard one
	winclass.hCursor	=	LoadCursor			// Set cursor to use
							(NULL,				// Use a standard one
							IDC_ARROW);			// The bog-standard arrow
	winclass.hbrBackground =					// Set background brush (using handle)
		(HBRUSH)GetStockObject(BLACK_BRUSH);	// Get the black one from the general stores
	winclass.lpszMenuName = NULL;				// A string for the resource filename with the menu in. Not using one here.
	winclass.lpszClassName = WINDOW_CLASS_NAME;	// The name of this class - defined above
	winclass.hIconSm	= LoadIcon				// Set the small icon
						(NULL, IDI_APPLICATION);	// Bog standard one

	g_hinstance = hInstance;					// Keep global record of the application instance#



	// Register the window. If it fails, bug out
	if (!RegisterClassEx(&winclass))
		return(FAILURE);

	// Create the window

	if (!(hwnd = CreateWindowEx(NULL,				// No extended styles
								WINDOW_CLASS_NAME,	// The class name
								"Basic window",		// Title
								WS_POPUP | WS_VISIBLE, // An overlapped, visible window
								0,0,				// Initial location
								SCREENWIDTH,SCREENHEIGHT,		// Size
								NULL,				// PArent - use desktop
								NULL,				// No menu used, so no handle
								hInstance,			// handle to this instance
								NULL)))				// No extra parameters
			return(FAILURE);						// Bug out if failed

	gHwnd=hwnd;										// Set the global

	// The event loop

	int gameError=GameInit();						// Initialise the game

	if (gameError == FAILURE)						// If game failed to initialise
		WindowClosed = true;
	else
	while(true)
	{												// Infinite loop

		if(PeekMessage(&msg, NULL, 0,0,PM_REMOVE))	// If there is a message in the queue, remove it and....
		{
			if (msg.message == WM_QUIT)				// If is is "quit"
				break;								// out of the infinite loop

			TranslateMessage(&msg);					// Translate the message - it's voodoo

			DispatchMessage(&msg);					// And send it to the Window proc
		}

	// Test to see if boss walked into the room

		if (KEYPRESSED(VK_ESCAPE))
		{
			PostMessage(gHwnd,WM_CLOSE,0,0);
			WindowClosed=true;
		}

		gameError=GameMain();								// Play the real game stuff

	}		// End infinite loop

	GameShutdown();								// Clear up the game

	return(msg.wParam);								// Return to windows

}	// End WinMain


// The game !!! *********************************************************************************

int GameInit()
{
	
	WindowClosed=false;

	lTimeCount = 0;

	RECT rgrClipperRects[1];

	rgrClipperRects[0].top = 0;
	rgrClipperRects[0].bottom = 599;
	rgrClipperRects[0].left = 0;
	rgrClipperRects[0].right = 799;

	myChopper.dXCoord = 0.0;
	myChopper.dYCoord = 0.0;
	myChopper.dVSpeed = 0.0;
	myChopper.dHSpeed = 0.0;

	pDrawEngine = new MyDraw(SCREENWIDTH, SCREENHEIGHT, COLOURDEPTH, gHwnd);
	pDrawEngine->SetClipper(1,rgrClipperRects);
	pSoundEngine = new MyPlayer(gHwnd);

	pChopper = new MySurface(pDrawEngine->lpdd);
	pChopper->LoadBitmap("chopper.bmp");

	pNumbers = new MySurface(pDrawEngine->lpdd);
	pNumbers->LoadBitmap("numbers.bmp");

	pPlayer = new MySurface(pDrawEngine->lpdd);
	pPlayer->LoadBitmap("buggy.bmp");

	pFlames = new MySurface(pDrawEngine->lpdd);
	pFlames->LoadBitmap("flames.bmp");

	pShot = new MySurface(pDrawEngine->lpdd);
	pShot->LoadBitmap("shot.bmp");

	pSoundObject = new MySound(pSoundEngine->lpds,"chopperloop.wav");

	// Initialise Physics
	gdAccelerate = 1.2;
	gdRAccelerate = 0.10;
	gdFriction = 0.96;
	gdGravity = 0.05;
	gdThrust = 0.0;
	gdMaxThrust = 8.0;
	gdThrustRate = 0.2;

	// Sines

	for (int i = 0;i<32;i++) 
	{
		gdMySin[i] = sin(2*PI*i/32);
	}

	for (int j = 0;j<32;j++) 
	{
		gdMyCos[j] = cos(2*PI*j/32);
	}

	return (SUCCESS);
}

// ******************************************************************

int GameMain()
{

	lTimeCount = GetTickCount();

	if (WindowClosed)		// Check I'm not already dead
		return FAILURE;

	RECT sourceRect, tempRect;

	myChopper.frameCounter ++;

	if (myChopper.frameCounter == 3) {
		myChopper.frameCounter = 0;
	}

	sourceRect.top = 0;
	sourceRect.bottom = 31;
	sourceRect.left = 0;
	sourceRect.right = 63;

	tempRect.top=0;
	tempRect.bottom=50;
	tempRect.left=0;
	tempRect.right=50;
	int x=500;

	pDrawEngine->FillRect(tempRect,x);

	//myChopper.Move();
	myPlayer.Move();
	// Plasma Bolts
	myBolts.Move();
	// Render Helicopter
	pDrawEngine->ClearBackBuffer();
	//myChopper.Draw(myChopper.frameCounter);
	myPlayer.Draw();
	myBolts.Draw();
	myChopper.Kill();
	DrawDigits(200,100,162);
	pDrawEngine->Flip();
	
	pSoundObject->Play(DSBPLAY_LOOPING);

	while(GetTickCount() - lTimeCount < 25);

	return SUCCESS;
}

// ***********************************************************

void GameShutdown()
{

	pChopper->Release();
	pNumbers->Release();
	pPlayer->Release();
	pFlames->Release();
	pShot->Release();
	pSoundObject->Release();
	
	// release everything
	pDrawEngine->Release();
	pSoundEngine->Release();

	// Or just scrub what you can and cross your fingers
}
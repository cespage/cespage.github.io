// Chris Rook

// version 5 13/2/02

// Inline functions corrected
// SetFrequency() added


#include <dsound.h>		// directX draw
#include <ddraw.h>		// directX draw
#include <mmsystem.h>	// Multimedia stuff
#include <iostream.h>	// In/out stuff
#include <conio.h>		// In/out stuff
#include <stdlib.h>		// Standard tools
#include <malloc.h>		// Memory allocation tools
#include <memory.h>		// Memory management tools
#include <string.h>		// Strings - old style
#include <stdarg.h>		// #########################
#include <stdio.h>		// Yet more in/out
#include <math.h>		// Maths tools
#include <io.h>			// Yet more in/out
#include <fcntl.h>		// Function control tools



#ifndef MYSOUND_H
#define MYSOUND_H


#define FAILURE -1
#define SUCCESS 0

class MySound
{
private:


public:
	LPDIRECTSOUNDBUFFER lpSoundBuffer;
	// This is a long pointer to the DSound buffer. DirectX
	// functions can be called on it, once it it initialised.

	MySound(LPDIRECTSOUND lpds, char* pszFilename);
	// Constructor
	// Preconditions:
	//	lpds points to an initialised instance of DirectSound.
	//  (Can be obtained "lpds" in an instance of MyPlayer.)
	//  pszFilename points to a string containing the name
	//  of a PCM wave file.
	// Postcondition:
	//  A directX sound buffer is created, and theSound points to it.
	//  The wave data from the sound file is loaded into the buffer.

	~MySound();
	// Destructor
	// Calls shutDown, but no harm is calling it explicitly.
	
	int Play(int flag=0);
	// Precondition:
	//	A sound file has been correctly opened by the constructor.
	// Postconditions:
	//	The sound will start playing. If the flag has been set to 
	//	DSBPLAY_LOOPING, the sound will loop. Otherwise it will play once.
	//  If the sound is currently playing, it will restart.
	// Returns:
	//  0 if dsound played the sound correctly.
	//  -1 if the sound failed to play.

	int Stop();
	// Precondition:
	//	A sound file has been correctly loaded by the constructor.
	// Postconditions:
	//  The sound file will stop playing.
	// Returns:
	//  0 if DSound stopped the sound correctly.
	//  -1 if DSound reported an error

	int SetVolume(int lVolume);
	// Precondition:
	//  Sound file has been correctly loaded.
	//	lVolume is between -10000 and 0.
	// Postcondition:
	//  Volume of the sound is set to level indicated by lVolume.
	//  0 is normal loudness. -10000 is silent.
	// Returns:
	//  0 if DSound set the volume of the sound correctly.
	//  -1 if DSound reported an error

	int SetPan(int lPan);
	// Precondition:
	//  Sound file has been correctly loaded.
	//	lPan is between -10000 and +10000.
	// Postcondition:
	//  Pan of the sound is set to level indicated by lPan.
	//  0 is dead centre. -10000 is fully left. +10000 is fully right.
	//  Note that pan is on top of any stereo data stored in the .wav file
	// Returns:
	//  0 if DSound set the pan of the sound correctly.
	//  -1 if DSound reported an error

	int SetFrequency(int lFrequency);
	// Precondition:
	//  Sound file has been correctly loaded.
	//	lFrequenncy is between DSBFREQUENCY_MIN (100?) and DSBFREQUENCY_MAX (100,000)?
	// Postcondition:
	//  Frequency of the sound is set to level indicated by lFrequency.
	//  0 is dead centre. -10000 is fully left. +10000 is fully right.
	//  Note that pan is on top of any stereo data stored in the .wav file
	// Returns:
	//  0 if DSound set the frequency of the sound correctly.
	//  -1 if DSound reported an error




	int Release();
	// Postcondition
	//  Releases memory and theSound
	//  theSound set to null
	// Returns:
	//  0 if theSound was initialised
	//  -1 if theSound was not initialised

};



#endif
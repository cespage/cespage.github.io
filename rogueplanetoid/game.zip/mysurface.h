// MySurface.h Specification for the class MySurface

// Chris Rook

// version 3 4/2/02

// Inline functions corrected
// Blit and FillRect changed to pass-by-reference

#ifndef mysurface_h
#define mysurface_h

#include <ddraw.h>		// directX draw
#include <mmsystem.h>	// Multimedia stuff
#include <iostream.h>	// In/out stuff
#include <conio.h>		// In/out stuff
#include <stdlib.h>		// Standard tools
#include <malloc.h>		// Memory allocation tools
#include <memory.h>		// Memory management tools
#include <string.h>		// Strings - old style
#include <stdarg.h>		// #########################
#include <stdio.h>		// Yet more in/out
#include <math.h>		// Maths tools
#include <io.h>			// Yet more in/out
#include <fcntl.h>		// Function control tools




// Macros ****************************************************

// Class Spec ************************************************

class MySurface
{
	IDirectDraw2* lpdd;

public:

// Public attributes
	int width;
	int height;
	LPDIRECTDRAWSURFACE lpTheSurface;

// Public methods

	MySurface(IDirectDraw2* lpdd);
	// Precondition:
	//	lpdd points to an initialised instance of Direct Draw
	// Postcondition
	//  A secondary surface is created. lpTheSurface points to it.


	~MySurface();

	int LoadBitmap(char* pszFilename, int flags=NULL);
	int MakeBlank(int width, int height, int flags=NULL);

	int Blit(RECT& destinationRect, RECT& sourceRect, MySurface *sourceSurface);
	int FillRect(RECT& destinationRect, int colour);

	void Release();

};




#endif
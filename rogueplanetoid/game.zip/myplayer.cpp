#include "myplayer.h"

MyPlayer::MyPlayer(HWND hwnd)
{
	HRESULT error;
	if (FAILED(DirectSoundCreate(NULL, &lpds, NULL)))
	{
		OutputDebugString("Failed to create sound player\n");
		lpds=NULL;
	}
	error=lpds->SetCooperativeLevel(hwnd, DSSCL_NORMAL);
	if (FAILED(error))
	{
		OutputDebugString("Failed to set cooperative level\n");
		lpds->Release();
		lpds=NULL;
		if (error==DSERR_INVALIDPARAM)
			OutputDebugString("Parameters invalid\n");
		if (error==DSERR_ALLOCATED)
			OutputDebugString("Allocated\n");

	}
}

MyPlayer::~MyPlayer()
{
	Release();
}

int MyPlayer::Release()
{
	if (lpds)
	{
		lpds->Release();
		return SUCCESS;
	}
	return FAILURE;
}